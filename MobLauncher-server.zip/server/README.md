# MobLauncher friends server
Friends, chat, mod-list sharing and voice-call signalling for MobLauncher.
Players are verified with the Minecraft session protocol (Microsoft + Ely.by) – nobody can pretend to be someone else.

## Run
    npm install
    npm start            # PORT=8787, data in ./data/db.json
    npm test             # end-to-end tests

## Deploy
* **Docker / VPS:** `docker build -t mob-friends . && docker run -d -p 8787:8787 -v mobdata:/data mob-friends`
* **Render.com:** push this folder to GitHub, "New → Blueprint", it reads `render.yaml` (free plan sleeps when idle; use a paid plan or a VPS for 24/7).
* **TLS (needed for wss://):** Caddy – `friends.example.com { reverse_proxy localhost:8787 }`
  nginx – `location / { proxy_pass http://127.0.0.1:8787; proxy_http_version 1.1; proxy_set_header Upgrade $http_upgrade; proxy_set_header Connection "upgrade"; }`

Then in the launcher: **Settings → Friends server → `wss://friends.example.com`**
(or ship it by default: put `{"friendsServer":"wss://friends.example.com"}` into `launcher/defaults.json` before building).

Env: `PORT`, `MOB_DATA`, `MOB_SERVER_NAME`, `CURSEFORGE_KEY` (optional: enables the built-in CurseForge proxy so players need no key; get a free key at console.curseforge.com). `MOB_INSECURE_AUTH=1` is for local tests ONLY.
Voice calls are peer-to-peer (WebRTC, Google STUN). Strict NATs may need a TURN server (not included).
