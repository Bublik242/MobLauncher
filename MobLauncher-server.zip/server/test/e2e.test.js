'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { spawn } = require('node:child_process');
const http = require('node:http');
const os = require('node:os'), fs = require('node:fs'), path = require('node:path');
const WebSocket = require('ws');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mobsrv-'));
const dbfile = path.join(tmp, 'db.json');
function startServer(env) {
  return new Promise((res, rej) => {
    const p = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env: { ...process.env, PORT: '0', MOB_DATA: dbfile, ...env } });
    p.stdout.on('data', d => { const m = String(d).match(/:(\d+)/); if (m) res({ p, port: +m[1] }); });
    p.on('error', rej); setTimeout(() => rej(new Error('server start timeout')), 8000);
  });
}
const uuid = (n) => n.toString(16).padStart(32, '0');
class Client {
  constructor(port, provider, name, n) { this.provider = provider; this.name = name; this.uuid = uuid(n); this.id = `${provider}:${this.uuid}`; this.inbox = []; this.waiters = []; this.ws = new WebSocket(`ws://127.0.0.1:${port}`); this.ws.on('message', d => { const m = JSON.parse(String(d)); const i = this.waiters.findIndex(w => w.f(m)); if (i >= 0) this.waiters.splice(i, 1)[0].r(m); else this.inbox.push(m); }); }
  next(f, ms = 3000) { const i = this.inbox.findIndex(f); if (i >= 0) return Promise.resolve(this.inbox.splice(i, 1)[0]); return new Promise((r, j) => { const w = { f, r }; this.waiters.push(w); setTimeout(() => { const k = this.waiters.indexOf(w); if (k >= 0) { this.waiters.splice(k, 1); j(new Error('timeout waiting; inbox=' + JSON.stringify(this.inbox.map(x => x.t)))); } }, ms); }); }
  type(t) { return this.next(m => m.t === t); }
  send(o) { this.ws.send(JSON.stringify(o)); }
  async login() { const h = await this.type('hello'); assert.equal(h.protocol, 1); this.send({ t: 'auth', provider: this.provider, username: this.name, uuid: this.uuid }); return this.next(m => m.t === 'authed' || m.t === 'error'); }
  close() { this.ws.close(); }
}

test('full flow (insecure auth)', async (t) => {
  const { p, port } = await startServer({ MOB_INSECURE_AUTH: '1' });
  t.after(() => p.kill());
  const a = new Client(port, 'microsoft', 'Alice', 1), b = new Client(port, 'elyby', 'Bob', 2), c = new Client(port, 'microsoft', 'Carol', 3);
  const ra = await a.login(); assert.equal(ra.t, 'authed'); assert.equal(ra.user.id, a.id);
  await b.login(); await c.login();

  // search
  a.send({ t: 'search', q: 'bo' }); const sr = await a.type('search.result'); assert.deepEqual(sr.users.map(u => u.name), ['Bob']);
  // request -> accept
  a.send({ t: 'friend.request', to: b.id, rid: 'r1' }); const ok = await a.next(m => m.t === 'ok'); assert.equal(ok.rid, 'r1');
  const inc = await b.type('friend.incoming'); assert.equal(inc.from.id, a.id);
  b.send({ t: 'friend.accept', from: a.id }); const fa = await a.type('friend.added'); assert.equal(fa.friend.id, b.id); assert.equal(fa.friend.online, true); await b.type('friend.added');
  // mutual request auto-accept
  a.send({ t: 'friend.request', to: c.id }); await c.type('friend.incoming');
  c.send({ t: 'friend.request', to: a.id }); await a.next(m => m.t === 'friend.added' && m.friend.id === c.id);
  // presence with huge mod list
  const mods = Array.from({ length: 1500 }, (_, i) => ({ id: `modrinth:P${i}`, name: 'Mod' + i, version: '1.0', sha1: 'ab'.repeat(20) }));
  b.send({ t: 'presence', status: 'online', playing: { instance: 'Pack', mcVersion: '1.20.1', loader: 'fabric', loaderVersion: '0.15', server: 'play.x.net:25566', mods } });
  const pr = await a.next(m => m.t === 'presence' && m.presence && m.presence.playing); assert.equal(pr.presence.playing.mods.length, 1500); assert.equal(pr.presence.playing.server, 'play.x.net:25566');
  // hours + profile + hideActivity
  b.send({ t: 'presence', status: 'online', hours: 123.46, hideActivity: true, playing: { instance: 'secret', mcVersion: '1.20.1', loader: 'vanilla', mods: [] } });
  const hp = await a.next(m => m.t === 'presence' && m.user.id === b.id && m.presence && m.presence.playing === null); assert.equal(hp.user.hours, 123.5);
  a.send({ t: 'profile', user: b.id }); const pf = await a.type('profile'); assert.equal(pf.user.hours, 123.5); assert.equal(pf.user.isFriend, true);
  a.send({ t: 'search', q: 'bob' }); assert.equal((await a.type('search.result')).users[0].hours, 123.5);
  // chat online
  a.send({ t: 'msg', to: b.id, text: 'hello' }); const m1 = await b.type('msg'); assert.equal(m1.text, 'hello'); const echo = await a.type('msg'); assert.equal(echo.id, m1.id);
  // not friends can't chat
  b.send({ t: 'msg', to: 'microsoft:' + uuid(99), text: 'x' }); assert.equal((await b.type('error')).code, 'not_friends');
  // offline chat + unread
  b.close(); await a.next(m => m.t === 'presence' && m.user.id === b.id && m.online === false);
  a.send({ t: 'msg', to: b.id, text: 'while away' }); await a.type('msg');
  const b2 = new Client(port, 'elyby', 'Bob', 2); const rb = await b2.login(); assert.equal(rb.unread[a.id], 1); assert.equal(rb.friends.length, 1);
  b2.send({ t: 'history', with: a.id }); const h = await b2.type('history'); assert.deepEqual(h.messages.map(x => x.text), ['hello', 'while away']);
  b2.send({ t: 'read', with: a.id }); await b2.type('ok');
  // invite
  a.send({ t: 'invite', to: b.id, payload: { instance: 'X', server: 's' } }); const iv = await b2.type('invite'); assert.equal(iv.from.id, a.id); assert.equal(iv.payload.server, 's');
  // calls
  a.send({ t: 'call.invite', to: b.id }); assert.equal((await b2.type('call.invite')).from.id, a.id);
  b2.send({ t: 'call.accept', to: a.id }); assert.equal((await a.type('call.accepted')).from, b.id);
  a.send({ t: 'call.signal', to: b.id, data: { sdp: { type: 'offer', sdp: 'v=0' } } }); assert.equal((await b2.type('call.signal')).data.sdp.type, 'offer');
  b2.send({ t: 'call.end', to: a.id }); assert.equal((await a.type('call.ended')).from, b.id);
  // multi connection: second Alice connection gets events
  const a2 = new Client(port, 'microsoft', 'Alice', 1); await a2.login();
  c.send({ t: 'msg', to: a.id, text: 'multi' }); await a.next(m => m.t === 'msg' && m.text === 'multi'); await a2.next(m => m.t === 'msg' && m.text === 'multi');
  // rate limiting
  for (let i = 0; i < 60; i++) c.send({ t: 'ping' });
  const rl = await c.next(m => m.t === 'error' && m.code === 'rate_limited'); assert.ok(rl);
  // remove
  a.send({ t: 'friend.remove', user: c.id }); await a.type('friend.removed'); await c.type('friend.removed');
  [a, a2, b2, c].forEach(x => x.close());
});

test('persistence across restart', async () => {
  const { p, port } = await startServer({ MOB_INSECURE_AUTH: '1' });
  const a = new Client(port, 'microsoft', 'Alice', 1); const r = await a.login();
  assert.equal(r.friends.length, 1, 'friend Bob persisted'); a.send({ t: 'history', with: 'elyby:' + uuid(2) }); const h = await a.type('history'); assert.equal(h.messages.length, 2);
  a.close(); p.kill();
});

test('bad auth rejected when verification is on (mock session servers)', async () => {
  const good = new Set(); let calls = 0;
  const mock = http.createServer((req, res) => { calls++; const u = new URL(req.url, 'http://x'); const key = u.searchParams.get('username') + ':' + u.searchParams.get('serverId'); if (good.has(key) && /hasJoined/.test(u.pathname)) { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ id: uuid(7), name: u.searchParams.get('username') })); } else { res.writeHead(204); res.end(); } });
  await new Promise(r => mock.listen(0, r)); const mp = mock.address().port;
  const { p, port } = await startServer({ MOB_INSECURE_AUTH: '', MOB_MOJANG_SESSION: `http://127.0.0.1:${mp}`, MOB_ELYBY_SESSION: `http://127.0.0.1:${mp}` });
  const bad = new Client(port, 'microsoft', 'Mallory', 7); assert.equal((await bad.login()).code, 'auth_failed');
  const ok = new Client(port, 'elyby', 'Eve', 7);
  const h = await ok.type('hello'); good.add(`Eve:${h.challenge}`); ok.send({ t: 'auth', provider: 'elyby', username: 'Eve', uuid: uuid(7) });
  assert.equal((await ok.next(m => m.t === 'authed' || m.t === 'error')).t, 'authed');
  const spoof = new Client(port, 'elyby', 'Eve', 8); const h2 = await spoof.type('hello'); good.add(`Eve:${h2.challenge}`); spoof.send({ t: 'auth', provider: 'elyby', username: 'Eve', uuid: uuid(8) });
  assert.equal((await spoof.next(m => m.t === 'authed' || m.t === 'error')).code, 'auth_failed', 'uuid mismatch rejected');
  ok.close(); p.kill(); mock.close();
});

test('curseforge proxy keeps the key on the server', async () => {
  let seen = null; let n = 0;
  const up = http.createServer((req, res) => { n++; seen = { key: req.headers['x-api-key'], url: req.url }; res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ data: [{ id: 1 }] })); });
  await new Promise(r => up.listen(0, r));
  const { p, port } = await startServer({ CURSEFORGE_KEY: 'SECRET', CF_UPSTREAM: `http://127.0.0.1:${up.address().port}` });
  const get = (path) => fetch(`http://127.0.0.1:${port}${path}`).then(async r => ({ s: r.status, j: await r.json().catch(() => null) }));
  assert.equal((await get('/cf-status')).j.enabled, true);
  const r1 = await get('/cf/v1/mods/search?gameId=432&searchFilter=sodium'); assert.equal(r1.s, 200); assert.equal(seen.key, 'SECRET'); assert.match(seen.url, /^\/v1\/mods\/search\?gameId=432/);
  await get('/cf/v1/mods/search?gameId=432&searchFilter=sodium'); assert.equal(n, 1, 'second identical request served from cache');
  assert.equal((await get('/cf/v1/games')).s, 404, 'only whitelisted endpoints');
  p.kill();
  const off = await startServer({}); const r = await fetch(`http://127.0.0.1:${off.port}/cf-status`).then(x => x.json()); assert.equal(r.enabled, false); off.p.kill(); up.close();
});
