# MobLauncher

A fast, clean, open-source launcher for **Minecraft: Java Edition**.

![Play](docs/1-play.png)

## Features
- **Builds (instances)** with their own folders — Vanilla, Fabric, Quilt, Forge, NeoForge
- **All Minecraft versions**, Java is downloaded automatically
- **Built-in mod browser** — mods, resource packs, shaders, modpacks (Modrinth, CurseForge) with descriptions and images
- **Mod update checker**
- **Accounts:** Microsoft, Ely.by, offline
- **3D avatar** viewer, skins and capes
- **Server list** with online status, ping and one-click join
- **Friends, chat and voice calls** (needs a friends server, see `server/`)
- **Self-repair** and crash analysis
- RAM sliders (MiB and GiB) with warnings, many languages, English by default

| Builds | Mod browser |
|---|---|
| ![Builds](docs/2-builds.png) | ![Browser](docs/5-browser.png) |

| Avatar | Servers |
|---|---|
| ![Avatar](docs/7-avatar.png) | ![Servers](docs/8b-servers.png) |

## Install
Download **MobLauncher-Setup-Offline.exe** from the [Releases](../../releases) page and run it.
Windows may show a SmartScreen warning because the app is not code-signed: click *More info → Run anyway*.

## Build from source
Requires Node.js 20+. Run `build-all.bat` (Windows) or see `installer/` and `launcher/`.

## Friends server (optional)
See [docs/PUBLISHING.md](docs/PUBLISHING.md) and `server/README.md`.

## License
MIT. 

> Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft.
