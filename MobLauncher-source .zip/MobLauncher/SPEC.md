# MobLauncher – shared spec (contract between launcher / installer / server)

Project root: /home/claude/MobLauncher
- `launcher/`  Electron app (the launcher)
- `installer/` Electron app (custom animated installer, builds to a Windows EXE)
- `server/`    Node.js WebSocket server for friends / chat / calls
- `shared/assets/` logo.svg, icon.png, icon.ico, fonts/ (Outfit, Inter, JetBrains Mono – woff2, latin)

## Design language (all UIs)
Dark + green, "glass" panels, soft glows, lots of tasteful motion (but 60fps, no jank; use transform/opacity only,
respect `prefers-reduced-motion`). Original look – do NOT imitate Mojang/Minecraft art, no creeper, no Mojang logos.
Tokens:
```
--bg-0:#050a07; --bg-1:#0a120d; --bg-2:#0f1b14; --bg-3:#15261c;
--panel:rgba(18,32,24,.72); --line:rgba(120,255,170,.12); --line-2:rgba(120,255,170,.22);
--green:#34d27b; --green-2:#22c55e; --green-3:#86efac; --green-4:#14532d; --glow:rgba(52,210,123,.45);
--text:#e8fff0; --muted:#86a493; --danger:#ff5d6c; --warn:#ffc857;
radius: 14px / 10px; fonts: "Outfit Variable" (headings), "Inter Variable" (body), "JetBrains Mono" (numbers/code)
```
Fonts are local files (no network): `@font-face` with `src:url(...woff2)`.
Language of UI: English by default (launcher has an i18n system, many languages later).

## Account choice / bootstrap (installer -> launcher)
The installer asks "How do you want to play?": Offline account (username), Microsoft, Ely.by.
It writes JSON to `<dataDir>/bootstrap.json`:
```json
{ "accountChoice": "offline" | "microsoft" | "elyby", "offlineName": "Steve" , "createdBy": "installer", "version": 1 }
```
and, ONLY if user picked a custom *data* folder, writes `<installDir>/moblauncher.config.json`: `{ "dataDir": "D:\\Games\\MobLauncher" }`.
Default `dataDir` = `%APPDATA%\MobLauncher` (Windows). The launcher reads `moblauncher.config.json` next to its exe, else the default.
Launcher consumes bootstrap.json on first start (creates the offline account or opens the Microsoft / Ely.by login) and renames it to `bootstrap.done.json`.

## Installer payload contract
Launcher is distributed as `MobLauncher-win-x64.zip` = the contents of electron-builder `win-unpacked` (MobLauncher.exe at zip root).
Installer installs it into `<installDir>` (default `%LOCALAPPDATA%\Programs\MobLauncher`), creates shortcuts
(Desktop optional, Start Menu), registers uninstall entry in HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\MobLauncher,
and drops an uninstaller (copy of the installer exe run with `--uninstall`).

## Friends server protocol (WebSocket, JSON text frames, one object per frame)
Every message: `{ "t": "<type>", ...fields }`. Client requests may carry `"rid": "<string>"`; server replies to those with `"rid"` echoed
(`{t:"ok",rid}` or `{t:"error",rid,code,message}`) unless the reply is a typed message listed below (which then also echoes rid).

### Identity / auth (Yggdrasil session proof, works for Microsoft and Ely.by)
1. On connect server sends `{t:"hello", challenge:"<32 hex>", protocol:1, serverName:"...", sessionServers:{microsoft:"https://sessionserver.mojang.com", elyby:"https://authserver.ely.by"}}`.
2. The client's main process calls the provider's session `join` with its own access token and `serverId = challenge`:
   - Microsoft: `POST https://sessionserver.mojang.com/session/minecraft/join` body `{accessToken, selectedProfile:<uuid no dashes>, serverId}`
   - Ely.by: `POST https://authserver.ely.by/session/join` same body.
3. Client sends `{t:"auth", provider:"microsoft"|"elyby", username, uuid /*no dashes*/}`.
4. Server verifies with `GET <sessionServer>/session/minecraft/hasJoined?username=<name>&serverId=<challenge>` (Microsoft, sessionserver.mojang.com) or
   `GET https://authserver.ely.by/session/hasJoined?username=<name>&serverId=<challenge>` (Ely.by). 200 + JSON `{id,name}` = ok (id must equal uuid).
   Env `MOB_INSECURE_AUTH=1` skips verification (dev/tests only).
5. Success: `{t:"authed", user:{id:"<provider>:<uuid>", name, uuid, provider}, friends:[Friend], incoming:[UserRef], outgoing:[UserRef], unread:{<userId>:count}}`.
   Failure: `{t:"error", code:"auth_failed", message}` then close.
`UserRef = {id,name,uuid,provider}`; `Friend = UserRef & {online:bool, presence:Presence|null, lastSeen:number}`.
Offline accounts can never connect (no identity).

### Presence
Client -> `{t:"presence", status:"online"|"away"|"dnd", playing: null | {instance:"My Pack", mcVersion:"1.20.1", loader:"fabric"|"forge"|"neoforge"|"quilt"|"vanilla", loaderVersion:"0.15.0", server:"host:port"|null, mods:[{id:"modrinth:<projectId>"|"curseforge:<projectId>"|"file:<filename>", name:"Sodium", version:"0.5.8", sha1:"..."}] }}`.
Server -> friends `{t:"presence", user:UserRef, online:bool, presence:Presence|null, lastSeen}` (also pushed when a friend connects/disconnects).
Presence = the object above. Server stores last presence while the user is online; mods list may be large (accept up to 1.5 MB frames, 2000 mods).

### Friends
- `{t:"search", q:"nick"}` -> `{t:"search.result", users:[UserRef&{online:bool}]}` (prefix/substring, case-insens., known users only, max 20, excluding self).
- `{t:"friend.request", to:userId}` -> `{t:"ok"}`; target gets `{t:"friend.incoming", from:UserRef}`. If target already requested us -> auto-accept.
- `{t:"friend.accept", from:userId}` / `{t:"friend.decline", from:userId}` / `{t:"friend.cancel", to:userId}` / `{t:"friend.remove", user:userId}`
- Server pushes `{t:"friend.added", friend:Friend}`, `{t:"friend.removed", user:userId}`, `{t:"friend.incoming", from}`, `{t:"friend.outgoing", to}`, `{t:"friend.request.cancelled", user:userId}`.
- Limits: 200 friends, 100 pending requests.

### Chat (friends only)
- `{t:"msg", to:userId, text}` (<= 2000 chars) -> server echoes `{t:"msg", id, from:userId, to:userId, text, ts}` to BOTH sender (all its connections) and recipient; if recipient offline it is stored and counted as unread.
- `{t:"history", with:userId, before?:ts, limit?:50}` -> `{t:"history", with, messages:[{id,from,to,text,ts}]}` oldest first.
- `{t:"read", with:userId}` marks read. `{t:"typing", to:userId}` is relayed as `{t:"typing", from}`.
- History kept per pair, last 500 messages.

### Invites (join a friend through Minecraft)
`{t:"invite", to:userId, payload:{...}}` relayed as `{t:"invite", from:UserRef, payload, ts}` (payload = a Presence.playing-like object). 

### Calls (voice, WebRTC signalling only – media is peer to peer)
`{t:"call.invite", to}` -> callee gets `{t:"call.invite", from:UserRef}`; `{t:"call.accept", to}`, `{t:"call.decline", to}`, `{t:"call.end", to}`,
`{t:"call.signal", to, data:<any JSON (SDP/ICE)>}` relayed as `{t:"call.signal", from:userId, data}`. Relayed events: `call.accepted {from}`, `call.declined {from}`, `call.ended {from}`, `call.invite {from}`.
If callee offline -> `{t:"error", code:"offline"}`.

### Misc
- `{t:"ping"}` -> `{t:"pong"}`; server also WebSocket-pings every 25 s and drops dead sockets.
- Same account may have several connections; events go to all of them.
- HTTP GET `/health` -> `{ok:true, users:n, online:n}`.
- Persistence: JSON file (path from `MOB_DATA`, default ./data/db.json), atomic write, debounced.
- Rate limiting: max ~30 msgs/sec per connection burst, chat 5/sec; otherwise `{t:"error",code:"rate_limited"}`.
- Env: `PORT` (default 8787), `MOB_DATA`, `MOB_INSECURE_AUTH`.

### Additions (v1.1)
- `presence` may carry `hours` (number|null, total play hours) and `hideActivity` (bool: broadcast no `playing`). `UserRef` gains `hours`.
- `{t:"profile", user:userId}` -> `{t:"profile", user:UserRef&{online,lastSeen,isFriend,presence,friends}}` (presence only for friends).
