# Publishing MobLauncher

1. Create a GitHub repo named `MobLauncher` (public). Upload everything in this folder (`git init && git add . && git commit -m "MobLauncher" && git push`).
2. Repo → Settings → *Topics*: `minecraft`, `minecraft-launcher`, `electron`, `modrinth`, `curseforge`, `fabric`, `neoforge`, `ely-by`.
3. Deploy `server/` once (Render: "New → Blueprint" uses `render.yaml`). Optional env var `CURSEFORGE_KEY` (free key from console.curseforge.com) makes CurseForge work for everyone.
4. Repo → Settings → Secrets → Actions: `FRIENDS_SERVER` (`wss://your-app.onrender.com`), optional `MS_CLIENT_ID`.
5. Release: `git tag v1.0.0 && git push --tags` — Actions builds the installer EXE and attaches it to a Release.
6. Add screenshots/a short demo video to the README, and the disclaimer: *Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft.*

## Getting popular
- Great README with GIF/video at the top; a Releases page with a clear download button.
- Post on r/Minecraft (self-promo days), r/admincraft, r/feedthebeast, Modrinth/Planet Minecraft forums, Discord communities, YouTube/TikTok demos.
- Be honest and specific about what makes it different (friends + calls + built-in mod browser). Never advertise "free Minecraft".
- Reply to issues fast, label `good first issue`, add CONTRIBUTING notes.

## Friends server in 3 clicks (Render, free)
1. Push this repo to GitHub. 2. On render.com → New → Blueprint → pick the repo (it reads `render.yaml`). 3. Copy the URL Render gives you (`https://xxx.onrender.com`) and use it as `wss://xxx.onrender.com` in `build-all.bat` / the `FRIENDS_SERVER` secret.
