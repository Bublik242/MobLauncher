'use strict';
/**
 * MobLauncher Setup – main process.
 *
 * Contract with the launcher (see README.md):
 *   <dir>/MobLauncher.exe            copy of this installer's own Electron runtime
 *   <dir>/resources/app/...          contents of payload.zip (launcher app code)
 *   <APPDATA>/MobLauncher/firstrun.json   {"account":"offline","nick":"Steve"} | {"account":"microsoft"} | {"account":"ely"}
 */
const { app, BrowserWindow, ipcMain, dialog, shell, net } = require('electron');
const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const os = require('os');
const crypto = require('crypto');
const { spawn, execFile } = require('child_process');
const AdmZip = require('adm-zip');
const brand = require('./brand.json');

const IS_WIN = process.platform === 'win32';
const SRC_DIR = path.dirname(process.execPath); // our own Electron runtime
const EXE_NAME = IS_WIN ? 'MobLauncher.exe' : 'MobLauncher';
const NICK_RE = /^[A-Za-z0-9_]{3,16}$/;
const MB = 1024 * 1024;

const argv = process.argv.slice(1);
const shotsIdx = argv.indexOf('--screenshots');
const SHOTS_DIR = shotsIdx >= 0 ? path.resolve(argv[shotsIdx + 1] || 'shots') : process.env.MOB_SHOTS ? path.resolve(process.env.MOB_SHOTS) : '';

if (!SHOTS_DIR && !app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }
app.setAppUserModelId('com.moblauncher.setup');
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const slash = (p) => p.split(path.sep).join('/');

class InstallError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}

// ------------------------------------------------------------------ paths & checks
function defaultDir() {
  if (process.env.MOB_TEST_INSTALL_DIR) return path.resolve(process.env.MOB_TEST_INSTALL_DIR);
  if (IS_WIN) {
    const local = process.env.LOCALAPPDATA || path.join(app.getPath('home'), 'AppData', 'Local');
    return path.join(local, 'Programs', 'MobLauncher');
  }
  return path.join(os.homedir(), '.local', 'share', 'MobLauncher-app');
}

const mobHome = () => process.env.MOB_HOME || path.join(app.getPath('appData'), 'MobLauncher');

/** Files of our runtime that must NOT end up in the installed launcher. */
function skipRuntime(rel) {
  const r = slash(rel).toLowerCase();
  const base = r.split('/').pop();
  if (r === 'resources/app.asar' || r.startsWith('resources/app.asar.unpacked')) return true;
  if (r === 'resources/app-update.yml' || r === 'resources/default_app.asar' || r === 'resources/elevate.exe') return true;
  if (r === 'resources/app' || r.startsWith('resources/app/')) return true; // dev: installer's own sources
  if (base.startsWith('moblauncher-setup')) return true;
  return false;
}

let runtimeCache = null;
function runtimeFiles() {
  if (runtimeCache) return runtimeCache;
  const out = [];
  const selfName = path.basename(process.execPath);
  (function walk(dir, rel) {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const r = rel ? rel + '/' + e.name : e.name;
      const abs = path.join(dir, e.name);
      if (e.isDirectory()) { if (!skipRuntime(r)) walk(abs, r); continue; }
      let st;
      try { st = fs.statSync(abs); } catch { continue; }
      if (!st.isFile()) continue;
      if (rel === '' && e.name === selfName) { out.push({ rel: EXE_NAME, abs, size: st.size, mode: st.mode }); continue; }
      if (skipRuntime(r)) continue;
      out.push({ rel: r, abs, size: st.size, mode: st.mode });
    }
  })(SRC_DIR, '');
  runtimeCache = out;
  return out;
}

function payloadCandidates() {
  const list = [];
  if (process.env.MOB_PAYLOAD_FILE) list.push(process.env.MOB_PAYLOAD_FILE);
  if (process.env.PORTABLE_EXECUTABLE_DIR) list.push(path.join(process.env.PORTABLE_EXECUTABLE_DIR, 'payload.zip'));
  list.push(path.join(SRC_DIR, 'payload.zip'));
  list.push(path.join(process.resourcesPath || SRC_DIR, 'payload.zip'));
  list.push(path.join(app.getAppPath(), 'payload', 'payload.zip'));
  return list;
}
function findLocalPayload() {
  for (const f of payloadCandidates()) {
    try { if (fs.statSync(f).isFile()) return f; } catch { /* next */ }
  }
  return '';
}
const payloadUrl = () => (process.env.MOB_PAYLOAD_URL || brand.payloadUrl || '').trim();

function requiredBytes() {
  const rt = runtimeFiles().reduce((a, f) => a + f.size, 0);
  let pl = 40 * MB;
  const local = findLocalPayload();
  if (local) { try { pl = fs.statSync(local).size; } catch { /* default */ } }
  return rt + pl * 3 + 20 * MB; // runtime + zip + extracted code + slack
}

function nearestExisting(p) {
  let cur = p;
  for (let i = 0; i < 64; i++) {
    if (fs.existsSync(cur)) return cur;
    const up = path.dirname(cur);
    if (up === cur) break;
    cur = up;
  }
  return cur;
}

function isMobInstall(dir) {
  return fs.existsSync(path.join(dir, EXE_NAME)) || fs.existsSync(path.join(dir, 'resources', 'app', 'package.json'));
}

function validateDir(input) {
  const dir = String(input || '').trim().replace(/^"(.*)"$/, '$1');
  const requiredMB = Math.ceil(requiredBytes() / MB);
  const fail = (code, error, extra = {}) => ({ ok: false, code, error, requiredMB, ...extra });
  if (!dir) return fail('EMPTY', 'Choose an installation folder.');
  if (!path.isAbsolute(dir)) return fail('RELATIVE', IS_WIN ? 'Enter a full path, for example C:\\Games\\MobLauncher.' : 'Enter a full path.');
  const resolved = path.resolve(dir);
  if (path.parse(resolved).root === resolved) return fail('ROOT', 'Pick a folder, not a whole drive.');
  if (IS_WIN && /[<>:"|?*]/.test(resolved.slice(2))) return fail('CHARS', 'The path contains characters Windows does not allow.');
  if (resolved.length > 200) return fail('LONG', 'That path is too long. Choose a shorter one.');
  const rel = path.relative(SRC_DIR, resolved);
  if (rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel))) return fail('SELF', 'Choose a different folder.');

  let existing = false;
  try {
    const st = fs.statSync(resolved);
    if (!st.isDirectory()) return fail('FILE', 'That path points to a file, not a folder.');
    existing = true;
  } catch { /* will be created */ }
  const mine = existing && isMobInstall(resolved);
  const testDir = process.env.MOB_TEST_INSTALL_DIR && path.resolve(process.env.MOB_TEST_INSTALL_DIR) === resolved;
  if (existing && !mine && !testDir) {
    let n = 0;
    try { n = fs.readdirSync(resolved).length; } catch { return fail('READ', 'This folder cannot be read.'); }
    if (n > 0) return fail('NOTEMPTY', 'This folder is not empty. Choose an empty folder or a new one.');
  }
  const anc = nearestExisting(resolved);
  try { fs.accessSync(anc, fs.constants.W_OK); } catch { return fail('NOWRITE', 'You do not have permission to write there.'); }
  let freeMB = null;
  try {
    const s = fs.statfsSync(anc);
    freeMB = Math.floor((Number(s.bavail) * Number(s.bsize)) / MB);
  } catch { /* unknown */ }
  if (freeMB !== null && freeMB < requiredMB) return fail('SPACE', `Not enough free space: about ${requiredMB} MB needed, ${freeMB} MB available.`, { freeMB });
  return { ok: true, resolved, freeMB, requiredMB, update: mine };
}

// ------------------------------------------------------------------ install
let current = null; // running install context

function mapFsError(e) {
  if (e instanceof InstallError) return e;
  switch (e && e.code) {
    case 'EBUSY': case 'ETXTBSY': return new InstallError('BUSY', 'A MobLauncher file is in use. Close MobLauncher and Minecraft, then press Retry.');
    case 'ENOSPC': return new InstallError('SPACE', 'The disk is full. Free some space and press Retry.');
    case 'EACCES': case 'EPERM': return new InstallError('PERM', 'Windows blocked writing to that folder. Pick another folder or close programs using it.');
    case 'ENOENT': return new InstallError('IO', 'A file disappeared during installation (' + (e.path ? path.basename(e.path) : 'unknown') + '). Press Retry.');
    default: return new InstallError('UNKNOWN', 'Installation failed: ' + ((e && e.message) || e));
  }
}

async function withRetry(fn) {
  for (let i = 0; ; i++) {
    try { return await fn(); } catch (e) {
      if (['EBUSY', 'EPERM', 'EACCES', 'ETXTBSY'].includes(e && e.code) && i < 3) { await sleep(400 * (i + 1)); continue; }
      throw e;
    }
  }
}

async function downloadPayload(ctx, url, dest, seg) {
  ctx.phase('download', seg[0], 'Downloading launcher…');
  let res;
  try {
    res = await net.fetch(url, { signal: ctx.abort.signal, redirect: 'follow', headers: { 'User-Agent': 'MobLauncher-Setup/' + brand.version } });
  } catch (e) {
    if (ctx.cancelled) throw new InstallError('CANCELLED', 'Cancelled');
    throw new InstallError('NETWORK', 'Could not reach the download server. Check your internet connection and press Retry.');
  }
  if (!res.ok) throw new InstallError('HTTP', `The download server answered with error ${res.status}. Try again later.`);
  const total = Number(res.headers.get('content-length')) || 0;
  const hash = crypto.createHash('sha256');
  const out = fs.createWriteStream(dest);
  let got = 0;
  let lastT = Date.now();
  let lastB = 0;
  let speed = 0;
  try {
    const reader = res.body.getReader();
    for (;;) {
      ctx.check();
      const { done, value } = await reader.read();
      if (done) break;
      hash.update(value);
      got += value.length;
      if (!out.write(value)) await new Promise((r) => out.once('drain', r));
      const now = Date.now();
      if (now - lastT >= 300) { speed = ((got - lastB) / (now - lastT)) * 1000; lastT = now; lastB = got; }
      const frac = total ? got / total : Math.min(0.9, got / (40 * MB));
      ctx.progress({ phase: 'download', pct: seg[0] + (seg[1] - seg[0]) * frac, text: 'Downloading launcher…', bytes: { got, total }, speed });
    }
  } catch (e) {
    out.destroy();
    if (ctx.cancelled || (e && e.name === 'AbortError')) throw new InstallError('CANCELLED', 'Cancelled');
    if (e instanceof InstallError) throw e;
    throw new InstallError('NETWORK', 'The download was interrupted. Check your internet connection and press Retry.');
  }
  await new Promise((r, j) => { out.end(); out.on('finish', r); out.on('error', j); });
  const want = (process.env.MOB_PAYLOAD_SHA256 || brand.payloadSha256 || '').trim().toLowerCase();
  if (want && hash.digest('hex') !== want) throw new InstallError('HASH', 'The downloaded file is damaged (checksum mismatch). Press Retry.');
}

async function extractPayload(ctx, zipPath, appDir, seg) {
  ctx.phase('install', seg[0], 'Extracting launcher files…');
  let zip;
  try { zip = new AdmZip(zipPath); } catch { throw new InstallError('ZIP', 'The launcher package is damaged. Re-download the installer.'); }
  const entries = zip.getEntries().filter((e) => !e.isDirectory);
  if (!entries.length) throw new InstallError('ZIP', 'The launcher package is empty.');
  // tolerate one wrapping folder
  let strip = '';
  if (!entries.some((e) => e.entryName === 'package.json')) {
    const first = entries[0].entryName.split('/')[0] + '/';
    if (entries.every((e) => e.entryName.startsWith(first)) && entries.some((e) => e.entryName === first + 'package.json')) strip = first;
    else throw new InstallError('ZIP', 'The launcher package has an unexpected layout (package.json not found).');
  }
  await withRetry(() => fsp.rm(appDir, { recursive: true, force: true }));
  await fsp.mkdir(appDir, { recursive: true });
  const base = path.resolve(appDir) + path.sep;
  let i = 0;
  for (const e of entries) {
    ctx.check();
    const rel = e.entryName.slice(strip.length);
    const target = path.resolve(appDir, rel);
    if (!target.startsWith(base)) continue; // zip-slip guard
    await fsp.mkdir(path.dirname(target), { recursive: true });
    const data = e.getData();
    await withRetry(() => fsp.writeFile(target, data));
    ctx.written.push(target);
    i++;
    if (i % 25 === 0) {
      ctx.progress({ phase: 'install', pct: seg[0] + (seg[1] - seg[0]) * (i / entries.length), text: 'Extracting launcher files…', files: { done: i, total: entries.length } });
      await sleep(0);
    }
  }
}

async function copyRuntime(ctx, dir, seg) {
  ctx.phase('install', seg[0], 'Installing files…');
  const files = runtimeFiles();
  const totalBytes = files.reduce((a, f) => a + f.size, 0) || 1;
  let doneBytes = 0;
  let n = 0;
  let lastSend = 0;
  for (const f of files) {
    ctx.check();
    const dst = path.join(dir, f.rel);
    await fsp.mkdir(path.dirname(dst), { recursive: true });
    await withRetry(async () => {
      await fsp.copyFile(f.abs, dst);
      if (!IS_WIN) await fsp.chmod(dst, f.mode & 0o7777);
    });
    ctx.written.push(dst);
    doneBytes += f.size;
    n++;
    const now = Date.now();
    if (now - lastSend > 60) {
      lastSend = now;
      ctx.progress({ phase: 'install', pct: seg[0] + (seg[1] - seg[0]) * (doneBytes / totalBytes), text: 'Installing files…', files: { done: n, total: files.length } });
      await sleep(0);
    }
  }
}

function runReg(args) {
  return new Promise((resolve) => execFile('reg', args, { windowsHide: true }, () => resolve()));
}

async function createShortcuts(ctx, dir, exe, opts) {
  ctx.phase('shortcuts', 94, 'Creating shortcuts…');
  if (IS_WIN) {
    const make = (file) => {
      fs.mkdirSync(path.dirname(file), { recursive: true });
      shell.writeShortcutLink(file, 'create', { target: exe, cwd: dir, icon: opts.icon || exe, iconIndex: 0, description: 'MobLauncher' });
      ctx.written.push(file);
    };
    if (opts.desktop) make(path.join(app.getPath('desktop'), 'MobLauncher.lnk'));
    if (opts.startMenu) make(path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'MobLauncher', 'MobLauncher.lnk'));
    ctx.progress({ phase: 'shortcuts', pct: 97, text: 'Registering uninstaller…' });
    const key = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MobLauncher';
    const add = (name, value, type = 'REG_SZ') => runReg(['add', key, '/v', name, '/t', type, '/d', String(value), '/f']);
    await add('DisplayName', 'MobLauncher');
    await add('DisplayVersion', brand.version);
    await add('Publisher', 'MobLauncher');
    await add('InstallLocation', dir);
    await add('DisplayIcon', opts.icon || exe);
    await add('UninstallString', `"${exe}" --uninstall`);
    await add('NoModify', 1, 'REG_DWORD');
    await add('NoRepair', 1, 'REG_DWORD');
  }
}

function writeFirstRun(opts) {
  const home = mobHome();
  fs.mkdirSync(home, { recursive: true });
  const data = { account: opts.account };
  if (opts.account === 'offline') data.nick = opts.nick;
  fs.writeFileSync(path.join(home, 'firstrun.json'), JSON.stringify(data));
}

async function cleanup(ctx) {
  try { if (ctx.tmp) await fsp.rm(ctx.tmp, { recursive: true, force: true }); } catch { /* ignore */ }
}

async function rollback(ctx) {
  await cleanup(ctx);
  try {
    if (!ctx.preexisted) await fsp.rm(ctx.dir, { recursive: true, force: true });
    else for (const f of ctx.written) await fsp.rm(f, { force: true });
  } catch { /* best effort */ }
  try { fs.rmSync(path.join(mobHome(), 'firstrun.json'), { force: true }); } catch { /* ignore */ }
}

async function runInstall(opts, send) {
  if (current) return { ok: false, code: 'BUSY_INSTALL', message: 'An installation is already running.' };
  const account = ['offline', 'microsoft', 'ely'].includes(opts.account) ? opts.account : 'offline';
  const nick = String(opts.nick || '').trim();
  if (account === 'offline' && !NICK_RE.test(nick)) return { ok: false, code: 'NICK', message: 'The nickname must be 3-16 letters, digits or underscores.' };
  const v = validateDir(opts.dir);
  if (!v.ok) return { ok: false, code: v.code, message: v.error };

  const ctx = {
    dir: v.resolved, preexisted: fs.existsSync(v.resolved), written: [], cancelled: false, abort: new AbortController(), tmp: '',
    last: 0,
    check() { if (this.cancelled) throw new InstallError('CANCELLED', 'Cancelled'); },
    progress(p) {
      const now = Date.now();
      if (p.force || now - this.last > 70) { this.last = now; send({ ...p, pct: Math.min(100, Math.max(0, p.pct)) }); }
    },
    phase(phase, pct, text) { this.last = 0; this.progress({ phase, pct, text, force: true }); },
  };
  current = ctx;
  try {
    ctx.phase('prepare', 0, 'Preparing…');
    await sleep(350);
    ctx.check();
    await fsp.mkdir(ctx.dir, { recursive: true });

    // 1. get the launcher package
    let zipPath = findLocalPayload();
    let segExtract; let segCopy;
    if (zipPath) {
      ctx.phase('download', 4, 'Using the bundled launcher package…');
      await sleep(500);
      segExtract = [8, 24]; segCopy = [24, 94];
    } else {
      const url = payloadUrl();
      if (!url) throw new InstallError('NO_PAYLOAD', 'The installer has no launcher package to install: payload.zip is missing and no download address is configured.');
      ctx.tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'moblauncher-setup-'));
      zipPath = path.join(ctx.tmp, 'payload.zip');
      await downloadPayload(ctx, url, zipPath, [4, 52]);
      segExtract = [52, 66]; segCopy = [66, 94];
    }
    ctx.check();

    // 2. launcher code, then runtime
    await extractPayload(ctx, zipPath, path.join(ctx.dir, 'resources', 'app'), segExtract);
    await copyRuntime(ctx, ctx.dir, segCopy);
    ctx.check();

    // 3. shortcuts, registry, first-run hand-off
    const exe = path.join(ctx.dir, EXE_NAME);
    // the runtime exe keeps Electron's stock icon (no wine/rcedit at build time), so ship a standalone .ico for shortcuts
    let icon = exe;
    try {
      const ico = path.join(ctx.dir, 'MobLauncher.ico');
      await fsp.writeFile(ico, await fsp.readFile(path.join(__dirname, 'assets', 'icon.ico')));
      ctx.written.push(ico);
      icon = ico;
    } catch { /* fall back to the exe icon */ }
    await createShortcuts(ctx, ctx.dir, exe, { desktop: !!opts.desktop, startMenu: !!opts.startMenu, icon });
    writeFirstRun({ account, nick });
    await cleanup(ctx);
    ctx.phase('done', 100, 'Done');
    current = null;
    installedExe = exe;
    installedDir = ctx.dir;
    return { ok: true, dir: ctx.dir, exe };
  } catch (e) {
    const err = mapFsError(e);
    current = null;
    if (err.code === 'CANCELLED') { await rollback(ctx); return { ok: false, cancelled: true, code: 'CANCELLED', message: 'Cancelled' }; }
    await cleanup(ctx);
    if (!ctx.preexisted) { try { await fsp.rm(ctx.dir, { recursive: true, force: true }); } catch { /* ignore */ } }
    return { ok: false, code: err.code, message: err.message };
  }
}

let installedExe = '';
let installedDir = '';

// ------------------------------------------------------------------ window + ipc
let win = null;
const send = (p) => { if (win && !win.isDestroyed()) win.webContents.send('progress', p); };

function createWindow() {
  win = new BrowserWindow({
    width: 620, height: 440, resizable: false, maximizable: false, fullscreenable: false,
    frame: false, transparent: true, backgroundColor: '#00000000', show: false, hasShadow: false,
    title: 'MobLauncher Setup', icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false, devTools: !app.isPackaged,
    },
  });
  win.removeMenu();
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  win.on('closed', () => { win = null; });
}

ipcMain.handle('getDefaults', () => ({
  dir: defaultDir(), platform: process.platform, version: brand.version, name: brand.name,
  requiredMB: Math.ceil(requiredBytes() / MB), hasLocal: !!findLocalPayload(), hasUrl: !!payloadUrl(),
}));
ipcMain.handle('validateDir', (_e, dir) => validateDir(dir));
ipcMain.handle('pickFolder', async (_e, start) => {
  const r = await dialog.showOpenDialog(win, { title: 'Choose where to install MobLauncher', defaultPath: start || defaultDir(), properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled || !r.filePaths[0]) return '';
  let p = r.filePaths[0];
  // a non-empty, unrelated folder gets its own "MobLauncher" subfolder
  try {
    if (fs.readdirSync(p).length && !isMobInstall(p) && path.basename(p).toLowerCase() !== 'moblauncher') p = path.join(p, 'MobLauncher');
  } catch { /* ignore */ }
  return p;
});
ipcMain.handle('install', (_e, opts) => runInstall(opts || {}, send));
ipcMain.handle('cancel', () => { if (current) { current.cancelled = true; current.abort.abort(); } return true; });
ipcMain.handle('launch', () => {
  try {
    if (installedExe && fs.existsSync(installedExe)) spawn(installedExe, [], { detached: true, stdio: 'ignore', cwd: installedDir, windowsHide: false }).unref();
  } catch { /* the user can start it from the shortcut */ }
  setTimeout(() => app.quit(), 150);
  return true;
});
ipcMain.handle('quit', () => { if (current) { current.cancelled = true; current.abort.abort(); } setTimeout(() => app.quit(), 250); return true; });
ipcMain.handle('minimize', () => { if (win) win.minimize(); return true; });

// ------------------------------------------------------------------ screenshots (dev)
async function takeShots(dir) {
  fs.mkdirSync(dir, { recursive: true });
  const wc = win.webContents;
  const run = (code) => wc.executeJavaScript(code);
  const snap = async (name, wait = 1100) => {
    await sleep(wait);
    const img = await wc.capturePage();
    fs.writeFileSync(path.join(dir, name + '.png'), img.toPNG());
    console.log('shot', name);
  };
  await run('window.__shot.step("welcome")'); await snap('1-welcome', 1400);
  await run('window.__shot.step("account")'); await snap('2a-account-offline');
  await run('window.__shot.pick("microsoft")'); await snap('2b-account-microsoft', 800);
  await run('window.__shot.pick("offline"); window.__shot.nick("a!")'); await snap('2c-account-invalid', 800);
  await run('window.__shot.nick("Steve"); window.__shot.step("location")'); await snap('3-location');
  await run('window.__shot.step("install"); window.__shot.fake({phase:"download",pct:34,text:"Downloading launcher…",bytes:{got:13e6,total:38e6},speed:3.4e6})'); await snap('4a-installing-download', 900);
  await run('window.__shot.fake({phase:"install",pct:71,text:"Installing files…",files:{done:212,total:301}})'); await snap('4b-installing-files', 700);
  await run('window.__shot.error("NO_PAYLOAD","The installer has no launcher package to install: payload.zip is missing and no download address is configured.")'); await snap('4c-error', 900);
  await run('window.__shot.step("finish")'); await snap('5-finish', 1800);
  app.quit();
}

app.whenReady().then(() => {
  createWindow();
  if (SHOTS_DIR) {
    win.webContents.once('did-finish-load', () => { win.show(); takeShots(SHOTS_DIR).catch((e) => { console.error(e); app.exit(1); }); });
  }
});
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => app.quit());
