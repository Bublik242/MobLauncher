'use strict';
(function () {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const api = window.setup;

  // ------------------------------------------------------------ pixel logo (original art, same as the launcher cube)
  // isometric cube with a little pixel grain (original art)
  function logoSvg() {
    const grain = (pts, col) => pts.map(([x, y]) => `<rect x="${x}" y="${y}" width="3" height="3" fill="${col}"/>`).join('');
    return `<svg viewBox="0 0 64 64" shape-rendering="crispEdges">
      <polygon points="32,5 57,19 32,33 7,19" fill="#8cf09b"/>
      <polygon points="7,19 32,33 32,59 7,45" fill="#3ddc6b"/>
      <polygon points="57,19 32,33 32,59 57,45" fill="#1f9a4b"/>
      <polygon points="32,5 57,19 32,33 7,19" fill="none" stroke="#c8ffd2" stroke-width="1.2" stroke-linejoin="round"/>
      ${grain([[27, 14], [36, 18], [20, 19], [41, 22], [30, 24]], '#b9f7c2')}
      ${grain([[12, 31], [19, 40], [24, 34], [14, 45], [26, 48]], '#27b755')}
      ${grain([[38, 38], [47, 31], [51, 41], [42, 48], [38, 53]], '#177a3b')}
    </svg>`;
  }
  $$('[data-logo]').forEach((n) => { n.innerHTML = logoSvg(); });

  // ------------------------------------------------------------ rising cubes backdrop
  (function bg() {
    const cv = $('#bg');
    const ctx = cv.getContext('2d');
    let w = 0; let h = 0; let parts = []; let last = 0; let raf = 0;
    const spawn = (anywhere) => {
      const s = 8 + Math.random() * 34;
      return { x: Math.random() * w, y: anywhere ? Math.random() * h : h + s, s, v: 5 + Math.random() * 15, r: Math.random() * Math.PI, vr: (Math.random() - 0.5) * 0.3, a: 0.05 + Math.random() * 0.1 };
    };
    function resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = cv.clientWidth; h = cv.clientHeight;
      cv.width = Math.floor(w * dpr); cv.height = Math.floor(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      parts = Array.from({ length: 16 }, () => spawn(true));
    }
    function frame(t) {
      raf = requestAnimationFrame(frame);
      if (t - last < 32) return;
      const dt = Math.min((t - last) / 1000, 0.1);
      last = t;
      ctx.clearRect(0, 0, w, h);
      for (const p of parts) {
        p.y -= p.v * dt; p.r += p.vr * dt;
        if (p.y < -p.s * 2) Object.assign(p, spawn(false));
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r);
        ctx.fillStyle = `rgba(61,220,107,${p.a})`; ctx.fillRect(-p.s / 2, -p.s / 2, p.s, p.s);
        ctx.strokeStyle = `rgba(120,255,160,${p.a * 1.8})`; ctx.lineWidth = 1; ctx.strokeRect(-p.s / 2, -p.s / 2, p.s, p.s);
        ctx.restore();
      }
    }
    resize();
    document.addEventListener('visibilitychange', () => { cancelAnimationFrame(raf); if (!document.hidden) raf = requestAnimationFrame(frame); });
    raf = requestAnimationFrame(frame);
  })();

  // ------------------------------------------------------------ state
  const ORDER = ['welcome', 'account', 'location', 'install', 'finish'];
  const S = {
    step: 'welcome', account: 'offline', dirOk: false, installing: false, defaults: { dir: '', requiredMB: 0, hasLocal: false },
    vseq: 0, lastError: null, lastResult: null,
  };
  const NICK_RE = /^[A-Za-z0-9_]{3,16}$/;

  // dots
  $('#dots').innerHTML = ORDER.map(() => '<i></i>').join('');

  const fmtB = (b) => (b >= 1073741824 ? (b / 1073741824).toFixed(1) + ' GB' : b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB');
  const fmtMB = (mb) => (mb >= 1024 ? (mb / 1024).toFixed(1) + ' GB' : mb + ' MB');

  // ------------------------------------------------------------ navigation
  function nextEnabled() {
    if (S.step === 'account') return S.account !== 'offline' || NICK_RE.test($('#nick').value);
    if (S.step === 'location') return S.dirOk;
    return true;
  }
  function syncFooter() {
    const foot = $('#foot');
    foot.classList.toggle('hide', S.step === 'install');
    $('#btnBack').classList.toggle('off', S.step === 'welcome' || S.step === 'finish');
    $('#btnBack').disabled = S.step === 'welcome' || S.step === 'finish';
    $('#nextLbl').textContent = S.step === 'location' ? 'Install' : S.step === 'finish' ? 'Finish' : 'Next';
    $('#btnNext').disabled = !nextEnabled();
  }
  function go(name) {
    S.step = name;
    const idx = ORDER.indexOf(name);
    $$('.step').forEach((el) => {
      const i = ORDER.indexOf(el.dataset.step);
      el.classList.toggle('active', i === idx);
      el.classList.toggle('before', i < idx);
    });
    $$('#dots i').forEach((d, i) => { d.classList.toggle('on', i === idx); d.classList.toggle('done', i < idx); });
    syncFooter();
    if (name === 'account' && S.account === 'offline') setTimeout(() => { const n = $('#nick'); if (S.step === 'account') { n.focus(); n.select(); } }, 450);
    if (name === 'location') validateDir();
  }

  // ------------------------------------------------------------ account step
  function pickAccount(acc) {
    S.account = acc;
    $$('.acard').forEach((c) => { const on = c.dataset.acc === acc; c.classList.toggle('on', on); c.setAttribute('aria-checked', String(on)); });
    $('#nickPanel').hidden = acc !== 'offline';
    $('#notePanel').hidden = acc === 'offline';
    $('#noteText').textContent = acc === 'microsoft'
      ? 'You will sign in with your Microsoft account inside the launcher, right after installation.'
      : 'You will sign in with your Ely.by username and password inside the launcher, right after installation.';
    syncFooter();
  }
  function checkNick() {
    const v = $('#nick').value;
    const ok = NICK_RE.test(v);
    const input = $('#nick');
    input.classList.toggle('bad', !ok && v.length > 0);
    $('#nickState').className = 'nick-state ' + (ok ? 'ok' : v.length ? 'bad' : '');
    const hint = $('#nickHint');
    hint.classList.toggle('bad', !ok);
    hint.textContent = ok ? 'Looks good. This is the name other players will see.'
      : /[^A-Za-z0-9_]/.test(v) ? 'Only letters, digits and _ are allowed.' : '3-16 characters: letters, digits and _';
    syncFooter();
  }
  $('#cards').addEventListener('click', (e) => { const c = e.target.closest('.acard'); if (c) pickAccount(c.dataset.acc); });
  $('#nick').addEventListener('input', checkNick);

  // ------------------------------------------------------------ location step
  let vt = 0;
  function validateDir() {
    clearTimeout(vt);
    const seq = ++S.vseq;
    const msg = $('#dirMsg');
    msg.className = 'sp-msg wait'; msg.textContent = 'Checking…';
    S.dirOk = false; syncFooter();
    vt = setTimeout(async () => {
      const r = await api.validateDir($('#dir').value);
      if (seq !== S.vseq) return;
      $('#spReq').textContent = '~' + fmtMB(r.requiredMB);
      $('#spFree').textContent = r.freeMB == null ? 'Unknown' : fmtMB(r.freeMB);
      $('#dir').classList.toggle('bad', !r.ok && !!$('#dir').value);
      S.dirOk = !!r.ok;
      msg.className = 'sp-msg' + (r.ok ? '' : ' bad');
      msg.textContent = r.ok ? (r.update ? 'An existing MobLauncher will be updated' : 'Ready to install') : r.error;
      syncFooter();
    }, 220);
  }
  $('#dir').addEventListener('input', validateDir);
  $('#bBrowse').addEventListener('click', async () => {
    const p = await api.pickFolder($('#dir').value);
    if (p) { $('#dir').value = p; validateDir(); }
  });

  // ------------------------------------------------------------ install step
  const PHASES = ['prepare', 'download', 'install', 'shortcuts', 'done'];
  function setPhase(p) {
    const i = PHASES.indexOf(p);
    $$('#phases li').forEach((li, k) => { li.classList.toggle('done', k < i || p === 'done'); li.classList.toggle('on', k === i && p !== 'done'); });
    const title = p === 'prepare' || p === 'download'
      ? (S.defaults.hasLocal ? 'Installing MobLauncher…' : 'Downloading MobLauncher…')
      : p === 'done' ? 'All set!' : 'Installing MobLauncher…';
    $('#instTitle').textContent = title;
  }
  function paintProgress(e) {
    setPhase(e.phase);
    $('#pFill').style.width = e.pct.toFixed(1) + '%';
    $('#pPct').textContent = Math.floor(e.pct) + '%';
    $('#instText').textContent = e.text || '';
    let d = '';
    if (e.bytes) d = `${fmtB(e.bytes.got)}${e.bytes.total ? ' / ' + fmtB(e.bytes.total) : ''}${e.speed ? ' · ' + fmtB(e.speed) + '/s' : ''}`;
    else if (e.files) d = `${e.files.done} / ${e.files.total} files`;
    $('#pDetail').textContent = d;
  }
  api.onProgress((e) => { if (S.installing) paintProgress(e); });

  function resetInstallUi() {
    $('#errPanel').hidden = true;
    $('#instMain').hidden = false;
    $('#bCancel').disabled = false;
    paintProgress({ phase: 'prepare', pct: 0, text: 'Preparing…' });
  }
  function showError(code, message) {
    S.installing = false;
    $('#instMain').hidden = true;
    $('#errPanel').hidden = false;
    $('#errTitle').textContent = code === 'NO_PAYLOAD' ? 'Launcher package not found' : code === 'NETWORK' || code === 'HTTP' ? 'Download failed' : 'Installation failed';
    $('#errMsg').textContent = message;
  }

  async function startInstall() {
    if (S.installing) return;
    S.installing = true;
    resetInstallUi();
    go('install');
    const res = await api.install({
      dir: $('#dir').value, desktop: $('#oDesk').checked, startMenu: $('#oStart').checked,
      account: S.account, nick: $('#nick').value.trim(),
    });
    if (!S.installing && !res.ok) return; // error already handled elsewhere
    if (res.ok) {
      paintProgress({ phase: 'done', pct: 100, text: 'Done' });
      await new Promise((r) => setTimeout(r, 750));
      S.installing = false;
      $('#finPath').textContent = res.dir;
      go('finish');
    } else if (res.cancelled) {
      S.installing = false;
      go('location');
    } else {
      showError(res.code, res.message);
    }
  }

  $('#bCancel').addEventListener('click', () => { $('#bCancel').disabled = true; $('#instText').textContent = 'Cancelling…'; api.cancel(); });
  $('#eRetry').addEventListener('click', startInstall);
  $('#eBack').addEventListener('click', () => { S.installing = false; go('location'); });

  // ------------------------------------------------------------ footer + window buttons
  $('#btnBack').addEventListener('click', () => {
    const i = ORDER.indexOf(S.step);
    if (i > 0 && S.step !== 'install' && S.step !== 'finish') go(ORDER[i - 1]);
  });
  $('#btnNext').addEventListener('click', () => {
    if (!nextEnabled()) return;
    if (S.step === 'welcome') go('account');
    else if (S.step === 'account') go('location');
    else if (S.step === 'location') startInstall();
    else if (S.step === 'finish') { if ($('#oLaunch').checked) api.launch(); else api.quit(); }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && document.activeElement && document.activeElement.tagName !== 'BUTTON') $('#btnNext').click();
  });
  $('#bMin').addEventListener('click', () => api.minimize());
  $('#bClose').addEventListener('click', () => api.quit());

  // ------------------------------------------------------------ boot
  (async function init() {
    S.defaults = await api.getDefaults();
    $('#dir').value = S.defaults.dir;
    $('#spReq').textContent = '~' + fmtMB(S.defaults.requiredMB);
    checkNick();
    pickAccount('offline');
    go('welcome');
  })();

  // dev hooks for --screenshots
  window.__shot = {
    step: (n) => { S.installing = n === 'install'; if (n === 'install') resetInstallUi(); go(n); if (n === 'finish') $('#finPath').textContent = S.defaults.dir; },
    pick: pickAccount,
    nick: (v) => { $('#nick').value = v; checkNick(); },
    fake: (e) => { S.installing = true; paintProgress(e); },
    error: (c, m) => showError(c, m),
  };
})();
