# MobLauncher Setup (installer)

Custom Electron installer: Welcome → Account → Location → Installing → Finish. English UI, green animated design.

## How it works
The installer is one portable `.exe`. It contains **only an Electron runtime + the wizard**; the launcher itself ships as a small `payload.zip` (~10 MB, the contents of `resources/app/`).

1. Gets `payload.zip`: next to the installer exe (`payload.zip`), else downloads `payloadUrl` from `brand.json` (progress, speed, optional `payloadSha256`).
2. Extracts it to `<dir>/resources/app/`, copies its own Electron runtime to `<dir>` (exe renamed to `MobLauncher.exe`; `app.asar`, `app-update.yml`, `elevate.exe` are skipped).
3. Windows: `MobLauncher.lnk` on Desktop / Start Menu (`MobLauncher\MobLauncher.lnk`), `MobLauncher.ico`, uninstall entry in `HKCU\...\Uninstall\MobLauncher` (`"<dir>\MobLauncher.exe" --uninstall`).
4. Writes `%APPDATA%\MobLauncher\firstrun.json` → `{"account":"offline","nick":"Steve"}` / `{"account":"microsoft"}` / `{"account":"ely"}`.
5. Finish → optionally starts `MobLauncher.exe` detached.

Cancel rolls everything back (new folder removed / written files deleted, temp download removed, no firstrun.json).

## Build
```
npm install
npm run icon       # regenerate assets/icon.png + icon.ico (Pillow)
npm run payload    # ../launcher -> payload/payload.zip (+ prints sha256)
npm run dist       # -> dist/MobLauncher-Setup.exe (win x64 portable; works on Linux without wine)
```
Distribute: upload `payload.zip` somewhere (e.g. GitHub Release asset), put the URL (and sha256) in `brand.json` **before** `npm run dist`, ship only `MobLauncher-Setup.exe`.
Or ship `payload.zip` next to the exe for an offline install.

## Dev / test
- `npm start` – run the wizard. Env: `MOB_TEST_INSTALL_DIR`, `MOB_HOME`, `MOB_PAYLOAD_FILE`, `MOB_PAYLOAD_URL`, `MOB_PAYLOAD_SHA256`.
- `electron . --screenshots shots` – walks all steps and saves PNGs (use `xvfb-run -a` + `--no-sandbox` as root).
- `npm run e2e` – drives the real UI with Playwright (`MODE=local|download|cancel|nopayload`).
