'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('setup', {
  getDefaults: () => ipcRenderer.invoke('getDefaults'),
  validateDir: (dir) => ipcRenderer.invoke('validateDir', dir),
  pickFolder: (start) => ipcRenderer.invoke('pickFolder', start),
  install: (opts) => ipcRenderer.invoke('install', opts),
  cancel: () => ipcRenderer.invoke('cancel'),
  launch: () => ipcRenderer.invoke('launch'),
  quit: () => ipcRenderer.invoke('quit'),
  minimize: () => ipcRenderer.invoke('minimize'),
  onProgress: (cb) => { ipcRenderer.on('progress', (_e, p) => cb(p)); },
});
