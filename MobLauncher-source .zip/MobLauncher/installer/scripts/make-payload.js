'use strict';
/**
 * Builds payload/payload.zip = the launcher's app code (what ends up in <install>/resources/app).
 *   npm run payload            (uses ../launcher)
 * Production dependencies only (no Electron, no electron-builder). Prints the sha256 for brand.json.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execSync } = require('child_process');
const AdmZip = require('adm-zip');

const src = path.resolve(process.argv[2] || path.join(__dirname, '..', '..', 'launcher'));
const out = path.resolve(process.argv[3] || path.join(__dirname, '..', 'payload', 'payload.zip'));
const stage = fs.mkdtempSync(path.join(os.tmpdir(), 'mob-payload-'));
const skip = new Set(['node_modules', 'dist', '.git', 'shots', 'test', 'build', 'package-lock.json.bak']);

fs.cpSync(src, stage, { recursive: true, filter: (f) => !skip.has(path.basename(f)) });
console.log('installing production dependencies…');
execSync('npm install --omit=dev --no-audit --no-fund --ignore-scripts', { cwd: stage, stdio: 'inherit' });
if (fs.existsSync(path.join(stage, 'scripts', 'vendor.js'))) execSync('node scripts/vendor.js', { cwd: stage, stdio: 'inherit' });

const zip = new AdmZip();
zip.addLocalFolder(stage);
fs.mkdirSync(path.dirname(out), { recursive: true });
zip.writeZip(out);
fs.rmSync(stage, { recursive: true, force: true });
const sha = crypto.createHash('sha256').update(fs.readFileSync(out)).digest('hex');
console.log(`\n${out}\n${(fs.statSync(out).size / 1048576).toFixed(1)} MB\nsha256 ${sha}`);
