// Drives the real installer UI with Playwright (dev test, run under xvfb-run).
// MODE=local | download | cancel | nopayload ; env: E2E_DIR, E2E_HOME, E2E_PAYLOAD
const { _electron: electron } = require('playwright');
const path = require('path');
const fs = require('fs');
(async () => {
  const mode = process.env.MODE || 'local';
  const env = { ...process.env, MOB_TEST_INSTALL_DIR: process.env.E2E_DIR, MOB_HOME: process.env.E2E_HOME };
  if (mode === 'local') env.MOB_PAYLOAD_FILE = process.env.E2E_PAYLOAD;
  if (mode === 'nopayload') { env.MOB_PAYLOAD_FILE = ''; env.MOB_PAYLOAD_URL = process.env.E2E_URL || ''; if (process.env.E2E_SHA) env.MOB_PAYLOAD_SHA256 = process.env.E2E_SHA; }
  if (mode === 'download' || mode === 'cancel') { env.MOB_PAYLOAD_URL = process.env.E2E_URL; env.MOB_PAYLOAD_FILE = ''; if (process.env.E2E_SHA) env.MOB_PAYLOAD_SHA256 = process.env.E2E_SHA; }
  const app = await electron.launch({ executablePath: require('electron'), args: ['--no-sandbox', '--disable-gpu', path.join(__dirname, '..')], env });
  const win = await app.firstWindow();
  await win.waitForSelector('#btnNext:not([disabled])');
  await win.click('#btnNext');                       // welcome -> account
  await win.fill('#nick', 'TestUser');
  await win.click('#btnNext');                       // account -> location
  await win.waitForFunction(() => !document.querySelector('#btnNext').disabled && document.querySelector('#dirMsg').textContent.length > 0 && !/Checking/.test(document.querySelector('#dirMsg').textContent));
  await win.click('#btnNext');                       // install
  if (mode === 'cancel') {
    await win.waitForFunction(() => parseInt(document.querySelector('#pPct').textContent) >= 8, null, { timeout: 30000 });
    console.log('title while downloading:', await win.textContent('#instTitle'));
    await win.click('#bCancel');
    await win.waitForSelector('.step[data-step="location"].active', { timeout: 15000 });
    console.log('CANCELLED back on location step');
  } else if (mode === 'nopayload') {
    await win.waitForSelector('#errPanel:not([hidden])', { timeout: 15000 });
    console.log('ERROR PANEL:', await win.textContent('#errTitle'), '|', await win.textContent('#errMsg'));
  } else {
    await win.waitForSelector('.step[data-step="finish"].active', { timeout: 120000 });
    console.log('FINISH, path shown:', await win.textContent('#finPath'));
    await win.uncheck('#oLaunch', { force: true }).catch(() => {});
  }
  await app.close().catch(() => {});
})().catch((e) => { console.error('E2E FAIL', e.message); process.exit(1); });
