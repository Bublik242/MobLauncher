"""Generates the pixel-cube installer icon (assets/icon.png + assets/icon.ico)."""
from PIL import Image, ImageDraw
import os
here = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets')
os.makedirs(here, exist_ok=True)
S = 256
img = Image.new('RGBA', (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
d.rounded_rectangle((0, 0, S - 1, S - 1), radius=56, fill=(9, 16, 11, 255), outline=(61, 220, 107, 90), width=3)
k = 3.0  # 64 -> 192 px cube, centred
ox = oy = (S - 64 * k) / 2
P = lambda pts: [(ox + x * k, oy + y * k) for x, y in pts]
d.polygon(P([(32, 5), (57, 19), (32, 33), (7, 19)]), fill=(140, 240, 155, 255))
d.polygon(P([(7, 19), (32, 33), (32, 59), (7, 45)]), fill=(61, 220, 107, 255))
d.polygon(P([(57, 19), (32, 33), (32, 59), (57, 45)]), fill=(31, 154, 75, 255))
d.line(P([(32, 5), (57, 19), (32, 33), (7, 19), (32, 5)]), fill=(200, 255, 210, 255), width=3)
img.save(os.path.join(here, 'icon.png'))
img.save(os.path.join(here, 'icon.ico'), sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print('icons written')
