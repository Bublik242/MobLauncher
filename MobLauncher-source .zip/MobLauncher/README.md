# MobLauncher

Лаунчер Minecraft: Java Edition. Три частини:

| Папка | Що це |
|---|---|
| `launcher/` | Сам лаунчер (Electron). Запуск: `npm i && npm start` |
| `installer/` | Інсталятор з анімаціями (збирається в один EXE) |
| `server/` | Сервер друзів / чату / дзвінків (`npm i && npm start`, див. server/README.md) |

## Як зібрати й випустити
1. `cd launcher && npm i`
2. `cd installer && npm i && npm run payload` → `payload/payload.zip` (код лаунчера, ~8 МБ)
3. **Офлайн-інсталятор** (payload усередині): `npm run dist:offline` → `dist/MobLauncher-Setup-Offline.exe`
4. **Веб-інсталятор** (завантажує лаунчер з інтернету): залий `payload.zip` на GitHub Release, встав URL (і sha256) у `installer/brand.json` (`payloadUrl`, `payloadSha256`), потім `npm run dist` → `dist/MobLauncher-Setup.exe`
EXE збираються й на Linux (без wine).

## Що треба налаштувати один раз (інакше ці функції не працюватимуть)
* **Вхід через Microsoft** потребує Azure client ID (безкоштовно, інструкція є в самому лаунчері, вікно акаунта → Microsoft). Mojang має схвалити додаток: aka.ms/AppRegInfo. Можна вшити в `launcher/defaults.json`: `{"msClientId":"..."}`.
* **CurseForge** потребує безкоштовний API-ключ (console.curseforge.com) → Налаштування, або `defaults.json`: `{"curseforgeKey":"..."}`. Modrinth працює без ключа.
* **Друзі/чат/дзвінки** потребують запущений `server/` на твоєму хостингу → адреса `wss://...` у Налаштуваннях або `defaults.json`: `{"friendsServer":"wss://..."}`.

## Ely.by
Вхід логіном/паролем Ely.by (з 2FA). У грі працює через authlib-injector (лаунчер сам його завантажує), тож скіни з Ely.by видно в грі.


## Publishing
See [docs/PUBLISHING.md](docs/PUBLISHING.md). MIT licensed.

> Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft.
