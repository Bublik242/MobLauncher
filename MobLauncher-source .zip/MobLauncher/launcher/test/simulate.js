// SIMULATION: local fake "Mojang" server + tiny fake game. Exercises the launcher's real download/launch pipeline.
const { app, BrowserWindow } = require('electron');
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto'), cp = require('child_process');
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const sha1 = (b) => crypto.createHash('sha1').update(b).digest('hex');
const W = '/tmp/mobsim-work'; fs.rmSync(W, { recursive: true, force: true }); fs.mkdirSync(W + '/src/mob', { recursive: true });
fs.writeFileSync(W + '/src/mob/FakeMain.java', `package mob; import java.util.*;
public class FakeMain { static String v(String[] a,String k){for(int i=0;i<a.length-1;i++)if(a[i].equals(k))return a[i+1];return "?";}
 public static void main(String[] a) throws Exception {
  List<String> shown=new ArrayList<>(); for(int i=0;i<a.length;i++){ shown.add(a[i-1<0?0:i-1].equals("--accessToken")?"***":a[i]); }
  System.out.println("[Render thread/INFO]: Setting user: "+v(a,"--username"));
  System.out.println("[Render thread/INFO]: Minecraft version "+v(a,"--version")+" (SIMULATED test game)");
  System.out.println("[Render thread/INFO]: Game dir: "+v(a,"--gameDir"));
  System.out.println("[Render thread/INFO]: Args: "+String.join(" ",shown));
  Thread.sleep(1500); System.out.println("[Render thread/INFO]: Backend library: LWJGL version 3.3.3 (simulated)");
  Thread.sleep(1200); System.out.println("[Render thread/INFO]: Sound engine started");
  Thread.sleep(4000); System.out.println("[Render thread/INFO]: Stopping!"); } }`);
cp.execSync(`javac --release 8 -d ${W}/cls ${W}/src/mob/FakeMain.java && cd ${W}/cls && head -c 6000000 /dev/urandom > pad.bin && jar cf0 ${W}/client.jar mob pad.bin && mkdir -p ${W}/lib/x && echo hi > ${W}/lib/x/a.txt && cd ${W}/lib && jar cf ${W}/fakelib.jar x`, { stdio: 'pipe' });
const pad = fs.readFileSync(W + '/client.jar'); // jar + trailing bytes (still valid zip) for a visible download
const files = new Map(); const objs = {};
for (let i = 0; i < 90; i++) { const b = crypto.randomBytes(4000 + i * 50); const h = sha1(b); objs[`minecraft/sounds/sim_${i}.ogg`] = { hash: h, size: b.length }; files.set(`/assets/${h.slice(0, 2)}/${h}`, b); }
let base = '';
const server = http.createServer(async (req, res) => {
  await sleep(25); const u = req.url.split('?')[0];
  const send = (b, type = 'application/octet-stream') => { res.writeHead(200, { 'Content-Type': type, 'Content-Length': b.length }); res.end(b); };
  if (u === '/manifest.json') return send(Buffer.from(JSON.stringify({ latest: { release: '1.21.1', snapshot: '1.21.1' }, versions: [{ id: '1.21.1', type: 'release', url: base + '/v/1.21.1.json', releaseTime: '2024-08-08T00:00:00+00:00' }, { id: '1.20.1', type: 'release', url: base + '/v/1.20.1.json', releaseTime: '2023-06-12T00:00:00+00:00' }] })), 'application/json');
  if (u === '/v/1.21.1.json') {
    const idx = Buffer.from(JSON.stringify({ objects: objs })); files.set('/index.json', idx);
    return send(Buffer.from(JSON.stringify({ id: '1.21.1', type: 'release', mainClass: 'mob.FakeMain', assets: '17', assetIndex: { id: '17', url: base + '/index.json', sha1: sha1(idx), size: idx.length }, javaVersion: { component: 'java-runtime-delta', majorVersion: 21 },
      downloads: { client: { url: base + '/client.jar', sha1: sha1(pad), size: pad.length } },
      libraries: [{ name: 'com.mob:fakelib:1.0', downloads: { artifact: { path: 'com/mob/fakelib/1.0/fakelib-1.0.jar', url: base + '/fakelib.jar', sha1: sha1(fs.readFileSync(W + '/fakelib.jar')), size: fs.statSync(W + '/fakelib.jar').size } } }],
      arguments: { game: ['--username', '${auth_player_name}', '--version', '${version_name}', '--gameDir', '${game_directory}', '--assetsDir', '${assets_root}', '--assetIndex', '${assets_index_name}', '--uuid', '${auth_uuid}', '--accessToken', '${auth_access_token}', '--userType', '${user_type}', { rules: [{ action: 'allow', features: { has_custom_resolution: true } }], value: ['--width', '${resolution_width}', '--height', '${resolution_height}'] }],
        jvm: ['-Djava.library.path=${natives_directory}', '-Dminecraft.launcher.brand=${launcher_name}', '-cp', '${classpath}'] } })), 'application/json');
  }
  if (u === '/client.jar') { res.writeHead(200, { 'Content-Length': pad.length }); for (let o = 0; o < pad.length; o += 262144) { res.write(pad.subarray(o, o + 262144)); await sleep(45); } return res.end(); }
  if (u === '/fakelib.jar') return send(fs.readFileSync(W + '/fakelib.jar'));
  if (files.has(u)) return send(files.get(u)); res.writeHead(404); res.end();
});
const OUT = process.env.FRAMES, DATA = '/tmp/mobsim-data'; fs.rmSync(DATA, { recursive: true, force: true }); fs.mkdirSync(DATA, { recursive: true });
server.listen(0, '127.0.0.1', async () => {
  base = `http://127.0.0.1:${server.address().port}`;
  process.env.MOB_MANIFEST_URL = base + '/manifest.json'; process.env.MOB_ASSETS_URL = base + '/assets'; process.env.MOB_DATA_DIR = DATA;
  fs.writeFileSync(DATA + '/settings.json', JSON.stringify({ javaMode: 'custom', javaPath: cp.execSync('which java').toString().trim(), memInit: true, memoryMinMB: 512, memoryMaxMB: 1024, language: 'en', lastTab: 'play', showConsole: true }));
  require('../main/main.js');
  await app.whenReady(); await sleep(3500);
  const win = BrowserWindow.getAllWindows()[0]; win.setSize(1180, 740); const ex = (js) => win.webContents.executeJavaScript(js);
  await ex(`(async()=>{document.querySelectorAll('.mask').forEach(m=>m.remove());
    const c=document.createElement('div');c.style.cssText='position:fixed;left:50%;bottom:22px;transform:translateX(-50%);z-index:999;padding:10px 20px;border-radius:99px;background:rgba(0,0,0,.82);border:1px solid rgba(255,200,87,.6);color:#ffe9b0;font:600 15px system-ui,sans-serif;white-space:nowrap';c.id='cap';document.body.appendChild(c);window.cap=t=>c.textContent=t;
    cap('СИМУЛЯЦІЯ: фейковий сервер Mojang + тестова «гра» — справжній код лаунчера');
    await api('acc:offline','MobPlayer'); await refreshAccounts(); const i=await api('inst:create',{name:'Minecraft 1.21.1',mcVersion:'1.21.1',loader:'vanilla',icon:0}); S.instances=await api('inst:list'); S.selInst=i.id; S.consoleOpen=true; renderAll();})()`);
  const fs2 = require('fs'); fs2.mkdirSync(OUT, { recursive: true }); let n = 0, rec = true; const t0 = Date.now(), stamps = [];
  (async () => { while (rec) { const s = Date.now(); const img = await win.webContents.capturePage(); fs2.writeFileSync(`${OUT}/f${String(n).padStart(5, '0')}.jpg`, img.toJPEG(90)); stamps.push(s - t0); n++; await sleep(Math.max(0, 66 - (Date.now() - s))); } })();
  await sleep(2500);
  await ex(`launch()`);
  const t1 = Date.now(); let st = ''; while (Date.now() - t1 < 90000) { await sleep(500); st = await ex(`JSON.stringify({run:[...S.running],prog:S.progress&&S.progress.stage,log:S.logs.length,last:S.logs[S.logs.length-1]})`); if (/Stopping/.test(st)) break; }
  console.log('STATE', st);
  { const lib = DATA + '/minecraft/libraries/com/mob/fakelib/1.0/fakelib-1.0.jar'; const good = fs.statSync(lib).size; fs.writeFileSync(lib, 'CORRUPTED'); const nat = DATA + '/instances'; 
    const r = await ex(`api('inst:list').then(l=>api('inst:repair',l[0].id)).then(()=>'ok',e=>'ERR '+e.message)`);
    console.log('REPAIR', r, 'restored:', fs.statSync(lib).size === good); } await sleep(3500); rec = false; await sleep(300);
  fs2.writeFileSync(`${OUT}/stamps.json`, JSON.stringify(stamps)); console.log('LOG', JSON.stringify(await ex('S.logs'))); console.log('frames', n);
  app.exit(0);
});
