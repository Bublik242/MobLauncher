const { app, BrowserWindow } = require('electron');
process.env.MOB_DATA_DIR = process.env.MOB_DATA_DIR || '/tmp/mobtest-data';
require('../main/main.js');
const fs = require('fs');
const out = process.env.SHOTS || '/home/claude/MobLauncher/launcher/shots';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
app.whenReady().then(async () => {
  await sleep(3500);
  const win = BrowserWindow.getAllWindows()[0];
  const ex = (js) => win.webContents.executeJavaScript(js);
  const shot = async (n) => { await sleep(900); const img = await win.webContents.capturePage(); fs.writeFileSync(`${out}/${n}.png`, img.toPNG()); console.log('shot', n); };
  win.setSize(1180, 740);
  const errs = []; win.webContents.on('console-message', (e, lvl, msg, line, src) => { if (lvl >= 2) errs.push(msg + ' @' + src.split('/').pop() + ':' + line); });
  await ex(`(async()=>{ document.querySelectorAll('.mask').forEach(m=>m.remove());
    if(!S.accounts.length){ await api('acc:offline','MobPlayer'); await refreshAccounts(); }
    if(!S.instances.length){ for (const [n,v,l,i] of [['Survival 1.20.1','1.20.1','fabric',0],['Skyblock','1.21.1','neoforge',1],['Vanilla Plus','1.19.4','vanilla',4]]) await api('inst:create',{name:n,mcVersion:v,loader:l,icon:i}); S.instances=await api('inst:list'); S.selInst=S.instances[0].id; }
    renderAll(); setTab('play'); })()`);
  await shot('1-play');
  await ex(`document.querySelector('[data-act="pickInst"]').click()`); await shot('1b-menu'); await ex(`document.body.click()`);
  await ex(`setTab('builds')`); await shot('2-builds');
  await ex(`S.buildTab='settings'; renderBuilds()`); await shot('2b-build-settings');
  await ex(`S.buildTab='mod'; setTab('builds'); openNewBuild()`); await shot('3-newbuild');
  await ex(`document.querySelectorAll('.mask').forEach(m=>m.remove()); openAccounts('microsoft')`); await shot('4-accounts');
  await ex(`document.querySelectorAll('.mask').forEach(m=>m.remove()); openBrowser({instanceId:S.selInst,type:'mod'})`); await shot('5-browser');
  await ex(`document.querySelectorAll('.mask').forEach(m=>m.remove()); S.accounts[0].type='microsoft'; S.accounts[0].uuid='00000000000000000000000000000001'; S.settings.friendsServer='ws://x'; 
   FR.state='online'; FR.me={id:'microsoft:1',name:'MobPlayer'}; FR.list=[{id:'microsoft:a',name:'Alex_Creeper',provider:'microsoft',uuid:'a',online:true,presence:{playing:{instance:'Survival',mcVersion:'1.20.1',loader:'fabric',server:'play.x.net',mods:[{id:'modrinth:AANobbMI',name:'Sodium',version:'0.5.8',sha1:'a'}]}}},{id:'elyby:b',name:'Steve_Ely',provider:'elyby',uuid:'b',online:true,presence:null},{id:'microsoft:c',name:'Notch2',provider:'microsoft',uuid:'c',online:false,lastSeen:Date.now()-86400000}];
   FR.incoming=[{id:'microsoft:d',name:'NewGuy',provider:'microsoft',uuid:'d'}]; FR.unread={'microsoft:a':2}; FR.msgs['microsoft:a']=[{id:1,from:'microsoft:a',to:'microsoft:1',text:'Hey! Join my server?',ts:Date.now()-60000},{id:2,from:'microsoft:1',to:'microsoft:a',text:'Sure, one sec',ts:Date.now()-30000}]; FR.active='microsoft:a'; renderNav(); setTab('friends');`); await shot('6-friends');
  await ex(`showProfile({id:'microsoft:a',name:'Alex_Creeper',provider:'microsoft',uuid:'a',hours:312.4,friends:18,online:true,isFriend:true,lastSeen:0,presence:FR.list[0].presence})`); await shot('6c-profile'); await ex(`document.querySelectorAll('.mask').forEach(m=>m.remove())`);
  await ex(`joinFriend('microsoft:a')`); await sleep(900); await shot('6b-join');
  await ex(`document.querySelectorAll('.mask').forEach(m=>m.remove()); setTab('avatar')`); await sleep(1200); await shot('7-avatar');
  await ex(`setTab('servers')`); await sleep(500); await shot('8b-servers');
  await ex(`setTab('settings')`); await shot('8-settings');
  await ex(`S.progress={instanceId:S.selInst,stage:'Downloading game files',pct:42,detail:'318/760'}; S.logs=['[12:00:01] [main/INFO]: Loading Minecraft 1.20.1','[12:00:03] [main/INFO]: Backend library: LWJGL version 3.3.1']; S.consoleOpen=true; setTab('play')`); await shot('9-play-progress');
  console.log('ERRORS:', JSON.stringify(errs, null, 1));
  app.exit(0);
});
