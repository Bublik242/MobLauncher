'use strict';
// ---------------- PLAY view ----------------
const isReady = (i) => !!(i.ready || i.lastPlayed || i.resolvedVersion);
function renderPlay() {
  const el = $('#v-play'); const inst = curInst(); const running = inst && S.running.has(inst.id);
  const p = S.progress && inst && S.progress.instanceId === inst.id ? S.progress : null;
  if (!inst) {
    el.innerHTML = `<div class="hero" style="align-items:center;text-align:center;justify-content:center"><div class="artclip"><div class="art">${cubeSVG(0, 380)}</div></div><h2 style="position:relative">${esc(t('noBuild'))}</h2><p class="sub" style="position:relative">${esc(t('noBuildSub'))}</p><button class="btn primary" data-act="newBuild" style="position:relative">${ICONS.plus} ${esc(t('newBuild'))}</button></div>`;
    return;
  }
  el.innerHTML = `
  <div class="hero">
    <div class="artclip"><div class="art">${cubeSVG(inst.icon, 380)}</div></div>
    <div class="meta"><span class="tag">Minecraft ${esc(inst.mcVersion)}</span><span class="tag">${esc(LOADER_NAME[inst.loader] || 'Vanilla')}${inst.loaderVersion ? ' ' + esc(inst.loaderVersion) : ''}</span>${running ? `<span class="tag" style="color:#fff;background:rgba(52,210,123,.35)">● ${esc(t('running'))}</span>` : ''}</div>
    <h2 class="display">${esc(inst.name)}</h2>
    <div class="row" style="position:relative;gap:16px;margin-top:8px;flex-wrap:wrap">
      <div class="sel" data-act="pickInst"><span id="selIcon">${cubeSVG(inst.icon, 34)}</span><div class="grow"><b>${esc(inst.name)}</b><div class="muted" style="font-size:12px">${esc(t('chooseBuild'))}</div></div><span class="muted">▾</span></div>
      <button class="playbtn ${running ? 'stop' : ''}" data-act="${running ? 'kill' : (isReady(inst) ? 'play' : 'download')}" ${p && !running ? 'disabled' : ''}>${esc(running ? t('stop') : (p ? (isReady(inst) ? t('launching') : '…') : (isReady(inst) ? t('playNow') : '⬇ ' + t('download'))))}</button>
    </div>
  </div>
  ${p ? `<div class="glass prog"><div class="row between" style="margin-bottom:10px"><b>${esc(p.stage)}</b><span class="muted mono">${Math.round(p.pct || 0)}% ${esc(p.detail || '')}</span></div><div class="bar"><i style="width:${Math.max(2, p.pct || 0)}%"></i></div></div>` : ''}
  <div class="stats">
    <div class="glass stat"><b>${esc(fmtTime(inst.playTime))}</b><span>${esc(t('playtime'))}</span></div>
    <div class="glass stat"><b>${inst.lastPlayed ? esc(new Date(inst.lastPlayed).toLocaleDateString()) : esc(t('never'))}</b><span>${esc(t('lastPlayed'))}</span></div>
    <div class="glass stat"><b>${S.instances.length}</b><span>${esc(t('builds'))}</span></div>
  </div>
  <div class="row between" style="margin-top:18px"><div class="row"><button class="btn sm" data-act="toggleConsole">${esc(t('console'))}</button><button class="btn sm" data-act="repair">🛠 Repair</button></div></div>
  <div class="console ${S.settings.showConsole || S.consoleOpen ? '' : 'hide'}" id="console">${esc(S.logs.slice(-300).join('\n'))}</div>`;
  const c = $('#console'); if (c) c.scrollTop = c.scrollHeight;
}
function updateProgressOnly() { // cheap update while downloading, avoids re-rendering the whole view
  const p = S.progress; const box = $('#v-play .prog'); if (!box || !p) return renderPlay();
  box.querySelector('b').textContent = p.stage; box.querySelector('.mono').textContent = `${Math.round(p.pct || 0)}% ${p.detail || ''}`; box.querySelector('i').style.width = Math.max(2, p.pct || 0) + '%';
}
function pickInstMenu(anchor, onPick) {
  $$('.menu').forEach(m => m.remove());
  const m = document.createElement('div'); m.className = 'menu';
  m.innerHTML = S.instances.map(i => `<div class="it" data-id="${esc(i.id)}">${cubeSVG(i.icon, 30)}<div><b>${esc(i.name)}</b><div class="muted" style="font-size:12px">${esc(i.mcVersion)} · ${esc(LOADER_NAME[i.loader])}</div></div></div>`).join('') || `<div class="it muted">${esc(t('noBuild'))}</div>`;
  anchor.appendChild(m);
  m.addEventListener('click', (e) => { const it = e.target.closest('.it[data-id]'); if (it) { e.stopPropagation(); m.remove(); onPick(it.dataset.id); } });
  setTimeout(() => document.addEventListener('click', () => m.remove(), { once: true }), 0);
}
async function launch(opts = {}) {
  const inst = curInst(); if (!inst) return;
  if (!opts.installOnly && !curAcc()) { openAccounts(); return; }
  S.progress = { instanceId: inst.id, stage: opts.installOnly ? t('download') : t('launching'), pct: 0 }; S.logs = []; renderPlay();
  try {
    const r = await api('play', { instanceId: inst.id, accountId: S.selectedAcc, server: opts.server || null, installOnly: !!opts.installOnly });
    if (r && r.installed) { S.progress = null; S.instances = await api('inst:list'); renderPlay(); toast('Minecraft is ready — press PLAY', 'good'); }
  }
  catch (e) { S.progress = null; renderPlay(); fail(e); }
}

// ---------------- Accounts modal ----------------
async function refreshAccounts() {
  const r = await api('acc:list'); S.accounts = r.accounts; S.selectedAcc = r.selected; renderAccChip();
  if (typeof friendsAccountChanged === 'function') friendsAccountChanged();
}
function renderAccChip() {
  const a = curAcc();
  $('#accName').textContent = a ? a.name : 'Sign in'; $('#accType').textContent = a ? ({ offline: t('offline'), microsoft: 'Microsoft', elyby: 'Ely.by' })[a.type] : '';
  const h = $('#accHead'); h.dataset.type = a ? a.type : ''; h.dataset.uuid = a ? a.uuid : ''; h.dataset.name = a ? a.name : ''; h.dataset.skin = a && a.skinUrl || ''; h.dataset.done = ''; h.classList.add('head');
  if (a) paintHeads($('#title')); else drawHead(h, null);
}
const typeBadge = (a) => `<span class="badge ${a.type === 'microsoft' ? 'ms' : a.type === 'elyby' ? 'ely' : 'off'}">${a.type === 'offline' ? t('offline') : a.type === 'microsoft' ? 'Microsoft' : 'Ely.by'}</span>`;

function openAccounts(tab = 'list') {
  let cur = tab; let unsub = null;
  const m = modal('', { onClose: () => { unsub && unsub(); api('acc:ms:cancel').catch(() => {}); } });
  const render = () => {
    const list = S.accounts.map(a => `<div class="item" style="${a.id === S.selectedAcc ? 'border-color:var(--green)' : ''}">${headImg(a.type, a.uuid, a.name, a.skinUrl)}<div class="grow"><div class="nm">${esc(a.name)}</div></div>${typeBadge(a)}${a.needsLogin ? '<span class="badge" style="background:rgba(255,93,108,.2);color:#ff9aa4">sign in again</span>' : ''}<button class="btn sm" data-sel="${a.id}">${a.id === S.selectedAcc ? '✓' : 'Use'}</button><button class="btn sm danger" data-rm="${a.id}">✕</button></div>`).join('') || `<div class="empty">${esc(t('addAccount'))}</div>`;
    m.el.innerHTML = `<h3>${esc(t('accounts'))}</h3>
      <div class="chips" style="margin:12px 0 16px"><button class="chip ${cur === 'list' ? 'on' : ''}" data-tab="list">${esc(t('accounts'))}</button><button class="chip ${cur === 'offline' ? 'on' : ''}" data-tab="offline">${esc(t('offline'))}</button><button class="chip ${cur === 'microsoft' ? 'on' : ''}" data-tab="microsoft">Microsoft</button><button class="chip ${cur === 'elyby' ? 'on' : ''}" data-tab="elyby">Ely.by</button></div>
      <div id="accBody">${cur === 'list' ? `<div class="ilist">${list}</div>` : cur === 'offline' ? `<div class="field"><label>${esc(t('username'))}</label><input class="in" id="offName" maxlength="16" placeholder="Steve" value="${esc((S.bootOffline || ''))}"></div><p class="muted" style="margin-bottom:10px">Offline accounts work without internet and on offline-mode servers. Friends & skins need Microsoft or Ely.by.</p><button class="btn primary" data-do="offline">${esc(t('create'))}</button>` : cur === 'microsoft' ? `<div id="msBox"><p class="muted" style="margin-bottom:14px">Sign in with your Microsoft account that owns Minecraft: Java Edition. You will get a short code to enter on microsoft.com.</p><button class="btn primary" data-do="ms">Microsoft — ${esc(t('signIn'))}</button></div>` : `<div class="field"><label>Ely.by ${esc(t('username'))} / email</label><input class="in" id="elyU"></div><div class="field"><label>${esc(t('password'))}</label><input class="in" id="elyP" type="password"></div><div class="field hide" id="ely2"><label>2FA code</label><input class="in" id="elyT" maxlength="8" placeholder="123456"></div><button class="btn primary" data-do="ely">${esc(t('signIn'))}</button> <button class="btn" data-open="https://account.ely.by/register">Create Ely.by account</button>`}</div>
      <div class="acts"><button class="btn" data-close>${esc(t('close'))}</button></div>`;
    paintHeads(m.el);
  };
  render();
  m.el.addEventListener('click', async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    try {
      if (b.dataset.tab) { cur = b.dataset.tab; render(); }
      else if (b.dataset.sel) { await api('acc:select', b.dataset.sel); await refreshAccounts(); render(); }
      else if (b.dataset.rm) { await api('acc:remove', b.dataset.rm); await refreshAccounts(); render(); }
      else if (b.dataset.open) api('shell:open', b.dataset.open);
      else if (b.dataset.do === 'offline') { await api('acc:offline', $('#offName').value); await refreshAccounts(); toast('✓', 'good'); cur = 'list'; render(); }
      else if (b.dataset.do === 'ely') {
        try { await api('acc:elyby', $('#elyU').value, $('#elyP').value, ($('#elyT') || {}).value); await refreshAccounts(); cur = 'list'; render(); }
        catch (er) { if (er.code === 'ELY_2FA') { $('#ely2').classList.remove('hide'); toast('Enter your 2FA code', 'err'); } else throw er; }
      }
      else if (b.dataset.do === 'ms') {
        const box = $('#msBox'); box.innerHTML = `<div class="row" style="gap:10px"><span class="spin"></span> Contacting Microsoft…</div>`;
        unsub = on('acc:ms:code', (info) => { box.innerHTML = `<p style="margin-bottom:10px">Your browser opened Microsoft sign-in. ${info.copied ? 'The code was <b>copied</b> — just paste it' : 'Enter this code'} (or <a href="#" data-open="${esc(info.openUrl || info.url)}" style="color:var(--green-3)">open the page again</a>):</p><div class="code">${esc(info.userCode)}</div><div class="row" style="gap:10px;margin-top:14px"><span class="spin"></span><span class="muted">Waiting for you to finish signing in…</span></div>`; });
        try { await api('acc:ms:start'); await refreshAccounts(); unsub && unsub(); cur = 'list'; render(); toast('Microsoft ✓', 'good'); }
        catch (er) {
          unsub && unsub();
          if (er.code === 'MS_CLIENT_ID_MISSING') { box.innerHTML = msSetupHtml(); const go = box.querySelector('[data-save]'); go.onclick = async () => { const v = box.querySelector('#msCid').value.trim(); if (!/^[0-9a-f-]{36}$/i.test(v)) return toast('Client ID looks like 00000000-0000-0000-0000-000000000000', 'err'); S.settings = await api('settings:set', { msClientId: v }); cur = 'microsoft'; render(); toast('Saved. Press Sign in again.', 'good'); }; }
          else { cur = 'microsoft'; render(); fail(er); }
        }
      }
    } catch (er) { fail(er); }
  });
  m.el.addEventListener('click', (e) => { const a = e.target.closest('a[data-open]'); if (a) { e.preventDefault(); api('shell:open', a.dataset.open); } });
}
const msSetupHtml = () => `<div class="warn" style="margin-bottom:12px"><span>ℹ</span><span>Microsoft sign-in is not enabled in this build yet. You can use Ely.by or an offline account for now. <i>(Launcher developer: set it up below.)</i></span></div><div class="info" style="margin-bottom:12px">Microsoft sign-in needs an <b>Azure application (client) ID</b> — this is how Microsoft identifies the launcher. It is free and takes 3 minutes:</div>
 <ol class="muted" style="padding-left:20px;line-height:1.7;margin-bottom:12px"><li>Open <a href="#" data-open="https://portal.azure.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade" style="color:var(--green-3)">Azure → App registrations</a> → New registration</li><li>Account type: <i>Personal Microsoft accounts only</i> (or “any directory + personal”)</li><li>Authentication → enable <i>Allow public client flows</i></li><li>Copy the <i>Application (client) ID</i> here</li><li>Mojang must approve the app for the Minecraft API (form: aka.ms/AppRegInfo)</li></ol>
 <div class="field"><input class="in" id="msCid" placeholder="00000000-0000-0000-0000-000000000000"></div><button class="btn primary" data-save>Save client ID</button>`;
