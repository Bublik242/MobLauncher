'use strict';
// ---------------- SETTINGS ----------------
const mem = (mb) => `${mb} MiB <small>= ${(mb / 1024).toFixed(mb % 1024 ? 2 : 1)} GiB</small>`;
let saveT;
function saveSetting(patch) { Object.assign(S.settings, patch); clearTimeout(saveT); saveT = setTimeout(() => api('settings:set', patch).catch(fail), 250); }
function memWarnings(min, max) {
  const total = S.sys.totalMB || 8192, w = [];
  if (min > max) w.push(['', t('memWarnOrder')]);
  if (max > total * 0.75) w.push(['bad', t('memWarnHigh') + ` (${Math.round(max / total * 100)}% of ${(total / 1024).toFixed(1)} GiB)`]);
  if (max > 8192) w.push(['', t('memWarnBig')]);
  if (max < 2048) w.push(['', t('memWarnLow')]);
  return w.map(([c, m]) => `<div class="warn ${c}"><span>⚠</span><span>${esc(m)}</span></div>`).join('');
}
function renderSettings() {
  const s = S.settings, total = S.sys.totalMB || 8192, top = Math.max(1024, Math.min(32768, Math.floor((total - 512) / 256) * 256));
  const toggle = (k, label, d) => `<div class="srow"><div><b>${esc(label)}</b>${d ? `<div class="d">${esc(d)}</div>` : ''}</div><div class="switch ${s[k] ? 'on' : ''}" data-sw="${k}"></div></div>`;
  $('#v-settings').innerHTML = `<h2>${esc(t('settings'))}</h2><div class="sub">MobLauncher ${esc(S.sys.version || '')}</div>
  <div class="glass set-sec"><h3>${esc(t('memory'))}</h3><div class="ram">
    <div><div class="row between"><b>${esc(t('minMem'))}</b><span class="v" id="vMin">${mem(s.memoryMinMB)}</span></div><input type="range" id="rMin" min="256" max="${top}" step="256" value="${s.memoryMinMB}"></div>
    <div><div class="row between"><b>${esc(t('maxMem'))}</b><span class="v" id="vMax">${mem(s.memoryMaxMB)}</span></div><input type="range" id="rMax" min="512" max="${top}" step="256" value="${s.memoryMaxMB}"></div>
    <div class="muted" style="font-size:12px">${esc(t('memHelp'))} · System RAM: ${mem(total)}</div><div id="memWarn" style="display:grid;gap:8px">${memWarnings(s.memoryMinMB, s.memoryMaxMB)}</div></div></div>
  <div class="glass set-sec"><h3>${esc(t('general'))}</h3>
    <div class="srow"><b>${esc(t('language'))}</b><select class="in" id="sLang" style="width:220px">${Object.entries(LANGS).map(([k, v]) => `<option value="${k}" ${k === s.language ? 'selected' : ''}>${v}</option>`).join('')}</select></div>
    <div class="srow"><b>${esc(t('closeAfter'))}</b><select class="in" id="sClose" style="width:220px">${[['keep', t('keep')], ['hide', t('hide')], ['quit', t('quit')]].map(([k, v]) => `<option value="${k}" ${k === s.closeOnLaunch ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></div>
    ${toggle('reducedMotion', t('reduceMotion'), 'Turns off background and transition animations (helps weak PCs).')}</div>
  <div class="glass set-sec"><h3>${esc(t('game'))}</h3>
    <div class="srow"><b>${esc(t('resolution'))}</b><div class="row"><input class="in" id="sW" type="number" style="width:100px" value="${s.width}"> × <input class="in" id="sH" type="number" style="width:100px" value="${s.height}"></div></div>
    ${toggle('fullscreen', t('fullscreen'))}${toggle('showConsole', t('showConsole'))}</div>
  <div class="glass set-sec"><h3>${esc(t('java'))}</h3>
    <div class="srow"><div><b>Java</b><div class="d">Launcher picks and downloads the right Java for each Minecraft version automatically.</div></div><select class="in" id="sJm" style="width:240px"><option value="auto" ${s.javaMode === 'auto' ? 'selected' : ''}>${esc(t('javaAuto'))}</option><option value="custom" ${s.javaMode === 'custom' ? 'selected' : ''}>${esc(t('javaCustom'))}</option></select></div>
    <div class="field ${s.javaMode === 'custom' ? '' : 'hide'}" id="sJpBox" style="margin-top:10px"><input class="in mono" id="sJp" placeholder="C:\\Program Files\\Java\\jdk-21\\bin\\java.exe" value="${esc(s.javaPath)}"></div>
    <div class="field" style="margin-top:12px"><label>JVM arguments</label><input class="in mono" id="sJvm" value="${esc(s.jvmArgs)}"></div></div>
  <div class="glass set-sec"><h3>Privacy</h3>${toggle('showHours', 'Show my play time to friends', 'Friends see total hours in your profile and in search.')}${toggle('showActivity', 'Show what I’m playing', 'Friends see your build, version and server, and can join you. Turn off to appear as just “online”.')}</div>
  <details class="glass set-sec"><summary style="cursor:pointer;font:600 18px Outfit">Developer options</summary><div style="margin-top:14px">
    <div class="field"><label>${esc(t('server'))}</label><input class="in" id="sFs" placeholder="wss://your-server" value="${esc(s.friendsServer)}"></div>
    <div class="field"><label>Server address to share with friends (host:port)</label><input class="in" id="sSrv" placeholder="play.example.com" value="${esc(s.shareServerAddress)}"></div>
    <div class="field"><label>Microsoft Azure client ID</label><input class="in mono" id="sMs" placeholder="00000000-0000-0000-0000-000000000000" value="${esc(s.msClientId)}"></div>
    <div class="field"><label>CurseForge API key</label><input class="in mono" id="sCf" type="password" value="${esc(s.curseforgeKey)}"></div></div></details>
  <div class="glass set-sec"><h3>${esc(t('about'))}</h3><div class="srow"><div><b>${esc(t('dataFolder'))}</b><div class="d mono">${esc(S.sys.dataDir || '')}</div></div><button class="btn sm" id="sOpen">${ICONS.folder} ${esc(t('openFolder'))}</button></div></div>
  <div class="glass set-sec" style="border-color:rgba(255,93,108,.35)"><h3 style="color:#ff9aa4">Danger zone</h3><div class="srow"><div><b>Uninstall MobLauncher</b><div class="d">Closes the launcher and removes it from this computer, including shortcuts. You choose whether your game data is deleted too.</div></div><button class="btn sm danger" id="sUninst">Uninstall…</button></div></div>`;
  $('#sUninst').onclick = () => {
    const m = modal(`<h3>Uninstall MobLauncher?</h3><p class="muted" style="margin:10px 0 14px">The launcher will close by itself and its files and shortcuts will be removed.</p><label class="row" style="gap:10px;margin-bottom:16px;cursor:pointer"><input type="checkbox" id="unData"> <span>Also delete my game data (worlds, mods, accounts, builds)</span></label><div class="row"><button class="btn danger" id="unGo">Uninstall</button><button class="btn" data-close>${esc(t('cancel'))}</button></div>`);
    $('#unGo', m.el).onclick = async () => { try { await api('app:uninstall', { deleteData: $('#unData', m.el).checked }); $('#unGo', m.el).textContent = 'Closing…'; } catch (e) { fail(e); } };
  };
  const upd = () => { const mn = +$('#rMin').value, mx = +$('#rMax').value; $('#vMin').innerHTML = mem(mn); $('#vMax').innerHTML = mem(mx); $('#memWarn').innerHTML = memWarnings(mn, mx); saveSetting({ memoryMinMB: Math.min(mn, mx), memoryMaxMB: mx }); };
  $('#rMin').oninput = upd; $('#rMax').oninput = upd;
  $('#sLang').onchange = (e) => { CUR_LANG = e.target.value; saveSetting({ language: CUR_LANG }); renderAll(); };
  $('#sClose').onchange = (e) => saveSetting({ closeOnLaunch: e.target.value });
  $('#sJm').onchange = (e) => { saveSetting({ javaMode: e.target.value }); $('#sJpBox').classList.toggle('hide', e.target.value !== 'custom'); };
  $('#sJp').oninput = (e) => saveSetting({ javaPath: e.target.value.trim() }); $('#sJvm').oninput = (e) => saveSetting({ jvmArgs: e.target.value });
  $('#sW').oninput = (e) => saveSetting({ width: +e.target.value || 1280 }); $('#sH').oninput = (e) => saveSetting({ height: +e.target.value || 720 });
  $('#sMs').oninput = (e) => saveSetting({ msClientId: e.target.value.trim() }); $('#sCf').oninput = (e) => saveSetting({ curseforgeKey: e.target.value.trim() });
  $('#sSrv').oninput = (e) => saveSetting({ shareServerAddress: e.target.value.trim() });
  $('#sFs').onchange = (e) => { saveSetting({ friendsServer: e.target.value.trim() }); setTimeout(friendsAccountChanged, 400); };
  $('#sOpen').onclick = () => api('system:openDataDir');
  $$('[data-sw]', $('#v-settings')).forEach(n => n.onclick = () => { const k = n.dataset.sw; saveSetting({ [k]: !S.settings[k] }); n.classList.toggle('on', S.settings[k]); if (k === 'reducedMotion') document.body.classList.toggle('reduced', S.settings[k]); if (k === 'showHours' || k === 'showActivity') setTimeout(publishPresence, 400); });
}
