'use strict';
// ---------------- AVATAR: 3D skin viewer, capes, backgrounds ----------------
const AV = { viewer: null, skinData: null, variant: 'classic', anim: 'walk', bg: 0, localPath: null, ro: null, capeData: null, accKey: '' };
const AV_BGS = ['linear-gradient(160deg,#0f2a1b,#050a07)', 'radial-gradient(circle at 50% 30%,#1d6b3f,#04100a 70%)', 'linear-gradient(160deg,#0b2a4a,#050a14)', 'linear-gradient(160deg,#3b1d5e,#0a0514)', 'linear-gradient(160deg,#5e2a1d,#140805)', 'linear-gradient(180deg,#8fd3ff,#e6f6ff 60%,#4aa85c 60%,#2f7a3e)', 'repeating-conic-gradient(#0c1a12 0 25%,#0f2218 0 50%) 50%/36px 36px'];
const AV_ANIMS = { idle: () => new skinview3d.IdleAnimation(), walk: () => new skinview3d.WalkingAnimation(), run: () => new skinview3d.RunningAnimation(), fly: () => new skinview3d.FlyingAnimation(), none: () => null };

function renderAvatar() {
  const el = $('#v-avatar'); const a = curAcc();
  const key = a ? a.id + ':' + (a.skinUrl || '') : 'none';
  if (el.dataset.built === key && AV.viewer) { avatarResize(); return; }
  el.dataset.built = key;
  el.innerHTML = `<h2>${esc(t('avatar'))}</h2><div class="sub">${a ? esc(a.name) + ' · ' + esc({ offline: t('offline'), microsoft: 'Microsoft', elyby: 'Ely.by' }[a.type]) : ''}</div>
  <div class="av"><div class="stage" id="avStage" style="background:${AV_BGS[AV.bg]}"><canvas id="avCanvas" tabindex="-1"></canvas><div class="hint">${esc(t('rotate'))}</div></div>
   <div style="overflow:auto;display:flex;flex-direction:column;gap:14px;padding-right:4px">
    <div class="glass set-sec" style="margin:0"><h3>${esc(t('animation'))}</h3><div class="chips" id="avAnim">${Object.keys(AV_ANIMS).map(k => `<button class="chip ${k === AV.anim ? 'on' : ''}" data-an="${k}">${k}</button>`).join('')}</div></div>
    <div class="glass set-sec" style="margin:0"><h3>${esc(t('background'))}</h3><div class="row" style="flex-wrap:wrap;gap:8px" id="avBg">${AV_BGS.map((b, i) => `<div class="sw ${i === AV.bg ? 'on' : ''}" data-bg="${i}" style="background:${b}"></div>`).join('')}<div class="sw" data-bg="img" title="Image…" style="display:grid;place-items:center;background:var(--bg-3)">＋</div></div></div>
    <div class="glass set-sec" style="margin:0"><h3>Skin</h3>
      <div class="chips" style="margin-bottom:12px"><button class="chip ${AV.variant === 'classic' ? 'on' : ''}" data-var="classic">Classic</button><button class="chip ${AV.variant === 'slim' ? 'on' : ''}" data-var="slim">Slim</button></div>
      <div class="row" style="flex-wrap:wrap;gap:8px"><button class="btn sm" id="avImport">${esc(t('skinImport'))}</button>
      ${a && a.type === 'microsoft' ? `<button class="btn sm primary" id="avUpload" ${AV.localPath ? '' : 'disabled'}>${esc(t('skinUpload'))}</button>` : ''}
      ${a && a.type === 'elyby' ? `<button class="btn sm" data-open="https://ely.by/skins">ely.by skins ↗</button><button class="btn sm" id="avReload">↻</button>` : ''}</div>
      <p class="muted" style="font-size:12px;margin-top:10px">${!a ? '' : a.type === 'offline' ? 'Offline accounts: skin is a preview only (servers won’t show it). Use Microsoft or Ely.by for a real skin.' : a.type === 'elyby' ? 'Your Ely.by skin appears in game through authlib-injector. Upload or change it on ely.by, then press ↻.' : 'Import a 64×64 PNG, preview it, then apply it to your Minecraft account.'}</p></div>
    ${a && a.type === 'microsoft' ? `<div class="glass set-sec" style="margin:0"><h3>${esc(t('capes'))}</h3><div class="row" style="flex-wrap:wrap;gap:10px" id="avCapes">${(a.capes || []).length ? `<div class="cape" data-cape="" title="None" style="display:grid;place-items:center;font-size:22px">∅</div>` : '<span class="muted">No capes on this account.</span>'}${(a.capes || []).map(c => `<div class="cape ${c.active ? 'on' : ''}" data-cape="${esc(c.id)}" data-url="${esc(c.url)}" title="${esc(c.alias)}"></div>`).join('')}</div></div>` : ''}
   </div></div>`;
  initViewer(); loadAccountSkin();
  $$('#avCapes .cape[data-url]').forEach(async n => { const d = await api('skin:get', { url: n.dataset.url, type: 'x', uuid: n.dataset.cape, name: 'cape' }).catch(() => null); if (d) cropCape(d).then(u => { n.style.backgroundImage = `url(${u})`; n.style.backgroundSize = 'cover'; }); if (n.classList.contains('on') && d) AV.viewer && AV.viewer.loadCape(d); });
}
function cropCape(src) { return new Promise(r => { const i = new Image(); i.onload = () => { const c = document.createElement('canvas'); c.width = 10; c.height = 16; const x = c.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(i, 1, 1, 10, 16, 0, 0, 10, 16); r(c.toDataURL()); }; i.src = src; }); }
function initViewer() {
  const stage = $('#avStage'), cv = $('#avCanvas');
  if (AV.viewer) { try { AV.viewer.dispose(); } catch {} AV.viewer = null; }
  const w = Math.max(300, stage.clientWidth), h = Math.max(300, stage.clientHeight);
  try {
    AV.viewer = new skinview3d.SkinViewer({ canvas: cv, width: w, height: h, skin: defaultSkinDataURL(), model: AV.variant === 'slim' ? 'slim' : 'default' });
    AV.viewer.fov = 40; AV.viewer.zoom = 0.85; AV.viewer.autoRotate = false; AV.viewer.controls.enableZoom = true; AV.viewer.controls.enablePan = false;
    AV.viewer.animation = AV_ANIMS[AV.anim](); AV.viewer.globalLight.intensity = 2.6; AV.viewer.cameraLight.intensity = 1.2;
  } catch (e) { stage.innerHTML = `<div class="empty">3D preview unavailable (WebGL): ${esc(e.message)}</div>`; return; }
  if (AV.ro) AV.ro.disconnect(); AV.ro = new ResizeObserver(avatarResize); AV.ro.observe(stage);
}
function avatarResize() { const s = $('#avStage'); if (AV.viewer && s && s.clientWidth > 50) { try { AV.viewer.setSize(s.clientWidth, s.clientHeight); } catch {} } }
async function loadAccountSkin() {
  const a = curAcc(); if (!a || !AV.viewer) return;
  let url = AV.skinData; if (!url) url = await loadSkinURL(a);
  if (url && AV.viewer) { try { await AV.viewer.loadSkin(url, { model: AV.variant === 'slim' ? 'slim' : 'default' }); } catch (e) { console.warn(e); } }
}
document.addEventListener('click', async (e) => {
  const v = e.target.closest('#v-avatar'); if (!v) return; const a = curAcc();
  const q = (s) => e.target.closest(s);
  try {
    if (q('[data-an]')) { AV.anim = q('[data-an]').dataset.an; $$('#avAnim .chip').forEach(c => c.classList.toggle('on', c.dataset.an === AV.anim)); AV.viewer.animation = AV_ANIMS[AV.anim](); }
    else if (q('[data-bg]')) {
      const b = q('[data-bg]').dataset.bg;
      if (b === 'img') { const p = await api('dialog:file', [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'webp'] }]); if (!p) return; const d = await api('fs:readB64', p); $('#avStage').style.background = `center/cover url(data:image/*;base64,${d})`; $$('#avBg .sw').forEach(c => c.classList.remove('on')); }
      else { AV.bg = +b; $('#avStage').style.background = AV_BGS[AV.bg]; $$('#avBg .sw').forEach(c => c.classList.toggle('on', c.dataset.bg === b)); }
    }
    else if (q('[data-var]')) { AV.variant = q('[data-var]').dataset.var; $$('[data-var]').forEach(c => c.classList.toggle('on', c.dataset.var === AV.variant)); loadAccountSkin(); }
    else if (q('#avImport')) { const p = await api('dialog:file', [{ name: 'PNG skin', extensions: ['png'] }]); if (!p) return; AV.localPath = p; AV.skinData = 'data:image/png;base64,' + await api('fs:readB64', p); await loadAccountSkin(); const u = $('#avUpload'); if (u) u.disabled = false; toast('Skin loaded — preview only until you apply it', 'good'); }
    else if (q('#avUpload')) { const b = q('#avUpload'); b.disabled = true; const r = await api('acc:skin:upload', a.id, AV.localPath, AV.variant); S.accounts = r.accounts; AV.skinData = null; $('#v-avatar').dataset.built = ''; headCache.clear(); renderAccChip(); renderAvatar(); toast('Skin applied to your Minecraft account', 'good'); }
    else if (q('#avReload')) { headCache.clear(); AV.skinData = null; await loadAccountSkin(); }
    else if (q('[data-cape]') && a) { const n = q('[data-cape]'); const r = await api('acc:cape', a.id, n.dataset.cape || null); S.accounts = r.accounts; if (!n.dataset.cape && AV.viewer) AV.viewer.resetCape(); $('#v-avatar').dataset.built = ''; renderAvatar(); }
    else if (q('[data-open]')) api('shell:open', q('[data-open]').dataset.open);
  } catch (er) { fail(er); }
});
