'use strict';
// ---------------- BUILDS (Minecraft instance builder) ----------------
S.buildTab = 'mod'; S.contentCache = {};
async function renderBuilds() {
  const el = $('#v-builds'); const inst = curInst();
  const dock = `<div class="glass dock">${S.instances.map(i => `<button class="dk ${i.id === S.selInst ? 'on' : ''}" data-id="${esc(i.id)}">${S.running.has(i.id) ? '<i class="run"></i>' : ''}${cubeSVG(i.icon, 56)}<span>${esc(i.name)}</span></button>`).join('')}<button class="dk add" data-act="newBuild"><div class="plus">+</div><span>${esc(t('newBuild'))}</span></button></div>`;
  if (!inst) { el.innerHTML = `<div class="builder"><div><h2>${esc(t('builds'))}</h2><p class="sub">${esc(t('noBuildSub'))}</p></div><div class="empty"><div style="--s:140px">${cubeSVG(0, 140)}</div><button class="btn primary" data-act="newBuild">${ICONS.plus} ${esc(t('newBuild'))}</button><button class="btn" data-act="browseModpacks">${esc(t('modpacks'))}</button></div>${dock}</div>`; return; }
  el.innerHTML = `<div class="builder"><div style="overflow:auto;padding-right:6px">
    <div class="row between" style="margin-bottom:14px;gap:14px"><div class="row" style="gap:16px">${cubeSVG(inst.icon, 64)}<div><h2 style="margin:0">${esc(inst.name)}</h2><div class="muted">Minecraft ${esc(inst.mcVersion)} · ${esc(LOADER_NAME[inst.loader])}${inst.loaderVersion ? ' ' + esc(inst.loaderVersion) : ''}</div></div></div>
      <div class="row"><button class="btn sm" data-act="openFolder">${ICONS.folder} ${esc(t('openFolder'))}</button><button class="btn sm" data-act="browseModpacks">${esc(t('modpacks'))}</button><button class="btn sm" data-act="dupBuild">⧉</button><button class="btn sm danger" data-act="delBuild">${esc(t('delete'))}</button><button class="btn primary sm" data-act="playBuild">▶ ${esc(t('play'))}</button></div></div>
    <div class="tabs">${[['mod', t('mods')], ['resourcepack', t('resourcepacks')], ['shader', t('shaders')], ['settings', t('settings')]].map(([k, l]) => `<button class="tab ${S.buildTab === k ? 'on' : ''}" data-tab="${k}">${esc(l)}</button>`).join('')}</div>
    <div id="buildBody"></div></div>${dock}</div>`;
  await renderBuildBody();
}
async function renderBuildBody() {
  const inst = curInst(); const body = $('#buildBody'); if (!inst || !body) return;
  if (S.buildTab === 'settings') return renderBuildSettings(inst, body);
  const type = S.buildTab;
  let items = []; try { items = await api('inst:content', inst.id, type); } catch (e) { fail(e); }
  if (type !== S.buildTab || inst.id !== S.selInst) return;
  body.innerHTML = `<div class="row between" style="margin-bottom:12px"><span class="muted">${items.length} · ${esc(type === 'mod' ? t('mods') : type === 'shader' ? t('shaders') : t('resourcepacks'))}</span><div class="row">${type === 'mod' ? '<button class="btn sm" id="chkUpd">⟳ Check for updates</button>' : ''}<button class="btn primary sm" data-act="browse" data-type="${type}">${ICONS.search} ${esc(t('browse'))}</button></div></div>
    <div class="ilist">${items.map(m => `<div class="item ${m.enabled ? '' : 'off'}">${m.icon ? `<img class="ic" src="" data-src="${esc(m.icon)}" alt="">` : `<div class="ic" style="display:grid;place-items:center;background:var(--bg-3);border-radius:9px;width:40px;height:40px;font-size:18px">${type === 'mod' ? '⚙' : type === 'shader' ? '✦' : '▦'}</div>`}<div class="grow"><div class="nm">${esc(m.name)}</div><div class="vs">${esc(m.version || m.base)} · ${(m.size / 1048576).toFixed(1)} MB${m.provider ? ' · ' + esc(m.provider) : ''}</div></div><div class="switch ${m.enabled ? 'on' : ''}" data-toggle="${esc(m.file)}"></div><button class="btn sm danger" data-del="${esc(m.file)}">✕</button></div>`).join('') || `<div class="empty"><div style="font-size:42px">📦</div><div>Nothing here yet.</div><button class="btn primary" data-act="browse" data-type="${type}">${esc(t('browse'))}</button></div>`}</div>`;
  $$('img[data-src]', body).forEach(async img => { try { img.src = await api('img:proxy', img.dataset.src); } catch {} });
  const cu = $('#chkUpd', body); if (cu) cu.onclick = async () => {
    cu.disabled = true; cu.textContent = 'Checking…';
    try {
      const list = await api('content:updates', inst.id);
      if (!list.length) { toast('All your mods are up to date ✓', 'good'); return; }
      const m = modal(`<h3>${list.length} update${list.length > 1 ? 's' : ''} available</h3><div class="ilist" style="margin:14px 0">${list.map(u => `<div class="item"><div class="grow"><div class="nm">${esc(u.name)}</div><div class="vs">${esc(u.from || '?')} → ${esc(u.to)}</div></div></div>`).join('')}</div><div class="row"><button class="btn primary" id="updGo">Update all</button><button class="btn" data-close>${esc(t('close'))}</button></div>`);
      $('#updGo', m.el).onclick = async (e) => { e.target.disabled = true; e.target.textContent = 'Updating…'; try { await api('content:applyUpdates', inst.id, list); toast('Mods updated ✓', 'good'); m.close(); renderBuildBody(); } catch (er) { fail(er); e.target.disabled = false; } };
    } catch (e) { fail(e); } finally { cu.disabled = false; cu.textContent = '⟳ Check for updates'; }
  };

}
function renderBuildSettings(inst, body) {
  const total = S.sys.totalMB || 8192;
  body.innerHTML = `<div class="glass set-sec"><h3>${esc(t('general'))}</h3>
    <div class="field"><label>${esc(t('name'))}</label><input class="in" id="bsName" value="${esc(inst.name)}"></div>
    <div class="row" style="gap:14px"><div class="field grow"><label>${esc(t('mcVersion'))}</label><select class="in" id="bsMc"></select></div><div class="field grow"><label>${esc(t('loader'))}</label><select class="in" id="bsLoader">${Object.keys(LOADER_NAME).map(k => `<option value="${k}" ${k === inst.loader ? 'selected' : ''}>${LOADER_NAME[k]}</option>`).join('')}</select></div><div class="field grow"><label>${esc(t('loaderVersion'))}</label><select class="in" id="bsLv"><option value="">${esc(t('latest'))}</option></select></div></div>
    <div class="field"><label>${esc(t('color'))}</label><div class="row" style="gap:8px">${CUBE_COLORS.map((c, i) => `<div class="sw ${i === inst.icon ? 'on' : ''}" data-ic="${i}" style="background:linear-gradient(135deg,${c[0]},${c[2]})"></div>`).join('')}</div></div></div>
    <div class="glass set-sec"><h3>${esc(t('memory'))} <small class="muted" style="font-weight:400;font-size:12px">— 0 = use global settings</small></h3>
    <div class="row" style="gap:14px"><div class="field grow"><label>${esc(t('minMem'))} MiB</label><input class="in" id="bsMin" type="number" min="0" step="256" value="${inst.memoryMinMB || 0}"></div><div class="field grow"><label>${esc(t('maxMem'))} MiB</label><input class="in" id="bsMax" type="number" min="0" step="256" max="${total}" value="${inst.memoryMaxMB || 0}"></div></div>
    <div class="field"><label>JVM arguments (empty = global)</label><input class="in mono" id="bsJvm" value="${esc(inst.jvmArgs || '')}"></div></div>
    <button class="btn primary" data-act="saveBuild">${esc(t('save'))}</button>`;
  fillVersionSelect($('#bsMc'), inst.mcVersion).then(() => fillLoaderVersions());
  $('#bsLoader').onchange = fillLoaderVersions; $('#bsMc').onchange = fillLoaderVersions;
  async function fillLoaderVersions() {
    if (!$('#bsLoader') || !$('#bsMc') || !$('#bsLv')) return;
    const ld = $('#bsLoader').value, mc = $('#bsMc').value, sel = $('#bsLv'); sel.innerHTML = `<option value="">${esc(t('latest'))}</option>`;
    if (ld === 'vanilla') { sel.disabled = true; return; } sel.disabled = false;
    try { const v = await api('mc:loaderVersions', ld, mc); sel.innerHTML += v.slice(0, 80).map(x => `<option value="${esc(x.id)}" ${x.id === inst.loaderVersion ? 'selected' : ''}>${esc(x.id)}${x.stable ? ' ★' : ''}</option>`).join(''); } catch (e) { sel.innerHTML += ''; }
  }
}
let VERSIONS = null;
async function loadVersions() { if (!VERSIONS) VERSIONS = await api('mc:versions'); return VERSIONS; }
async function fillVersionSelect(sel, current, snaps = false) {
  try { const v = await loadVersions(); const list = v.filter(x => snaps || x.type === 'release' || x.id === current); sel.innerHTML = list.map(x => `<option value="${esc(x.id)}" ${x.id === current ? 'selected' : ''}>${esc(x.id)}${x.type !== 'release' ? ' (' + x.type + ')' : ''}</option>`).join(''); }
  catch (e) { VERSIONS = null; sel.innerHTML = `<option value="">⚠ Versions did not load — press ↻ Retry</option>`; toast(e.message, 'err'); }
}

function openNewBuild() {
  let loader = 'vanilla', icon = Math.floor(Math.random() * CUBE_COLORS.length);
  const m = modal(`<h3>${esc(t('newBuildTitle'))}</h3><p class="sub" style="margin-bottom:16px">Every build has its own folder, mods and settings.</p>
   <div class="field"><label>${esc(t('name'))}</label><input class="in" id="nbName" placeholder="My survival world" maxlength="40"></div>
   <div class="field"><label>${esc(t('mcVersion'))}</label><div class="row" style="gap:10px"><select class="in" id="nbMc"><option>Loading…</option></select><button class="btn sm" id="nbReload" title="Retry">↻ Retry</button><label class="row muted" style="white-space:nowrap;gap:8px;font-size:12px;text-transform:none;letter-spacing:0"><div class="switch" id="nbSnap"></div>${esc(t('showSnap'))}</label></div></div>
   <div class="field"><label>${esc(t('loader'))}</label><div class="chips" id="nbLoaders">${Object.keys(LOADER_NAME).map(k => `<button class="chip ${k === 'vanilla' ? 'on' : ''}" data-l="${k}">${LOADER_NAME[k]}</button>`).join('')}</div></div>
   <div class="field"><label>${esc(t('loaderVersion'))}</label><select class="in" id="nbLv" disabled><option value="">${esc(t('latest'))}</option></select></div>
   <div class="field"><label>${esc(t('color'))}</label><div class="row" style="gap:8px" id="nbIc">${CUBE_COLORS.map((c, i) => `<div class="sw ${i === icon ? 'on' : ''}" data-ic="${i}" style="background:linear-gradient(135deg,${c[0]},${c[2]})"></div>`).join('')}</div></div>
   <div class="acts"><button class="btn" data-close>${esc(t('cancel'))}</button><button class="btn primary" id="nbGo">${esc(t('create'))}</button></div>`);
  const mc = $('#nbMc', m.el), lv = $('#nbLv', m.el); let snaps = false;
  const fillLv = async () => { lv.innerHTML = `<option value="">${esc(t('latest'))}</option>`; lv.disabled = loader === 'vanilla'; if (loader === 'vanilla') return;
    try { const v = await api('mc:loaderVersions', loader, mc.value); if (!v.length) { toast(`${LOADER_NAME[loader]} does not support ${mc.value}`, 'err'); return; } lv.innerHTML += v.slice(0, 80).map(x => `<option value="${esc(x.id)}">${esc(x.id)}${x.stable ? ' ★' : ''}</option>`).join(''); } catch (e) { toast('Loader list: ' + e.message, 'err'); } };
  fillVersionSelect(mc, null, false).then(fillLv); mc.onchange = fillLv;
  $('#nbReload', m.el).onclick = () => { VERSIONS = null; mc.innerHTML = '<option>Loading…</option>'; fillVersionSelect(mc, null, snaps).then(fillLv); };
  $('#nbSnap', m.el).onclick = (e) => { snaps = !snaps; e.currentTarget.classList.toggle('on', snaps); fillVersionSelect(mc, mc.value, snaps); };
  m.el.addEventListener('click', (e) => {
    const l = e.target.closest('[data-l]'); if (l) { loader = l.dataset.l; $$('#nbLoaders .chip', m.el).forEach(c => c.classList.toggle('on', c === l)); fillLv(); }
    const ic = e.target.closest('[data-ic]'); if (ic) { icon = +ic.dataset.ic; $$('#nbIc .sw', m.el).forEach(c => c.classList.toggle('on', c === ic)); }
  });
  $('#nbGo', m.el).onclick = async () => {
    if (!mc.value) return toast('Choose a Minecraft version first (press ↻ Retry if the list is empty).', 'err');
    try { const inst = await api('inst:create', { name: $('#nbName', m.el).value, mcVersion: mc.value, loader, loaderVersion: lv.value, icon });
      S.instances = await api('inst:list'); S.selInst = inst.id; await api('settings:set', { lastInstance: inst.id }); m.close(); toast(t('created'), 'good'); renderAll(); }
    catch (e) { fail(e); }
  };
}
