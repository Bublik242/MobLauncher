'use strict';
// Tabs are anchored to the bottom of the black sidebar and stack upward: Play is the lowest.
const TABS = [['play', 'play'], ['builds', 'builds'], ['servers', 'servers'], ['friends', 'friends'], ['avatar', 'avatar'], ['settings', 'settings']];
const VIEW = { play: renderPlay, builds: renderBuilds, servers: renderServers, friends: renderFriends, avatar: renderAvatar, settings: renderSettings };

function renderNav() {
  $('#nav').innerHTML = TABS.map(([k, ic]) => `<button class="nav ${S.tab === k ? 'on' : ''}" data-tab="${k}">${ICONS[ic]}<span>${esc(t(k))}</span>${k === 'friends' ? '<span class="dot"></span>' : ''}</button>`).join('');
  updateBadge();
}
function setTab(k) {
  S.tab = k; $$('.nav').forEach(n => n.classList.toggle('on', n.dataset.tab === k));
  $$('.view').forEach(v => v.classList.toggle('on', v.id === 'v-' + k));
  VIEW[k](); if (k === 'friends' && FR.active && FR.unread[FR.active]) { FR.unread[FR.active] = 0; fsend({ t: 'read', with: FR.active }); updateBadge(); }
  api('settings:set', { lastTab: k }).catch(() => {});
}
function renderAll() { document.documentElement.lang = CUR_LANG; renderNav(); renderAccChip(); $$('.view').forEach(v => v.classList.toggle('on', v.id === 'v-' + S.tab)); VIEW[S.tab](); }

document.addEventListener('click', async (e) => {
  const nav = e.target.closest('.nav[data-tab]'); if (nav) return setTab(nav.dataset.tab);
  const w = e.target.closest('[data-w]'); if (w) return api('win:' + w.dataset.w);
  if (e.target.closest('#accChip')) return openAccounts();
  const act = e.target.closest('[data-act]'); const inst = curInst();
  try {
    if (act) switch (act.dataset.act) {
      case 'newBuild': return openNewBuild();
      case 'accounts': return openAccounts();
      case 'pickInst': return pickInstMenu(act, async (id) => { S.selInst = id; api('settings:set', { lastInstance: id }); renderPlay(); });
      case 'play': return launch();
      case 'download': return launch({ installOnly: true });
      case 'kill': return api('play:kill', inst.id);
      case 'toggleConsole': S.consoleOpen = !S.consoleOpen; return renderPlay();
      case 'repair': { if (!inst) return; S.progress = { instanceId: inst.id, stage: 'Repairing…', pct: 1 }; renderPlay(); try { await api('inst:repair', inst.id); toast('Repair finished ✓', 'good'); } catch (er) { fail(er); } S.progress = null; return renderPlay(); }
      case 'openFolder': return api('inst:openFolder', inst.id);
      case 'browse': return openBrowser({ instanceId: inst.id, type: act.dataset.type });
      case 'browseModpacks': return openBrowser({ type: 'modpack' });
      case 'playBuild': setTab('play'); return launch();
      case 'dupBuild': { const c = await api('inst:duplicate', inst.id); S.instances = await api('inst:list'); S.selInst = c.id; return renderBuilds(); }
      case 'delBuild': if (confirm(`Delete "${inst.name}" and all its files (worlds, mods)? This cannot be undone.`)) { await api('inst:delete', inst.id); S.instances = await api('inst:list'); S.selInst = S.instances[0] ? S.instances[0].id : null; return renderBuilds(); } return;
      case 'saveBuild': {
        const patch = { name: $('#bsName').value.trim() || inst.name, mcVersion: $('#bsMc').value, loader: $('#bsLoader').value, loaderVersion: $('#bsLv').value, memoryMinMB: +$('#bsMin').value || 0, memoryMaxMB: +$('#bsMax').value || 0, jvmArgs: $('#bsJvm').value.trim() };
        const ic = $('#v-builds .sw.on'); if (ic) patch.icon = +ic.dataset.ic;
        await api('inst:update', inst.id, patch); S.instances = await api('inst:list'); toast(t('save') + ' ✓', 'good'); return renderBuilds();
      }
    }
    // builds view internals
    const dk = e.target.closest('.dk[data-id]'); if (dk) { S.selInst = dk.dataset.id; api('settings:set', { lastInstance: S.selInst }); return renderBuilds(); }
    const tab = e.target.closest('#v-builds .tab'); if (tab) { S.buildTab = tab.dataset.tab; return renderBuilds(); }
    const sw = e.target.closest('#v-builds .sw[data-ic]'); if (sw) { $$('#v-builds .sw').forEach(x => x.classList.toggle('on', x === sw)); return; }
    const tg = e.target.closest('#v-builds [data-toggle]'); if (tg) { await api('inst:toggle', inst.id, S.buildTab, tg.dataset.toggle); return renderBuildBody(); }
    const dl = e.target.closest('#v-builds [data-del]'); if (dl) { if (confirm('Remove this file?')) { await api('inst:removeContent', inst.id, S.buildTab, dl.dataset.del); renderBuildBody(); } return; }
  } catch (er) { fail(er); }
});

// ---- events from the main process ----
on('play:progress', (p) => { S.progress = p; if (S.tab === 'play') updateProgressOnly(); });
on('game:start', ({ instanceId }) => { S.running.add(instanceId); S.progress = null; FR.myServer = null; refreshViews(); setTimeout(publishPresence, 3000); });
on('game:ready', () => {});
on('game:server', ({ server }) => { FR.myServer = server; publishPresence(); });
on('game:log', ({ line }) => { S.logs.push(line); if (S.logs.length > 2000) S.logs.splice(0, 500); const c = $('#console'); if (c && !c.classList.contains('hide')) { c.textContent += line + '\n'; c.scrollTop = c.scrollHeight; } });
on('game:exit', async ({ instanceId, code, error }) => {
  S.running.delete(instanceId); S.progress = null; S.instances = await api('inst:list'); FR.myServer = null; publishPresence();
  if (code && code !== 0) { toast(`Game exited with code ${code}. Open the console on the Play tab for details.`, 'err'); S.consoleOpen = true; } else toast(t('exited'));
  refreshViews();
});
on('game:crash', ({ instanceId, reason, fix }) => {
  const labels = { memory: 'Give it more RAM and retry', java: 'Switch to automatic Java and retry', repair: 'Repair files and retry', mods: 'Open the build’s mods' };
  const m = modal(`<h3>⚠ The game stopped</h3><p style="margin:8px 0 14px">${esc(reason)}</p><div class="acts"><button class="btn" data-close>${esc(t('close'))}</button><button class="btn primary" id="fixBtn">🛠 ${esc(labels[fix] || 'Repair and retry')}</button></div>`);
  $('#fixBtn', m.el).onclick = async () => {
    m.close(); if (fix === 'mods') { S.selInst = instanceId; S.buildTab = 'mod'; return setTab('builds'); }
    S.progress = { instanceId, stage: 'Fixing…', pct: 1 }; renderPlay();
    try { await api('fix:apply', { fix, instanceId }); S.settings = await api('settings:get'); S.progress = null; S.selInst = instanceId; launch(); } catch (e) { S.progress = null; renderPlay(); fail(e); }
  };
});
on('friends:state', (d) => { FR.state = d.state; FR.err = d.message; if (d.state !== 'online') { FR.list.forEach(f => f.online = false); } if (S.tab === 'friends') renderFriends(); });
on('friends:msg', onFriendsMsg);
function refreshViews() { if (S.tab === 'play') renderPlay(); else if (S.tab === 'builds') renderBuilds(); else if (S.tab === 'friends') renderChat(); }

// ---- init ----
(async function init() {
  try {
    S.settings = await api('settings:get'); S.sys = await api('system:info');
    CUR_LANG = I18N[S.settings.language] ? S.settings.language : 'en';
    if (S.settings.reducedMotion) document.body.classList.add('reduced');
    if (!S.settings.memInit) { const mx = Math.min(4096, Math.max(2048, Math.floor(S.sys.totalMB / 2 / 256) * 256)); S.settings = await api('settings:set', { memInit: true, memoryMaxMB: mx, memoryMinMB: Math.min(1024, mx) }); }
    startBackground();
    S.instances = await api('inst:list');
    S.selInst = (S.instances.find(i => i.id === S.settings.lastInstance) || S.instances[0] || {}).id || null;
    S.running = new Set(await api('inst:running'));
    await refreshAccounts();
    S.tab = VIEW[S.settings.lastTab] ? S.settings.lastTab : 'play';
    renderAll();
    // installer hand-off
    const b = await api('bootstrap:get');
    if (b) {
      await api('bootstrap:done');
      if (b.accountChoice === 'offline' && b.offlineName && !S.accounts.length) { try { await api('acc:offline', b.offlineName); await refreshAccounts(); } catch (e) { fail(e); } }
      else if (!S.accounts.length) openAccounts(b.accountChoice === 'microsoft' ? 'microsoft' : b.accountChoice === 'elyby' ? 'elyby' : 'offline');
    } else if (!S.accounts.length) openAccounts('offline');
    if (!S.instances.length && S.accounts.length) setTimeout(() => { if (!$('.mask')) openNewBuild(); }, 600);
  } catch (e) { fail(e); }
})();
