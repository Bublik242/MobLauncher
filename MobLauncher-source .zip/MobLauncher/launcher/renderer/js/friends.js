'use strict';
// ---------------- FRIENDS: list, chat, calls, join-with-mod-check ----------------
const FR = S.friends; FR.results = []; FR.myPresence = null; FR.searchQ = '';
const fsend = (o) => api('friends:send', o).catch(() => false);
const frAccOk = () => { const a = curAcc(); return a && a.type !== 'offline'; };
function friendsAccountChanged() { if (frAccOk() && S.settings.friendsServer) { api('friends:connect', S.selectedAcc).catch(fail); } else { api('friends:disconnect').catch(() => {}); FR.state = frAccOk() ? 'no-server' : 'offline-account'; FR.list = []; } renderFriends(); }
const findFriend = (id) => FR.list.find(f => f.id === id) || null;
const userOf = (id) => { const f = findFriend(id); if (f) return f; return [...FR.incoming, ...FR.outgoing, ...FR.results].find(u => u.id === id) || { id, name: id.split(':')[1] || '?', provider: id.split(':')[0], uuid: id.split(':')[1] }; };
const unreadTotal = () => Object.values(FR.unread).reduce((a, b) => a + b, 0);
function updateBadge() { const d = $('#nav .nav[data-tab="friends"] .dot'); if (!d) return; const n = unreadTotal() + FR.incoming.length; d.textContent = n > 99 ? '99+' : n; d.classList.toggle('show', n > 0); }

function statusText(f) {
  if (!f.online) return f.lastSeen ? 'Last seen ' + new Date(f.lastSeen).toLocaleDateString() : t('offlineSt');
  const pl = f.presence && f.presence.playing;
  return pl ? `Playing ${pl.instance} · ${pl.mcVersion}${pl.server ? ' @ ' + pl.server : ''}` : t('online');
}
const presClass = (f) => !f.online ? '' : (f.presence && f.presence.playing ? 'play' : 'on');

function renderFriends() {
  const el = $('#v-friends'); updateBadge();
  if (!frAccOk()) { el.innerHTML = `<h2>${esc(t('friends'))}</h2><div class="glass empty" style="margin-top:20px"><div style="font-size:54px">🔒</div><b style="font-size:18px">${esc(t('friendsOnly'))}</b><button class="btn primary" data-act="accounts">${esc(t('addAccount'))}</button></div>`; return; }
  if (!S.settings.friendsServer) { el.innerHTML = `<h2>${esc(t('friends'))}</h2><div class="glass empty" style="margin-top:20px"><div style="font-size:54px">🛰</div><b style="font-size:18px">Friends service is not connected in this build</b><span class="muted">It will appear here automatically once the launcher is configured with a friends server.</span><details style="margin-top:10px"><summary class="muted" style="cursor:pointer">Developer: set server address</summary><div class="field" style="margin-top:10px;min-width:320px"><input class="in" id="fsUrl" placeholder="wss://friends.example.com"></div><button class="btn primary sm" id="fsSave">${esc(t('save'))} & connect</button></details></div>`; $('#fsSave').onclick = async () => { S.settings = await api('settings:set', { friendsServer: $('#fsUrl').value.trim() }); friendsAccountChanged(); }; return; }
  const online = FR.list.filter(f => f.online).sort((a, b) => a.name.localeCompare(b.name)), offl = FR.list.filter(f => !f.online).sort((a, b) => a.name.localeCompare(b.name));
  const row = (f) => `<div class="fi ${FR.active === f.id ? 'on' : ''}" data-fid="${esc(f.id)}">${headImg(f.provider, f.uuid, f.name)}<span class="pres ${presClass(f)}"></span><div class="grow"><b>${esc(f.name)}</b><div class="st">${esc(statusText(f))}</div></div>${FR.unread[f.id] ? `<span class="ub">${FR.unread[f.id]}</span>` : ''}</div>`;
  const resRow = (u) => { const isF = !!findFriend(u.id), pend = FR.outgoing.some(o => o.id === u.id); return `<div class="fi">${headImg(u.provider, u.uuid, u.name)}<div class="grow" data-prof="${esc(u.id)}" style="cursor:pointer"><b>${esc(u.name)}</b><div class="st">${u.hours != null ? '⏱ ' + u.hours + ' h · ' : ''}${esc(u.provider === 'microsoft' ? 'Microsoft' : 'Ely.by')}${u.online ? ' · online' : ''}</div></div>${isF ? '<span class="badge">friend</span>' : pend ? '<span class="badge off">sent</span>' : `<button class="btn sm primary" data-add="${esc(u.id)}">+</button>`}</div>`; };
  const stateBar = FR.state !== 'online' ? `<div class="warn ${FR.state === 'error' ? 'bad' : ''}" style="margin-bottom:10px">${FR.state === 'connecting' ? '<span class="spin"></span> Connecting…' : FR.state === 'error' ? '⚠ ' + esc(FR.err || 'Connection error') + ' <button class="btn sm" data-act="friendsRetry">Retry</button>' : 'Offline — reconnecting…'}</div>` : '';
  el.innerHTML = `<div class="fr"><div class="glass fr-l">${stateBar}<div class="search">${ICONS.search}<input class="in" id="frSearch" placeholder="${esc(t('findPlayers'))}" value="${esc(FR.searchQ)}"></div>
    <div class="flist">${FR.searchQ.length >= 2 ? `<div class="sec">Players</div>${FR.results.map(resRow).join('') || '<div class="muted" style="padding:8px">No players found.</div>'}` : ''}
    ${FR.incoming.length ? `<div class="sec">${esc(t('requests'))} (${FR.incoming.length})</div>${FR.incoming.map(u => `<div class="fi">${headImg(u.provider, u.uuid, u.name)}<div class="grow"><b>${esc(u.name)}</b></div><button class="btn sm primary" data-acc="${esc(u.id)}">✓</button><button class="btn sm" data-dec="${esc(u.id)}">✕</button></div>`).join('')}` : ''}
    ${FR.outgoing.length ? `<div class="sec">Sent</div>${FR.outgoing.map(u => `<div class="fi">${headImg(u.provider, u.uuid, u.name)}<div class="grow"><b>${esc(u.name)}</b></div><button class="btn sm" data-cancel="${esc(u.id)}">✕</button></div>`).join('')}` : ''}
    <div class="sec">${esc(t('online'))} — ${online.length}</div>${online.map(row).join('') || '<div class="muted" style="padding:6px 8px">—</div>'}
    <div class="sec">${esc(t('offlineSt'))} — ${offl.length}</div>${offl.map(row).join('')}</div></div>
    <div class="glass fr-r" id="chatBox"></div></div>`;
  paintHeads(el); renderChat();
  const si = $('#frSearch'); si.oninput = () => { FR.searchQ = si.value.trim(); clearTimeout(FR._st); FR._st = setTimeout(() => { if (FR.searchQ.length >= 2) fsend({ t: 'search', q: FR.searchQ }); else { FR.results = []; renderFriends(); } }, 300); };
  if (document.activeElement === document.body && FR.searchQ) { si.focus(); si.setSelectionRange(si.value.length, si.value.length); }
}
function renderChat() {
  const box = $('#chatBox'); if (!box) return;
  const f = FR.active && userOf(FR.active);
  if (!f) { box.innerHTML = `<div class="empty" style="height:100%"><div style="font-size:54px">💬</div><b>Select a friend to chat</b><span class="muted">Join their game, call them, or send an invite.</span></div>`; return; }
  const msgs = FR.msgs[f.id] || [];
  const inCall = CALL.peer === f.id && CALL.state !== 'idle';
  box.innerHTML = `<div class="chat-h">${headImg(f.provider, f.uuid, f.name)}<div class="grow"><b style="font-size:16px">${esc(f.name)}</b><div class="muted" style="font-size:12px">${esc(statusText(f))}</div></div>
    ${f.presence && f.presence.playing ? `<button class="btn sm primary" data-join="${esc(f.id)}">▶ ${esc(t('join'))}</button>` : ''}
    <button class="btn sm" data-invite="${esc(f.id)}" ${S.running.size ? '' : 'disabled'}>${esc(t('invite'))}</button>
    <button class="btn sm ${inCall ? 'danger' : ''}" data-call="${esc(f.id)}" ${f.online ? '' : 'disabled'}>${ICONS.phone} ${esc(inCall ? t('hangup') : t('call'))}</button>
    <button class="btn sm" data-prof="${esc(f.id)}" title="Profile">👤</button><button class="btn sm danger" data-unfriend="${esc(f.id)}">✕</button></div>
    <div class="msgs" id="msgs">${msgs.map(m => `<div class="m ${m.from === FR.me?.id ? 'me' : ''}">${esc(m.text)}<small>${new Date(m.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small></div>`).join('') || `<div class="empty muted">Say hi 👋</div>`}</div>
    <div class="composer"><input class="in" id="chatIn" placeholder="${esc(t('typeMsg'))}" maxlength="2000"><button class="btn primary" id="chatSend">➤</button></div>`;
  paintHeads(box);
  const ms = $('#msgs'); ms.scrollTop = ms.scrollHeight;
  const send = () => { const i = $('#chatIn'); const text = i.value.trim(); if (!text) return; fsend({ t: 'msg', to: f.id, text }); i.value = ''; };
  $('#chatSend').onclick = send; $('#chatIn').onkeydown = (e) => { if (e.key === 'Enter') send(); }; if (!FR._noFocus) $('#chatIn').focus();
}
function openChat(id) {
  FR.active = id; if (!FR.msgs[id]) { FR.msgs[id] = []; fsend({ t: 'history', with: id }); }
  if (FR.unread[id]) { FR.unread[id] = 0; fsend({ t: 'read', with: id }); }
  renderFriends();
}

// ---- server messages ----
function onFriendsMsg(m) {
  switch (m.t) {
    case 'authed': FR.me = m.user; FR.list = m.friends || []; FR.incoming = m.incoming || []; FR.outgoing = m.outgoing || []; FR.unread = m.unread || {}; FR.state = 'online'; publishPresence(); renderFriends(); break;
    case 'presence': { const f = findFriend(m.user.id); if (f) { f.online = m.online; f.presence = m.presence; f.lastSeen = m.lastSeen || f.lastSeen; renderFriends(); } break; }
    case 'friend.incoming': if (!FR.incoming.some(u => u.id === m.from.id)) FR.incoming.push(m.from); toast(`${m.from.name} sent you a friend request`); renderFriends(); break;
    case 'friend.outgoing': if (!FR.outgoing.some(u => u.id === m.to.id)) FR.outgoing.push(m.to); renderFriends(); break;
    case 'friend.added': FR.incoming = FR.incoming.filter(u => u.id !== m.friend.id); FR.outgoing = FR.outgoing.filter(u => u.id !== m.friend.id); FR.list = FR.list.filter(f => f.id !== m.friend.id).concat(m.friend); toast(`${m.friend.name} is now your friend`, 'good'); renderFriends(); break;
    case 'friend.removed': FR.list = FR.list.filter(f => f.id !== m.user); if (FR.active === m.user) FR.active = null; renderFriends(); break;
    case 'friend.request.cancelled': FR.incoming = FR.incoming.filter(u => u.id !== m.user); FR.outgoing = FR.outgoing.filter(u => u.id !== m.user); renderFriends(); break;
    case 'profile': showProfile(m.user); break;
    case 'search.result': FR.results = m.users || []; renderFriends(); break;
    case 'history': FR.msgs[m.with] = m.messages || []; if (FR.active === m.with) renderChat(); break;
    case 'msg': {
      const other = m.from === FR.me.id ? m.to : m.from; const arr = FR.msgs[other] || (FR.msgs[other] = []);
      if (!arr.some(x => x.id === m.id)) arr.push(m);
      if (m.from !== FR.me.id) { if (S.tab === 'friends' && FR.active === other) fsend({ t: 'read', with: other }); else { FR.unread[other] = (FR.unread[other] || 0) + 1; toast(`${userOf(other).name}: ${m.text.slice(0, 60)}`); } }
      if (S.tab === 'friends') { FR._noFocus = false; renderFriends(); } else updateBadge(); break; }
    case 'invite': showInvite(m); break;
    case 'error': if (m.code && !['auth_failed'].includes(m.code)) toast(`Friends: ${m.message || m.code}`, 'err'); break;
    default: if (m.t && m.t.startsWith('call.')) onCallMsg(m);
  }
}

// ---- presence ----
async function publishPresence() {
  if (FR.state !== 'online') return;
  let playing = null; const id = [...S.running][0];
  if (id) { const inst = S.instances.find(i => i.id === id); if (inst) { let mods = []; try { mods = await api('inst:mods', id); } catch {} playing = { instance: inst.name, mcVersion: inst.mcVersion, loader: inst.loader, loaderVersion: inst.loaderVersion || '', server: FR.myServer || S.settings.shareServerAddress || null, mods }; } }
  FR.myPresence = playing; fsend({ t: 'presence', status: 'online', playing, hours: S.settings.showHours === false ? null : totalHours(), hideActivity: S.settings.showActivity === false });
}

const totalHours = () => Math.round(S.instances.reduce((a, i) => a + (i.playTime || 0), 0) / 360) / 10;
function showProfile(u) {
  const pl = u.presence && u.presence.playing;
  const m = modal(`<div style="text-align:center">${headImg(u.provider, u.uuid, u.name).replace('class="head"', 'class="head" style="width:96px;height:96px;border-radius:20px"')}<h3 style="margin-top:12px">${esc(u.name)}</h3><div style="margin:6px 0 14px"><span class="badge ${u.provider === 'microsoft' ? 'ms' : 'ely'}">${u.provider === 'microsoft' ? 'Microsoft' : 'Ely.by'}</span> ${u.online ? '<span class="badge">online</span>' : '<span class="badge off">offline</span>'}</div></div>
    <div class="stats" style="grid-template-columns:repeat(3,1fr);margin:0 0 14px"><div class="glass stat"><b>${u.hours != null ? u.hours : '—'}</b><span>hours played</span></div><div class="glass stat"><b>${u.friends != null ? u.friends : '—'}</b><span>friends</span></div><div class="glass stat"><b style="font-size:16px">${u.online ? 'now' : (u.lastSeen ? new Date(u.lastSeen).toLocaleDateString() : '—')}</b><span>last seen</span></div></div>
    ${pl ? `<div class="info">▶ Playing ${esc(pl.instance)} · Minecraft ${esc(pl.mcVersion)} · ${esc(LOADER_NAME[pl.loader] || pl.loader)}${pl.server ? ' @ ' + esc(pl.server) : ''} · ${pl.mods ? pl.mods.length : 0} mods</div>` : (u.isFriend ? '<div class="muted" style="text-align:center">Not playing right now (or hiding activity)</div>' : '')}
    <div class="acts" style="justify-content:center"><button class="btn" data-close>${esc(t('close'))}</button>${u.id === (FR.me && FR.me.id) ? '' : u.isFriend ? `<button class="btn primary" id="pfChat">💬 Message</button>` : `<button class="btn primary" id="pfAdd">+ ${esc(t('addFriend'))}</button>`}</div>`);
  paintHeads(m.el);
  const c = $('#pfChat', m.el); if (c) c.onclick = () => { m.close(); setTab('friends'); openChat(u.id); };
  const a = $('#pfAdd', m.el); if (a) a.onclick = () => { fsend({ t: 'friend.request', to: u.id }); toast('Request sent', 'good'); m.close(); };
}
// ---- compare mods ----
function compareMods(mine, theirs) {
  const bySha = new Map(mine.filter(m => m.sha1).map(m => [m.sha1, m])), byId = new Map(mine.map(m => [m.id, m]));
  const matchedMine = new Set(), missing = [], different = [];
  for (const tm of theirs) {
    if (tm.sha1 && bySha.has(tm.sha1)) { matchedMine.add(bySha.get(tm.sha1)); continue; }
    const mm = byId.get(tm.id);
    if (mm) { matchedMine.add(mm); different.push({ name: tm.name, theirs: tm.version, mine: mm.version }); } else missing.push(tm);
  }
  return { missing, different, extra: mine.filter(m => !matchedMine.has(m)) };
}
async function joinFriend(id) {
  const f = findFriend(id); const pl = f && f.presence && f.presence.playing; if (!pl) return toast('Friend is not in game', 'err');
  if (!S.instances.length) { toast(t('noBuild'), 'err'); return; }
  let instId = S.instances.find(i => i.mcVersion === pl.mcVersion && i.loader === pl.loader)?.id || S.selInst || S.instances[0].id;
  const m = modal(`<h3>${esc(t('join'))} ${esc(f.name)}</h3><p class="muted" style="margin-bottom:14px">${esc(pl.instance)} · Minecraft ${esc(pl.mcVersion)} · ${esc(LOADER_NAME[pl.loader] || pl.loader)}${pl.server ? ' · ' + esc(pl.server) : ''}</p>
    <div class="field"><label>${esc(t('builds'))}</label><select class="in" id="jbSel">${S.instances.map(i => `<option value="${esc(i.id)}" ${i.id === instId ? 'selected' : ''}>${esc(i.name)} — ${esc(i.mcVersion)} ${esc(LOADER_NAME[i.loader])}</option>`).join('')}</select></div>
    <div id="jbBody"></div><div class="acts" id="jbActs"></div>`);
  const run = async () => {
    instId = $('#jbSel', m.el).value; const body = $('#jbBody', m.el), acts = $('#jbActs', m.el);
    body.innerHTML = `<div class="row" style="gap:10px;padding:14px"><span class="spin"></span> ${esc(t('checking'))}</div>`;
    acts.innerHTML = `<button class="btn" data-close>${esc(t('cancel'))}</button><button class="btn" id="jbSkip">${esc(t('skip'))}</button>`;
    $('#jbSkip', m.el).onclick = () => go();
    const inst = S.instances.find(i => i.id === instId); let mine = []; try { mine = await api('inst:mods', instId); } catch {}
    await new Promise(r => setTimeout(r, 450));
    if (!m.el.isConnected) return;
    const cmp = compareMods(mine, pl.mods || []); const verBad = inst.mcVersion !== pl.mcVersion || inst.loader !== pl.loader;
    const ok = !cmp.missing.length && !cmp.different.length && !verBad;
    const list = (title, arr, fmt) => arr.length ? `<div class="sec">${esc(title)} (${arr.length})</div><div style="max-height:130px;overflow:auto">${arr.slice(0, 60).map(x => `<div class="muted" style="padding:2px 6px">• ${esc(fmt(x))}</div>`).join('')}</div>` : '';
    body.innerHTML = ok ? `<div class="info" style="font-size:15px">✓ ${esc(t('compatOk'))}</div>` : `<div class="warn bad"><span>⚠</span><div><b>${esc(t('compatBad'))}</b>${verBad ? `<div>Version/loader: you have ${esc(inst.mcVersion)} ${esc(inst.loader)}, friend has ${esc(pl.mcVersion)} ${esc(pl.loader)}</div>` : ''}</div></div>${list(t('missing'), cmp.missing, x => `${x.name} ${x.version || ''}`)}${list(t('different'), cmp.different, x => `${x.name}: you ${x.mine || '?'} / friend ${x.theirs || '?'}`)}${list(t('extra'), cmp.extra, x => x.name)}`;
    acts.innerHTML = ok ? `<button class="btn" data-close>${esc(t('cancel'))}</button><button class="btn primary" id="jbGo">▶ ${esc(t('join'))}</button>` : `<button class="btn" data-close>${esc(t('close'))}</button><button class="btn danger" id="jbGo">${esc(t('joinAnyway'))}</button>`;
    $('#jbGo', m.el).onclick = () => go();
  };
  const go = async () => { m.close(); S.selInst = instId; await api('settings:set', { lastInstance: instId }); setTab('play'); if (pl.server) launch({ server: pl.server }); else { toast('Friend has not shared a server address — starting the game, join manually.', ''); launch(); } };
  $('#jbSel', m.el).onchange = run; run();
}
function showInvite(m) {
  const pl = m.payload || {};
  const mm = modal(`<h3>${esc(m.from.name)} invites you</h3><p class="muted">${esc(pl.instance || '')} · Minecraft ${esc(pl.mcVersion || '?')}${pl.server ? ' · ' + esc(pl.server) : ''}</p><div class="acts"><button class="btn" data-close>${esc(t('decline'))}</button><button class="btn primary" id="invGo">${esc(t('join'))}</button></div>`);
  $('#invGo', mm.el).onclick = () => { mm.close(); const f = findFriend(m.from.id); if (f) { f.presence = f.presence || {}; f.presence.playing = pl; joinFriend(f.id); } };
}
async function inviteFriend(id) { await publishPresence(); fsend({ t: 'invite', to: id, payload: FR.myPresence ? { ...FR.myPresence, mods: FR.myPresence.mods } : {} }); toast('Invite sent', 'good'); }

// ---- voice calls (WebRTC, signalling through the friends server) ----
const CALL = { peer: null, state: 'idle', pc: null, stream: null, muted: false };
const ICE = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }] };
function callBar() {
  let b = $('#callbar'); if (CALL.state === 'idle') { if (b) b.remove(); return; }
  if (!b) { b = document.createElement('div'); b.id = 'callbar'; b.className = 'callbar'; document.body.appendChild(b); }
  const u = userOf(CALL.peer);
  b.innerHTML = `${headImg(u.provider, u.uuid, u.name)}<div><b>${esc(u.name)}</b><div class="muted" style="font-size:12px">${CALL.state === 'ringing' ? 'Calling…' : CALL.state === 'connecting' ? 'Connecting…' : 'In call'}</div></div><div class="wave"><i></i><i></i><i></i><i></i></div><button class="btn sm" id="cMute">${CALL.muted ? '🔇' : '🎙'}</button><button class="btn sm danger" id="cEnd">${esc(t('hangup'))}</button>`;
  paintHeads(b); $('#cEnd').onclick = () => endCall(true);
  $('#cMute').onclick = () => { CALL.muted = !CALL.muted; CALL.stream && CALL.stream.getAudioTracks().forEach(tr => tr.enabled = !CALL.muted); callBar(); };
}
async function setupPC(initiator) {
  const pc = CALL.pc = new RTCPeerConnection(ICE);
  try { CALL.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); }
  catch (e) { toast('Microphone unavailable: ' + e.message, 'err'); endCall(true); return; }
  CALL.stream.getTracks().forEach(tr => pc.addTrack(tr, CALL.stream));
  pc.ontrack = (e) => { $('#remoteAudio').srcObject = e.streams[0]; };
  pc.onicecandidate = (e) => { if (e.candidate) fsend({ t: 'call.signal', to: CALL.peer, data: { candidate: e.candidate } }); };
  pc.onconnectionstatechange = () => { if (pc.connectionState === 'connected') { CALL.state = 'active'; callBar(); } if (['failed', 'closed'].includes(pc.connectionState)) endCall(false); };
  if (initiator) { const o = await pc.createOffer(); await pc.setLocalDescription(o); fsend({ t: 'call.signal', to: CALL.peer, data: { sdp: pc.localDescription } }); }
}
function startCall(id) { if (CALL.state !== 'idle') return endCall(true); CALL.peer = id; CALL.state = 'ringing'; fsend({ t: 'call.invite', to: id }); callBar(); renderChat(); }
function endCall(notify) { if (notify && CALL.peer) fsend({ t: 'call.end', to: CALL.peer }); CALL.pc && CALL.pc.close(); CALL.stream && CALL.stream.getTracks().forEach(tr => tr.stop()); Object.assign(CALL, { peer: null, state: 'idle', pc: null, stream: null, muted: false }); $('#remoteAudio').srcObject = null; callBar(); renderChat(); }
async function onCallMsg(m) {
  const from = m.from && (m.from.id || m.from);
  if (m.t === 'call.invite') {
    if (CALL.state !== 'idle') { fsend({ t: 'call.decline', to: from }); return; }
    const u = m.from; if (!findFriend(u.id)) return;
    const mm = modal(`<div style="text-align:center">${headImg(u.provider, u.uuid, u.name)}<h3 style="margin-top:12px">${esc(u.name)} is calling…</h3><div class="callbar" style="position:static;transform:none;justify-content:center;border:0;box-shadow:none;background:none"><div class="wave"><i></i><i></i><i></i><i></i></div></div><div class="acts" style="justify-content:center"><button class="btn danger" id="cDec">${esc(t('decline'))}</button><button class="btn primary" id="cAcc">${esc(t('accept'))}</button></div></div>`, { dismiss: false });
    paintHeads(mm.el); const to = setTimeout(() => { mm.close(); }, 40000);
    $('#cDec', mm.el).onclick = () => { clearTimeout(to); mm.close(); fsend({ t: 'call.decline', to: u.id }); };
    $('#cAcc', mm.el).onclick = async () => { clearTimeout(to); mm.close(); CALL.peer = u.id; CALL.state = 'connecting'; callBar(); fsend({ t: 'call.accept', to: u.id }); await setupPC(false); };
  } else if (m.t === 'call.accepted' && CALL.peer === from) { CALL.state = 'connecting'; callBar(); await setupPC(true); }
  else if (m.t === 'call.declined' && CALL.peer === from) { toast('Call declined'); endCall(false); }
  else if (m.t === 'call.ended' && CALL.peer === from) { toast('Call ended'); endCall(false); }
  else if (m.t === 'call.signal' && CALL.peer === from && CALL.pc) {
    const d = m.data || {};
    try {
      if (d.sdp) { await CALL.pc.setRemoteDescription(d.sdp); if (d.sdp.type === 'offer') { const a = await CALL.pc.createAnswer(); await CALL.pc.setLocalDescription(a); fsend({ t: 'call.signal', to: from, data: { sdp: CALL.pc.localDescription } }); } }
      else if (d.candidate) await CALL.pc.addIceCandidate(d.candidate);
    } catch (e) { console.warn(e); }
  }
}

// ---- delegated clicks inside the friends view ----
document.addEventListener('click', (e) => {
  const v = e.target.closest('#v-friends'); if (!v) return;
  const g = (sel, k) => { const n = e.target.closest(sel); return n ? n.dataset[k] : null; };
  let x;
  if ((x = g('[data-add]', 'add'))) { fsend({ t: 'friend.request', to: x }); toast('Request sent', 'good'); }
  else if ((x = g('[data-acc]', 'acc'))) fsend({ t: 'friend.accept', from: x });
  else if ((x = g('[data-dec]', 'dec'))) { fsend({ t: 'friend.decline', from: x }); FR.incoming = FR.incoming.filter(u => u.id !== x); renderFriends(); }
  else if ((x = g('[data-cancel]', 'cancel'))) { fsend({ t: 'friend.cancel', to: x }); FR.outgoing = FR.outgoing.filter(u => u.id !== x); renderFriends(); }
  else if ((x = g('[data-join]', 'join'))) joinFriend(x);
  else if ((x = g('[data-invite]', 'invite'))) inviteFriend(x);
  else if ((x = g('[data-call]', 'call'))) startCall(x);
  else if ((x = g('[data-unfriend]', 'unfriend'))) { if (confirm('Remove this friend?')) fsend({ t: 'friend.remove', user: x }); }
  else if ((x = g('[data-prof]', 'prof'))) fsend({ t: 'profile', user: x });
  else if ((x = g('[data-fid]', 'fid'))) openChat(x);
  else if (e.target.closest('[data-act="friendsRetry"]')) friendsAccountChanged();
});
