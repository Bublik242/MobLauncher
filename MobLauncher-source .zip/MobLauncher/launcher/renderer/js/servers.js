'use strict';
// ---------------- SERVERS view ----------------
async function renderServers() {
  const el = $('#v-servers');
  let list = []; try { list = await api('servers:list'); } catch (e) { fail(e); }
  el.innerHTML = `<h2>${esc(t('servers'))}</h2><div class="sub">Your favourite Minecraft servers — see who is online and join with one click.</div>
  <div class="glass set-sec"><div class="row" style="gap:10px;flex-wrap:wrap"><input class="in" id="svName" placeholder="Name (optional)" style="width:200px"><input class="in grow" id="svAddr" placeholder="play.example.com or 1.2.3.4:25565" style="min-width:220px"><button class="btn primary" id="svAdd">${ICONS.plus} Add</button></div></div>
  <div class="ilist" id="svList" style="margin-top:14px">${list.map(s => `<div class="item" data-sid="${esc(s.id)}"><div class="ic" style="display:grid;place-items:center;background:var(--bg-3);border-radius:9px;width:48px;height:48px;overflow:hidden"><img class="svIcon hide" style="width:48px;height:48px" alt=""><span class="svDot">${ICONS.servers}</span></div><div class="grow"><div class="nm">${esc(s.name)} <span class="muted" style="font-size:12px">${esc(s.address)}</span></div><div class="vs svInfo">Pinging…</div></div><button class="btn primary sm" data-svplay="${esc(s.address)}">▶ ${esc(t('play'))}</button><button class="btn sm danger" data-svdel="${esc(s.id)}">✕</button></div>`).join('') || `<div class="empty"><div style="font-size:42px">🌐</div><div>No servers yet. Add one above.</div></div>`}</div>`;
  $('#svAdd').onclick = async () => { try { await api('servers:add', $('#svName').value, $('#svAddr').value); renderServers(); } catch (e) { fail(e); } };
  $('#svList').onclick = async (e) => {
    const d = e.target.closest('[data-svdel]'); if (d) { await api('servers:remove', d.dataset.svdel); return renderServers(); }
    const p = e.target.closest('[data-svplay]'); if (p) { if (!curInst()) return toast('Create a build first.', ''); setTab('play'); return launch({ server: p.dataset.svplay }); }
  };
  for (const row of $$('.item[data-sid]', el)) {
    const s = list.find(x => x.id === row.dataset.sid);
    api('servers:ping', s.address).then(r => {
      const info = $('.svInfo', row); if (!info) return;
      if (!r.online) { info.innerHTML = '<span style="color:#ff9aa4">● Offline</span>'; return; }
      info.innerHTML = `<span style="color:var(--green-3)">● ${r.players ? r.players.online + '/' + r.players.max + ' players' : 'Online'}</span> · ${r.ms} ms${r.version ? ' · ' + esc(r.version) : ''}${r.motd ? `<div class="muted" style="font-size:12px">${esc(r.motd)}</div>` : ''}`;
      if (r.favicon && /^data:image\/png;base64,/.test(r.favicon)) { const im = $('.svIcon', row); im.src = r.favicon; im.classList.remove('hide'); $('.svDot', row).classList.add('hide'); }
    }).catch(() => {});
  }
}
