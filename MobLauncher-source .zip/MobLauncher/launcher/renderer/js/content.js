'use strict';
// ---------------- Mod / pack browser (Modrinth + CurseForge) ----------------
// opts: { type:'mod'|'resourcepack'|'shader'|'modpack', instanceId }
function openBrowser(opts = {}) {
  const inst = opts.instanceId ? S.instances.find(i => i.id === opts.instanceId) : null;
  const st = { provider: 'modrinth', type: opts.type || 'mod', q: '', items: [], total: 0, offset: 0, sel: null, loading: false, token: 0 };
  const m = modal(`<div class="cb-top">
      <div class="chips" id="cbProv"><button class="chip on" data-p="modrinth">Modrinth</button><span id="cfSlot"></span></div>
      <div class="chips" id="cbType">${(opts.instanceId ? ['mod', 'resourcepack', 'shader'] : ['modpack']).map(k => `<button class="chip ${k === st.type ? 'on' : ''}" data-t="${k}">${esc({ mod: t('mods'), resourcepack: t('resourcepacks'), shader: t('shaders'), modpack: t('modpacks') }[k])}</button>`).join('')}</div>
      <div class="search grow" style="min-width:220px">${ICONS.search}<input class="in" id="cbQ" placeholder="${esc(t('searchPlaceholder'))}"></div>
      ${inst ? `<span class="tag">Minecraft ${esc(inst.mcVersion)} · ${esc(LOADER_NAME[inst.loader])}</span>` : ''}
      <button class="btn sm" data-close>✕</button></div>
    <div class="cb"><div class="cb-list" id="cbList"></div><div class="cb-detail" id="cbDetail"><div class="empty"><div style="font-size:46px">🧩</div><div>Select something on the left to see its page.</div></div></div></div>`, { wide: true });
  const list = $('#cbList', m.el), det = $('#cbDetail', m.el);
  let timer;
  api('content:cf').then(ok => { const sl = $('#cfSlot', m.el); if (sl && ok) sl.outerHTML = '<button class="chip" data-p="curseforge">CurseForge</button>'; }).catch(() => {});
  const renderList = (append) => {
    const html = st.items.map(x => `<div class="res ${st.sel && st.sel.id === x.id ? 'on' : ''}" data-id="${esc(x.id)}"><img src="" data-src="${esc(x.icon || '')}" alt=""><div class="grow"><b style="display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(x.title)}</b><span class="muted" style="font-size:11px">${esc(x.author || '')} · ⬇ ${fmtNum(x.downloads)}</span><p>${esc(x.description || '')}</p></div></div>`).join('');
    list.innerHTML = html + (st.items.length < st.total ? `<button class="btn sm" style="width:100%;margin-top:8px" id="cbMore">Load more</button>` : '') || `<div class="empty">Nothing found</div>`;
    $$('img[data-src]', list).forEach(async img => { if (!img.dataset.src) return; try { img.src = await api('img:proxy', img.dataset.src); } catch {} });
  };
  const run = async (more) => {
    const token = ++st.token; if (!more) { st.offset = 0; st.items = []; list.innerHTML = '<div class="skel"></div>'.repeat(7); }
    try {
      const r = await api('content:search', { provider: st.provider, type: st.type, query: st.q, mcVersion: inst ? inst.mcVersion : undefined, loader: inst ? inst.loader : undefined, offset: st.offset, sort: st.q ? 'relevance' : 'downloads' });
      if (token !== st.token) return; st.total = r.total; st.items = st.items.concat(r.items); st.offset = st.items.length; renderList();
    } catch (e) {
      if (token !== st.token) return;
      if (st.provider === 'curseforge' && /CF_KEY_MISSING/.test(e.message + (e.code || ''))) { st.provider = 'modrinth'; $$('#cbProv .chip', m.el).forEach(c => c.classList.toggle('on', c.dataset.p === 'modrinth')); toast('CurseForge is not set up in this build yet — showing Modrinth.', ''); return run(); }
      if (e.code === 'CF_KEY_MISSING') { list.innerHTML = `<div class="info" style="margin:8px">CurseForge needs a free API key. Get one at <a href="#" data-open="https://console.curseforge.com" style="color:var(--green-3)">console.curseforge.com</a>, then paste it here:<div class="field" style="margin-top:10px"><input class="in" id="cfKey" placeholder="$2a$10$…"></div><button class="btn primary sm" id="cfSave">Save key</button></div>`; $('#cfSave', list).onclick = async () => { S.settings = await api('settings:set', { curseforgeKey: $('#cfKey', list).value.trim() }); run(); }; }
      else list.innerHTML = `<div class="empty">⚠ ${esc(e.message)}<button class="btn sm" id="cbRetry">Retry</button></div>`;
    }
  };
  const showProject = async (item) => {
    st.sel = item; $$('.res', list).forEach(r => r.classList.toggle('on', r.dataset.id === item.id));
    det.innerHTML = '<div class="skel" style="height:34px;width:50%"></div><div class="skel" style="height:190px"></div><div class="skel" style="height:300px"></div>';
    try {
      const p = await api('content:project', { provider: st.provider, id: item.id, type: st.type });
      if (st.sel !== item) return;
      let body = p.bodyHtml || (window.marked ? marked.parse(p.bodyMd || '', { gfm: true, breaks: false }) : esc(p.bodyMd || ''));
      body = DOMPurify.sanitize(body, { FORBID_TAGS: ['style', 'form', 'input', 'button', 'iframe', 'script'], FORBID_ATTR: ['style', 'onerror', 'onclick'] });
      const act = st.type === 'modpack' ? `<button class="btn primary" id="cbInstall">⬇ Create build from this modpack</button>` : `<button class="btn primary" id="cbInstall">⬇ ${esc(t('install'))} → ${esc(inst ? inst.name : '')}</button>`;
      det.innerHTML = `<div class="row" style="gap:16px;margin-bottom:14px"><img src="" id="pjIcon" style="width:72px;height:72px;border-radius:16px;object-fit:cover;background:var(--bg-3)" alt=""><div class="grow"><h2 style="margin:0;font-size:26px">${esc(p.title)}</h2><div class="muted">${esc(p.author || '')} · ⬇ ${fmtNum(p.downloads)}${p.updated ? ' · ' + esc(new Date(p.updated).toLocaleDateString()) : ''}</div><div style="margin-top:6px">${(p.categories || []).slice(0, 6).map(c => `<span class="tag" style="margin-right:6px">${esc(c)}</span>`).join('')}</div></div><div style="text-align:right">${act}<div class="bar hide" id="cbBar" style="margin-top:10px"><i style="width:100%"></i></div><div class="muted" id="cbMsg" style="font-size:12px;margin-top:6px"></div></div></div>
        <p style="margin-bottom:16px;font-size:15px">${esc(p.summary || '')}</p>
        ${p.gallery && p.gallery.length ? `<div class="gallery" id="pjGal">${p.gallery.slice(0, 12).map(g => `<img src="" data-src="${esc(g.url)}" title="${esc(g.title || '')}" alt="">`).join('')}</div>` : ''}
        <div class="md" id="pjBody">${body}</div>`;
      if (p.icon) api('img:proxy', p.icon).then(u => { const i = $('#pjIcon', det); if (i) i.src = u; }).catch(() => {});
      $$('#pjGal img', det).forEach(async img => { try { img.src = await api('img:proxy', img.dataset.src); } catch { img.remove(); } });
      // images inside the description: proxy them (CSP blocks remote) – lazy
      $$('#pjBody img', det).forEach(async img => { const src = img.getAttribute('src'); img.removeAttribute('src'); if (src && /^https:/.test(src)) { try { img.src = await api('img:proxy', src); } catch { img.remove(); } } else img.remove(); });
      $$('#pjBody a', det).forEach(a => { const h = a.getAttribute('href'); a.removeAttribute('href'); if (h && /^https?:/.test(h)) a.dataset.open = h; });
      $('#cbInstall', det).onclick = () => doInstall(item, p);
    } catch (e) { det.innerHTML = `<div class="empty">⚠ ${esc(e.message)}</div>`; }
  };
  const doInstall = async (item, p) => {
    const btn = $('#cbInstall', det), bar = $('#cbBar', det), msg = $('#cbMsg', det);
    btn.disabled = true; bar.classList.remove('hide'); msg.textContent = t('installing');
    const off1 = on('content:progress', (d) => { if (d.stage) msg.textContent = d.stage; if (d.warn) msg.textContent = '⚠ ' + d.warn; });
    const off2 = on('install:progress', (d) => { msg.textContent = `${d.stage || ''} ${d.detail || ''}`; if (d.pct != null) bar.firstElementChild.style.width = d.pct + '%'; });
    try {
      if (st.type === 'modpack') {
        bar.firstElementChild.style.width = '2%';
        const ni = await api('content:modpack', { provider: st.provider, id: item.id, title: p.title, icon: p.icon });
        S.instances = await api('inst:list'); S.selInst = ni.id; toast(`${p.title} ✓`, 'good'); m.close(); setTab('builds'); renderAll();
      } else {
        const r = await api('content:install', { instanceId: opts.instanceId, provider: st.provider, id: item.id, type: st.type, title: p.title, icon: p.icon });
        toast(`${p.title} ${t('installed').toLowerCase()} (${r.length} file${r.length > 1 ? 's' : ''})`, 'good'); btn.textContent = '✓ ' + t('installed'); msg.textContent = r.join(', ');
        renderBuildBody();
      }
    } catch (e) { btn.disabled = false; msg.textContent = ''; fail(e); }
    finally { off1(); off2(); bar.classList.add('hide'); }
  };
  m.el.addEventListener('click', (e) => {
    const pr = e.target.closest('[data-p]'); if (pr) { st.provider = pr.dataset.p; $$('#cbProv .chip', m.el).forEach(c => c.classList.toggle('on', c === pr)); run(); return; }
    const ty = e.target.closest('[data-t]'); if (ty) { st.type = ty.dataset.t; $$('#cbType .chip', m.el).forEach(c => c.classList.toggle('on', c === ty)); run(); return; }
    const r = e.target.closest('.res'); if (r) { showProject(st.items.find(x => x.id === r.dataset.id)); return; }
    if (e.target.id === 'cbMore') { run(true); return; } if (e.target.id === 'cbRetry') { run(); return; }
    const a = e.target.closest('[data-open]'); if (a) { e.preventDefault(); api('shell:open', a.dataset.open); }
  });
  $('#cbQ', m.el).addEventListener('input', (e) => { clearTimeout(timer); timer = setTimeout(() => { st.q = e.target.value.trim(); run(); }, 350); });
  run();
}
