'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const S = { settings: {}, accounts: [], selectedAcc: null, instances: [], selInst: null, running: new Set(), progress: null, logs: [], tab: 'play', sys: {}, friends: { state: 'offline', list: [], incoming: [], outgoing: [], unread: {}, msgs: {}, active: null, me: null } };

async function api(ch, ...args) {
  const r = await window.mob.invoke(ch, ...args);
  if (!r.ok) { const e = new Error(r.error); e.code = r.code; throw e; }
  return r.data;
}
const on = (ch, cb) => window.mob.on(ch, cb);

const ICONS = {
  servers: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="6" rx="2"/><rect x="3" y="14" width="18" height="6" rx="2"/><circle cx="7" cy="7" r=".8"/><circle cx="7" cy="17" r=".8"/></svg>',
  play: '<svg viewBox="0 0 24 24"><path d="M7 4.5v15l12-7.5z"/></svg>', builds: '<svg viewBox="0 0 24 24"><path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M12 12l8-4.5M12 12v9M12 12L4 7.5"/></svg>',
  friends: '<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17.5" cy="9" r="2.6"/><path d="M17 14.2c2.6.2 4.5 2 4.5 5.1"/></svg>',
  avatar: '<svg viewBox="0 0 24 24"><rect x="5" y="3" width="14" height="9" rx="2"/><path d="M8 12v3M16 12v3M5 15h14v6H5z"/></svg>', settings: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/></svg>',
  search: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>', plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
  folder: '<svg viewBox="0 0 24 24"><path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>', phone: '<svg viewBox="0 0 24 24"><path d="M22 16.9v3a2 2 0 01-2.2 2 19.8 19.8 0 01-8.6-3.1 19.5 19.5 0 01-6-6A19.8 19.8 0 012.1 4.2 2 2 0 014.1 2h3a2 2 0 012 1.7c.1 1 .4 1.9.7 2.8a2 2 0 01-.5 2.1L8.1 9.9a16 16 0 006 6l1.3-1.3a2 2 0 012.1-.4c.9.3 1.8.6 2.8.7a2 2 0 011.7 2z"/></svg>',
};
const CUBE_COLORS = [['#4ade80', '#16a34a', '#14532d'], ['#60a5fa', '#2563eb', '#1e3a8a'], ['#f472b6', '#db2777', '#831843'], ['#fbbf24', '#d97706', '#78350f'], ['#a78bfa', '#7c3aed', '#4c1d95'], ['#fb7185', '#e11d48', '#881337'], ['#2dd4bf', '#0d9488', '#134e4a'], ['#e5e7eb', '#9ca3af', '#4b5563']];
function cubeSVG(i = 0, s = 56, letter = '') {
  const [a, b, c] = CUBE_COLORS[i % CUBE_COLORS.length]; const id = 'g' + Math.random().toString(36).slice(2, 7);
  return `<svg class="cube" style="--s:${s}px" viewBox="0 0 64 64"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${a}" stop-opacity=".7"/></linearGradient></defs><polygon points="32,4 58,18 32,32 6,18" fill="url(#${id})"/><polygon points="6,18 32,32 32,60 6,46" fill="${b}"/><polygon points="32,32 58,18 58,46 32,60" fill="${c}"/>${letter ? `<text x="19" y="48" text-anchor="middle" font-family="Outfit" font-weight="800" font-size="15" fill="#fff" opacity=".9" transform="skewY(26) translate(0,-24)">${esc(letter)}</text>` : ''}</svg>`;
}

// ---------- toast / modal ----------
const _toastSeen = new Map();
function toast(msg, kind = '') { const now = Date.now(); if (now - (_toastSeen.get(msg) || 0) < 6000) return; _toastSeen.set(msg, now); const d = document.createElement('div'); d.className = kind; d.textContent = msg; $('#toast').appendChild(d); setTimeout(() => { d.style.transition = '.3s'; d.style.opacity = 0; d.style.transform = 'translateX(30px)'; setTimeout(() => d.remove(), 300); }, kind === 'err' ? 7000 : 3500); }
const fail = (e) => { console.error(e); toast(e && e.message ? e.message : String(e), 'err'); };
function modal(html, { wide = false, dismiss = true, onClose } = {}) {
  const mask = document.createElement('div'); mask.className = 'mask';
  mask.innerHTML = `<div class="modal${wide ? ' wide' : ''}">${html}</div>`;
  const close = () => { mask.style.opacity = 0; mask.style.transition = '.2s'; setTimeout(() => mask.remove(), 180); onClose && onClose(); };
  mask.addEventListener('mousedown', (e) => { if (dismiss && e.target === mask) close(); });
  mask.addEventListener('click', (e) => { if (e.target.closest('[data-close]')) close(); });
  $('#modals').appendChild(mask);
  return { el: mask.firstElementChild, mask, close };
}
const fmtTime = (s) => { s = s || 0; const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return h ? `${h}h ${m}m` : `${m}m`; };
const fmtNum = (n) => n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1) + 'K' : String(n || 0);
const LOADER_NAME = { vanilla: 'Vanilla', fabric: 'Fabric', quilt: 'Quilt', forge: 'Forge', neoforge: 'NeoForge' };
const curInst = () => S.instances.find(i => i.id === S.selInst) || null;
const curAcc = () => S.accounts.find(a => a.id === S.selectedAcc) || null;

// ---------- skins / heads ----------
// Original generated default skin (64x64) – used until a real skin loads
function defaultSkinDataURL(seed = 0) {
  const c = document.createElement('canvas'); c.width = 64; c.height = 64; const x = c.getContext('2d');
  const skin = '#d9a77a', hair = '#2b1d12', shirt = '#22c55e', shirt2 = '#16a34a', pants = '#1f2937', shoe = '#0b0f14';
  const R = (col, a, b, w, h) => { x.fillStyle = col; x.fillRect(a, b, w, h); };
  R(skin, 0, 0, 32, 16); R(hair, 8, 0, 8, 8); R(hair, 0, 8, 32, 4); R(skin, 8, 12, 8, 4); // head
  R(skin, 8, 8, 8, 8); R(hair, 8, 8, 8, 2); R('#fff', 9, 11, 2, 2); R('#fff', 13, 11, 2, 2); R('#1b4332', 10, 11, 1, 2); R('#1b4332', 14, 11, 1, 2); R('#a0522d', 10, 14, 4, 1);
  R(hair, 24, 8, 8, 8); R(hair, 16, 8, 8, 4); // back + sides
  R(shirt, 16, 16, 24, 16); R(shirt2, 20, 20, 8, 12); R('#eafff2', 22, 23, 4, 1); // torso
  R(pants, 0, 16, 16, 16); R(shoe, 4, 30, 4, 2); R(shoe, 0, 30, 4, 2); // right leg
  R(shirt2, 40, 16, 16, 16); R(skin, 44, 28, 4, 4); // right arm
  R(pants, 16, 48, 16, 16); R(shoe, 20, 62, 4, 2); // left leg
  R(shirt2, 32, 48, 16, 16); R(skin, 36, 60, 4, 4); R(shirt2, 40, 48, 16, 16);
  return c.toDataURL('image/png');
}
const headCache = new Map();
async function loadSkinURL(acc) {
  if (!acc) return null;
  const key = `${acc.type}:${acc.uuid}:${acc.skinUrl || ''}`;
  if (headCache.has(key)) return headCache.get(key);
  const p = (async () => { try { return await api('skin:get', { type: acc.type, uuid: acc.uuid, name: acc.name, url: acc.type === 'microsoft' ? acc.skinUrl : null }); } catch { return null; } })();
  headCache.set(key, p); return p;
}
function drawHead(img, skinURL) {
  const dflt = defaultSkinDataURL();
  const draw = (src) => { const im = new Image(); im.onload = () => { const c = document.createElement('canvas'); c.width = c.height = 32; const x = c.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(im, 8, 8, 8, 8, 0, 0, 32, 32); x.drawImage(im, 40, 8, 8, 8, 0, 0, 32, 32); img.src = c.toDataURL(); }; im.src = src; };
  draw(skinURL || dflt);
}
async function paintHeads(root = document) {
  for (const el of $$('img.head[data-type]', root)) {
    if (el.dataset.done === '1') continue; el.dataset.done = '1';
    drawHead(el, null);
    const url = await loadSkinURL({ type: el.dataset.type, uuid: el.dataset.uuid, name: el.dataset.name, skinUrl: el.dataset.skin || null });
    if (url) drawHead(el, url);
  }
}
const headImg = (type, uuid, name, skin) => `<img class="head" data-type="${esc(type)}" data-uuid="${esc(uuid)}" data-name="${esc(name)}" data-skin="${esc(skin || '')}" alt="">`;

// ---------- animated background (floating cubes & glow) ----------
function startBackground() {
  const cv = $('#bg'), ctx = cv.getContext('2d'); let W, H, items = [], raf, last = 0;
  const rs = () => { W = cv.width = innerWidth; H = cv.height = innerHeight; };
  rs(); addEventListener('resize', rs);
  for (let i = 0; i < 26; i++) items.push({ x: Math.random(), y: Math.random(), s: 14 + Math.random() * 46, v: .012 + Math.random() * .03, r: Math.random() * 6, rv: (Math.random() - .5) * .004, a: .05 + Math.random() * .12 });
  const hex = (x, y, s, r, a) => {
    ctx.save(); ctx.translate(x, y); ctx.rotate(r * .15); ctx.globalAlpha = a; ctx.strokeStyle = '#4ade80'; ctx.lineWidth = 1.2; ctx.beginPath();
    for (let i = 0; i < 6; i++) { const an = Math.PI / 3 * i + Math.PI / 6; ctx.lineTo(Math.cos(an) * s, Math.sin(an) * s); } ctx.closePath(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(Math.PI / 6) * s, Math.sin(Math.PI / 6) * s); ctx.moveTo(0, 0); ctx.lineTo(0, -s); ctx.moveTo(0, 0); ctx.lineTo(-Math.cos(Math.PI / 6) * s, Math.sin(Math.PI / 6) * s); ctx.stroke();
    ctx.globalAlpha = a * .35; ctx.fillStyle = '#22c55e'; ctx.fill(); ctx.restore();
  };
  const frame = (t) => {
    raf = requestAnimationFrame(frame); if (document.hidden || S.settings.reducedMotion || t - last < 33) return; last = t;
    ctx.clearRect(0, 0, W, H);
    const g = ctx.createRadialGradient(W * .75, H * .2, 0, W * .75, H * .2, W * .6); g.addColorStop(0, 'rgba(34,197,94,.13)'); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    for (const it of items) { it.y -= it.v * .033; it.r += it.rv; if (it.y < -.1) { it.y = 1.1; it.x = Math.random(); } hex(it.x * W, it.y * H, it.s, it.r, it.a); }
  };
  raf = requestAnimationFrame(frame);
}
