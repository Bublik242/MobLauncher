'use strict';
const { shell } = require('electron');
const { P } = require('./paths');
const U = require('./util');
const { path, fsp } = U;

const dirOf = (id) => path.join(P.instances, id);
const fileOf = (id) => path.join(dirOf(id), 'instance.json');
const gameOf = (id) => path.join(dirOf(id), 'game');
const SUB = { mod: 'mods', resourcepack: 'resourcepacks', shader: 'shaderpacks', datapack: 'datapacks' };

async function list() {
  await fsp.mkdir(P.instances, { recursive: true });
  const out = [];
  for (const d of await fsp.readdir(P.instances)) {
    const j = await U.readJSON(fileOf(d));
    if (j) out.push(j);
  }
  return out.sort((a, b) => (b.lastPlayed || 0) - (a.lastPlayed || 0) || (b.created || 0) - (a.created || 0));
}
async function get(id) { const j = await U.readJSON(fileOf(id)); if (!j) throw new Error('Instance not found'); return j; }
async function save(inst) { await U.writeJSON(fileOf(inst.id), inst); return inst; }

async function create({ name, mcVersion, loader = 'vanilla', loaderVersion = '', icon = 0 }) {
  name = String(name || '').trim();
  if (!name) throw new Error('Give your build a name.');
  if (!mcVersion) throw new Error('Choose a Minecraft version.');
  const id = U.sanitize(name).replace(/\s+/g, '-').toLowerCase() + '-' + U.uid().slice(0, 4);
  const inst = { id, name, mcVersion, loader, loaderVersion, icon, created: Date.now(), lastPlayed: 0, playTime: 0, memoryMinMB: 0, memoryMaxMB: 0, jvmArgs: '', width: 0, height: 0, resolvedVersion: '' };
  await fsp.mkdir(path.join(gameOf(id), 'mods'), { recursive: true });
  await save(inst);
  return inst;
}
async function update(id, patch) {
  const inst = await get(id);
  const loaderChanged = ('loader' in patch && patch.loader !== inst.loader) || ('mcVersion' in patch && patch.mcVersion !== inst.mcVersion) || ('loaderVersion' in patch && patch.loaderVersion !== inst.loaderVersion);
  Object.assign(inst, patch, { id });
  if (loaderChanged) { inst.resolvedVersion = ''; inst.ready = false; }
  return save(inst);
}
async function remove(id) { await fsp.rm(dirOf(id), { recursive: true, force: true }); return true; }
async function duplicate(id) {
  const inst = await get(id);
  const copy = await create({ name: inst.name + ' copy', mcVersion: inst.mcVersion, loader: inst.loader, loaderVersion: inst.loaderVersion, icon: inst.icon });
  await fsp.cp(gameOf(id), gameOf(copy.id), { recursive: true });
  return copy;
}
function openFolder(id, sub) { return shell.openPath(sub ? path.join(gameOf(id), sub) : gameOf(id)); }

// ----- content tracking (what we installed from Modrinth/CurseForge) -----
const trackFile = (id) => path.join(dirOf(id), 'content.json');
async function tracked(id) { return (await U.readJSON(trackFile(id), [])) || []; }
async function track(id, entry) {
  const t = (await tracked(id)).filter(e => !(e.type === entry.type && e.projectId === entry.projectId && e.provider === entry.provider));
  t.push(entry); await U.writeJSON(trackFile(id), t);
}

async function listContent(id, type) {
  const sub = path.join(gameOf(id), SUB[type] || 'mods');
  await fsp.mkdir(sub, { recursive: true });
  const t = await tracked(id);
  const out = [];
  for (const f of await fsp.readdir(sub)) {
    if (!/\.(jar|zip|disabled)$/i.test(f)) continue;
    const enabled = !f.endsWith('.disabled');
    const base = enabled ? f : f.slice(0, -9);
    const st = await fsp.stat(path.join(sub, f)).catch(() => null);
    if (!st || st.isDirectory()) continue;
    const tr = t.find(e => e.file === base && e.type === type);
    out.push({ file: f, base, enabled, size: st.size, name: tr ? tr.name : base.replace(/\.(jar|zip)$/i, ''), version: tr ? tr.version : '', projectId: tr ? tr.projectId : null, provider: tr ? tr.provider : null, icon: tr ? tr.icon : null });
  }
  return out.sort((a, b) => a.name.localeCompare(b.name));
}
async function toggleContent(id, type, file) {
  const sub = path.join(gameOf(id), SUB[type]);
  const to = file.endsWith('.disabled') ? file.slice(0, -9) : file + '.disabled';
  await fsp.rename(path.join(sub, file), path.join(sub, to));
  return listContent(id, type);
}
async function removeContent(id, type, file) {
  const sub = path.join(gameOf(id), SUB[type]);
  await fsp.rm(path.join(sub, file), { force: true });
  const base = file.endsWith('.disabled') ? file.slice(0, -9) : file;
  const t = (await tracked(id)).filter(e => !(e.file === base && e.type === type));
  await U.writeJSON(trackFile(id), t);
  return listContent(id, type);
}

// mod list for friends' compatibility check
async function modsForPresence(id) {
  const items = (await listContent(id, 'mod')).filter(m => m.enabled);
  const t = await tracked(id);
  const out = [];
  for (const m of items) {
    let sha1 = ''; try { sha1 = await U.sha1File(path.join(gameOf(id), 'mods', m.file)); } catch {}
    const tr = t.find(e => e.file === m.base && e.type === 'mod');
    out.push({ id: tr ? `${tr.provider}:${tr.projectId}` : `file:${m.base}`, name: m.name, version: m.version || '', sha1 });
  }
  return out;
}

module.exports = { list, get, save, create, update, remove, duplicate, openFolder, listContent, toggleContent, removeContent, track, tracked, modsForPresence, gameOf, dirOf, SUB };
