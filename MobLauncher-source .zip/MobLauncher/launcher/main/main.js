'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell, session } = require('electron');
const path = require('path');
const fs = require('fs');

function startUninstall(deleteData) {
  const { spawn } = require('child_process');
  const os = require('os');
  const PP = require('./paths').P;
  const dir = path.dirname(app.getPath('exe'));
  const exeName = path.basename(app.getPath('exe'));
  const sm = path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs');
  const rmdir = (d) => `for /l %%i in (1,1,30) do ( if exist "${d}" ( rmdir /s /q "${d}" >nul 2>&1 & if exist "${d}" ping 127.0.0.1 -n 2 >nul ) )`;
  const lines = ['@echo off', 'ping 127.0.0.1 -n 3 >nul', `taskkill /f /im ${exeName} >nul 2>&1`, 'ping 127.0.0.1 -n 2 >nul',
    `del /f /q "${path.join(app.getPath('desktop'), 'MobLauncher.lnk')}" >nul 2>&1`, `del /f /q "${path.join(sm, 'MobLauncher.lnk')}" >nul 2>&1`, `rmdir /s /q "${path.join(sm, 'MobLauncher')}" >nul 2>&1`,
    'reg delete "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MobLauncher" /f >nul 2>&1', rmdir(dir)];
  if (deleteData) lines.push(rmdir(PP.dataDir));
  lines.push('(goto) 2>nul & del "%~f0"');
  const bat = path.join(os.tmpdir(), 'moblauncher-uninstall.bat');
  fs.writeFileSync(bat, lines.join('\r\n') + '\r\n');
  if (process.platform === 'win32') spawn('cmd.exe', ['/c', 'start', '""', '/min', bat], { detached: true, stdio: 'ignore', windowsHide: true, shell: false }).unref();
}
// ---- uninstall mode: Windows "Apps & features" runs  MobLauncher.exe --uninstall ----
if (process.argv.includes('--uninstall')) {
  app.whenReady().then(async () => {
    const { P: PP } = require('./paths');
    const r = await dialog.showMessageBox({ type: 'question', title: 'MobLauncher', message: 'Uninstall MobLauncher?', detail: 'The launcher will be removed from this computer.', buttons: ['Uninstall', 'Cancel'], defaultId: 1, cancelId: 1, checkboxLabel: 'Also delete my game data (worlds, mods, accounts)', checkboxChecked: false });
    if (r.response !== 0) return app.quit();
    startUninstall(r.checkboxChecked);
    app.quit();
  });
} else if (!app.requestSingleInstanceLock()) { app.quit(); }
app.commandLine.appendSwitch('enable-features', 'CanvasOopRasterization');

const { P, loadSettings, saveSettings } = require('./paths');
const U = require('./util');
const A = require('./accounts');
const MC = require('./minecraft');
const I = require('./instances');
const C = require('./content');
const F = require('./friends');

let win = null;
const emit = (ch, d) => { if (win && !win.isDestroyed()) win.webContents.send(ch, d); };
const running = new Map(); // instanceId -> { child, started }
let launching = false;

function createWindow() {
  win = new BrowserWindow({
    width: 1180, height: 740, minWidth: 980, minHeight: 620, frame: false, backgroundColor: '#050a07', show: false,
    icon: path.join(__dirname, '..', 'renderer', 'assets', 'icon.png'), title: 'MobLauncher',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false, spellcheck: false },
  });
  win.removeMenu();
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file:')) { e.preventDefault(); if (/^https?:/.test(url)) shell.openExternal(url); } });
}

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });
if (!process.argv.includes('--uninstall')) app.whenReady().then(async () => {
  // microphone for voice calls: allow only for our own UI
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(perm === 'media' || perm === 'clipboard-sanitized-write'));
  await fs.promises.mkdir(P.dataDir, { recursive: true });
  createWindow();
});
app.on('window-all-closed', () => { if (!running.size) app.quit(); });

const handle = (ch, fn) => ipcMain.handle(ch, async (_e, ...a) => {
  try { return { ok: true, data: await fn(...a) }; }
  catch (e) { return { ok: false, error: e.message || String(e), code: e.code }; }
});

// ---- window ----
handle('win:min', () => win.minimize());
handle('win:max', () => { win.isMaximized() ? win.unmaximize() : win.maximize(); return win.isMaximized(); });
handle('win:close', () => win.close());
handle('shell:open', (url) => { if (/^https?:\/\//.test(url)) return shell.openExternal(url); });
handle('dialog:file', async (filters) => { const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters }); return r.canceled ? null : r.filePaths[0]; });
handle('fs:readB64', async (p) => (await fs.promises.readFile(p)).toString('base64'));

// ---- settings / system ----
handle('settings:get', () => loadSettings());
handle('settings:set', (patch) => saveSettings(patch));
handle('system:info', () => ({ totalMB: MC.systemMemoryMB(), cpus: require('os').cpus().length, platform: process.platform, dataDir: P.dataDir, version: app.getVersion() }));
handle('system:openDataDir', () => shell.openPath(P.dataDir));

// ---- bootstrap from the installer ----
const FIRSTRUN = path.join(P.dataDir, 'firstrun.json'); // written by MobLauncher Setup
handle('bootstrap:get', async () => {
  const b = await U.readJSON(P.bootstrap);
  if (b) return b;
  const f = await U.readJSON(FIRSTRUN);
  if (f) return { accountChoice: f.account === 'ely' ? 'elyby' : f.account, offlineName: f.nick || '' };
  return null;
});
handle('bootstrap:done', async () => {
  for (const [a, b] of [[P.bootstrap, 'bootstrap.done.json'], [FIRSTRUN, 'firstrun.done.json']]) { try { await fs.promises.rename(a, path.join(P.dataDir, b)); } catch {} }
  return true;
});

// ---- accounts ----
handle('acc:list', () => A.list());
handle('acc:select', (id) => A.select(id));
handle('acc:remove', (id) => A.remove(id));
handle('acc:offline', (name) => A.addOffline(name));
handle('acc:elyby', (u, p, t) => A.loginElyby(u, p, t));
handle('acc:ms:start', async () => A.startMicrosoft((info) => emit('acc:ms:code', info)));
handle('acc:ms:cancel', () => A.cancelMicrosoft());
handle('acc:cape', (id, cape) => A.setCape(id, cape));
handle('acc:skin:upload', async (id, file, variant) => A.uploadSkin(id, await fs.promises.readFile(file), variant));
handle('acc:refresh', (id) => A.refreshProfile(id));

const SKIN_HOSTS = /^(textures\.minecraft\.net|skinsystem\.ely\.by|ely\.by|sessionserver\.mojang\.com)$/;
const skinCache = new Map();
handle('skin:get', async ({ type, uuid, name, url }) => {
  const key = `${type}:${uuid}:${name}:${url || ''}`;
  if (skinCache.has(key)) return skinCache.get(key);
  let target = url;
  if (!target) {
    if (type === 'microsoft') {
      const p = await U.getJSON(`https://sessionserver.mojang.com/session/minecraft/profile/${uuid}`);
      const tex = (p.properties || []).find(x => x.name === 'textures');
      if (tex) { const j = JSON.parse(Buffer.from(tex.value, 'base64').toString('utf8')); target = j.textures && j.textures.SKIN && j.textures.SKIN.url; }
    } else if (type === 'elyby') target = `http://skinsystem.ely.by/skins/${encodeURIComponent(name)}.png`;
  }
  if (!target) return null;
  const u = new URL(target.replace(/^http:/, 'https:'));
  if (!SKIN_HOSTS.test(u.hostname)) throw new Error('Blocked skin host');
  const r = await U.http(u.href, { allowError: true });
  if (!r.ok) return null;
  const buf = Buffer.from(await r.arrayBuffer());
  const out = 'data:image/png;base64,' + buf.toString('base64');
  skinCache.set(key, out); return out;
});
handle('img:proxy', async (url) => { // remote images for project galleries (avoids mixed content / CSP issues)
  const u = new URL(url); if (!/^https:$/.test(u.protocol)) throw new Error('bad url');
  const r = await U.http(u.href); const buf = Buffer.from(await r.arrayBuffer());
  return `data:${r.headers.get('content-type') || 'image/png'};base64,${buf.toString('base64')}`;
});

// ---- versions / instances ----
handle('mc:versions', () => MC.listVersions());
handle('mc:loaderVersions', (loader, mc) => MC.loaderVersions(loader, mc));
handle('inst:list', () => I.list());
handle('inst:create', (d) => I.create(d));
handle('inst:update', (id, patch) => I.update(id, patch));
handle('inst:delete', (id) => I.remove(id));
handle('inst:duplicate', (id) => I.duplicate(id));
handle('inst:openFolder', (id, sub) => I.openFolder(id, sub));
handle('inst:content', (id, type) => I.listContent(id, type));
handle('inst:toggle', (id, type, file) => I.toggleContent(id, type, file));
handle('inst:removeContent', (id, type, file) => I.removeContent(id, type, file));
handle('inst:mods', (id) => I.modsForPresence(id));
handle('inst:running', () => [...running.keys()]);

// ---- content browser ----
handle('content:search', (q) => C.search(q));
handle('content:project', (q) => C.project(q));
handle('content:install', (q) => C.install(q, (p) => emit('content:progress', { ...p, key: q.provider + ':' + q.id })));
handle('content:modpack', async (q) => { const inst = await C.installModpack(q, (p) => emit('install:progress', p)); return inst; });

// ---- uninstall from inside the launcher ----
handle('app:uninstall', async ({ deleteData }) => {
  if (process.platform !== 'win32' || !/MobLauncher\.exe$/i.test(app.getPath('exe'))) throw new Error('Uninstall is available in the installed Windows version of MobLauncher.');
  if (running.size) throw new Error('Close Minecraft first.');
  startUninstall(!!deleteData); setTimeout(() => app.quit(), 300); return true;
});
// ---- servers tab / updates / curseforge availability ----
const SV = require('./servers');
handle('servers:list', () => SV.list());
handle('servers:add', (n, a) => SV.add(n, a));
handle('servers:remove', (id) => SV.remove(id));
handle('servers:ping', (a) => SV.ping(a));
handle('content:cf', () => C.cfAvailable());
handle('content:updates', (id) => C.checkUpdates(id));
handle('content:applyUpdates', (id, list) => C.applyUpdates(id, list, (p) => emit('install:progress', p)));

// ---- crash analysis / self-repair ----
function analyzeCrash(lines) {
  const t = lines.slice(-500).join('\n');
  if (/OutOfMemoryError|Could not reserve enough space|GC overhead limit/.test(t)) return { reason: 'Not enough memory (RAM) for this build.', fix: 'memory' };
  if (/UnsupportedClassVersionError|class file version|has been compiled by a more recent version/.test(t)) return { reason: 'This build needs a different Java version.', fix: 'java' };
  if (/Could not find or load main class|NoClassDefFoundError|ClassNotFoundException|ZipException|Invalid or corrupt jarfile|UnsatisfiedLinkError|java\.util\.zip|SHA-?1/i.test(t)) return { reason: 'Some game files are damaged or missing.', fix: 'repair' };
  if (/Mixin apply failed|Mod resolution failed|Incompatible mods|Missing or unsupported mandatory dependencies|mod .* requires|MixinTransformerError/i.test(t)) return { reason: 'A mod is incompatible with this version or misses a dependency.', fix: 'mods' };
  return null;
}
handle('inst:repair', async (id) => {
  const inst = await I.get(id);
  const vid = await MC.repair(inst, (p) => emit('play:progress', { instanceId: id, ...p }));
  inst.resolvedVersion = vid; await I.save(inst); emit('play:progress', { instanceId: id, stage: 'Repaired', pct: 100, detail: '' }); return true;
});
handle('fix:apply', async ({ fix, instanceId }) => {
  const s = await loadSettings();
  if (fix === 'memory') { const max = Math.min(s.memoryMaxMB + 1024, Math.floor(MC.systemMemoryMB() * 0.7 / 256) * 256); await saveSettings({ memoryMaxMB: max }); const inst = await I.get(instanceId); if (inst.memoryMaxMB) { inst.memoryMaxMB = Math.max(inst.memoryMaxMB, max); await I.save(inst); } return { memoryMaxMB: max }; }
  if (fix === 'java') { await saveSettings({ javaMode: 'auto' }); return true; }
  if (fix === 'repair') { const inst = await I.get(instanceId); const vid = await MC.repair(inst, (p) => emit('play:progress', { instanceId, ...p })); inst.resolvedVersion = vid; await I.save(inst); return true; }
  return true;
});

// ---- play ----
handle('play', async ({ instanceId, accountId, server, installOnly }) => {
  if (launching) throw new Error('Another launch is in progress.');
  if (running.has(instanceId)) throw new Error('This build is already running.');
  launching = true;
  try {
    const inst = await I.get(instanceId);
    const account = installOnly ? { type: 'offline', name: 'Player', uuid: '0'.repeat(32), accessToken: '0', userType: 'legacy' } : await A.getLaunchAccount(accountId);
    const prep = await MC.prepareLaunch(inst, account, { server }, (p) => emit('play:progress', { instanceId, ...p }));
    inst.resolvedVersion = prep.versionId; inst.ready = true; await I.save(inst);
    if (installOnly) { emit('play:progress', { instanceId, stage: 'Ready to play', pct: 100, detail: '' }); return { installed: true }; }
    emit('play:progress', { instanceId, stage: 'Starting Minecraft', pct: 100, detail: '' });
    const started = Date.now();
    const logbuf = [];
    const s = await loadSettings();
    const child = MC.spawnGame(prep.java, prep.args, prep.gameDir, {
      onLog: (line) => {
        logbuf.push(line); if (logbuf.length > 800) logbuf.splice(0, 300);
        emit('game:log', { instanceId, line });
        const m = line.match(/Connecting to ([^,\s]+), (\d+)/);
        if (m) emit('game:server', { instanceId, server: m[2] === '25565' ? m[1] : `${m[1]}:${m[2]}` });
        if (/Stopping!|Setting user:|Backend library:|Loading Minecraft|Sound engine started/.test(line)) emit('game:ready', { instanceId });
      },
      onExit: async (code, err) => {
        running.delete(instanceId);
        const cur = await I.get(instanceId).catch(() => null);
        if (cur) { cur.playTime = (cur.playTime || 0) + Math.floor((Date.now() - started) / 1000); cur.lastPlayed = Date.now(); await I.save(cur); }
        emit('game:exit', { instanceId, code, error: err && err.message });
        if (code && code !== 0) { const a = analyzeCrash(logbuf) || { reason: 'The game crashed. Open the console on the Play tab for details.', fix: 'repair' }; emit('game:crash', { instanceId, code, ...a }); }
        if (win && !win.isDestroyed() && !win.isVisible()) win.show();
        if (!running.size && s.closeOnLaunch === 'quit' && (!win || win.isDestroyed())) app.quit();
      },
    });
    running.set(instanceId, { child, started });
    inst.lastPlayed = Date.now(); await I.save(inst);
    emit('game:start', { instanceId, pid: child.pid });
    if (s.closeOnLaunch === 'hide') win.hide(); else if (s.closeOnLaunch === 'quit') { setTimeout(() => win && win.close(), 4000); }
    return true;
  } finally { launching = false; }
});
handle('play:kill', (id) => { const r = running.get(id); if (r) r.child.kill(); return true; });

// ---- friends ----
handle('friends:connect', (accId) => F.connect(emit, accId));
handle('friends:disconnect', () => F.disconnect());
handle('friends:send', (m) => F.send(m));
handle('friends:state', () => F.getState());
