'use strict';
const os = require('os');
const cp = require('child_process');
const { P, loadSettings } = require('./paths');
const U = require('./util');
const { path, fsp } = U;

const MANIFEST = process.env.MOB_MANIFEST_URL || 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json';
const ASSETS_URL = (process.env.MOB_ASSETS_URL || 'https://resources.download.minecraft.net').replace(/\/$/, '');
const RUNTIME_ALL = 'https://launchermeta.mojang.com/v1/products/java-runtime/2ec0cc96c44e5a76b9c8b7c39df7210883d12871/all.json';
const LAUNCHER_VERSION = '1.0.0';

// ---------------- versions ----------------
async function getManifest() {
  const cacheFile = path.join(P.cache, 'version_manifest.json');
  const urls = [MANIFEST, 'https://launchermeta.mojang.com/mc/game/version_manifest_v2.json'];
  for (let attempt = 0; attempt < 3; attempt++) {
    for (const u of urls) {
      try { const j = await U.getJSON(u, { timeout: 20000 }); await U.writeJSON(cacheFile, j); return j; } catch {}
    }
    await new Promise(r => setTimeout(r, 700 * (attempt + 1)));
  }
  const c = await U.readJSON(cacheFile); if (c) return c;
  throw new Error('Cannot load the Minecraft version list. Check your internet connection (or VPN/firewall) and press Retry.');
}
async function listVersions() {
  const m = await getManifest();
  return m.versions.map(v => ({ id: v.id, type: v.type, releaseTime: v.releaseTime }));
}

const matchOS = (rule) => {
  if (!rule) return true;
  if (rule.name && rule.name !== U.osName) return false;
  if (rule.arch && rule.arch !== (process.arch === 'ia32' ? 'x86' : 'x64') && !(process.arch === 'arm64' && rule.arch === 'arm64')) return false;
  return true;
};
function rulesAllow(rules, features = {}) {
  if (!rules || !rules.length) return true;
  let allowed = false;
  for (const r of rules) {
    let ok = matchOS(r.os);
    if (ok && r.features) for (const k of Object.keys(r.features)) if (!!features[k] !== r.features[k]) ok = false;
    if (ok) allowed = r.action === 'allow';
  }
  return allowed;
}

async function installVanillaJson(id) {
  const file = path.join(P.versions, id, id + '.json');
  const local = await U.readJSON(file);
  if (local) return local;
  const m = await getManifest();
  const v = m.versions.find(x => x.id === id);
  if (!v) throw new Error('Unknown Minecraft version: ' + id);
  const j = await U.getJSON(v.url);
  await U.writeJSON(file, j);
  return j;
}

// resolve inheritsFrom chain into one merged version JSON
async function resolveVersion(id, seen = new Set()) {
  if (seen.has(id)) throw new Error('Version inheritance loop: ' + id);
  seen.add(id);
  const file = path.join(P.versions, id, id + '.json');
  let j = await U.readJSON(file);
  if (!j) j = await installVanillaJson(id);
  if (!j.inheritsFrom) return j;
  const parent = await resolveVersion(j.inheritsFrom, seen);
  const merged = { ...parent, ...j };
  merged.libraries = [...(j.libraries || []), ...(parent.libraries || [])];
  const pa = parent.arguments || {}, ca = j.arguments || {};
  if (parent.arguments || j.arguments) merged.arguments = { game: [...(pa.game || []), ...(ca.game || [])], jvm: [...(pa.jvm || []), ...(ca.jvm || [])] };
  if (!j.minecraftArguments && parent.minecraftArguments) merged.minecraftArguments = parent.minecraftArguments;
  merged.jarId = parent.jarId || j.inheritsFrom;
  merged.assetIndex = j.assetIndex || parent.assetIndex;
  merged.assets = j.assets || parent.assets;
  merged.downloads = j.downloads || parent.downloads;
  merged.javaVersion = j.javaVersion || parent.javaVersion;
  merged.logging = j.logging || parent.logging;
  return merged;
}

// ---------------- libraries ----------------
function libKey(l) { const [g, a, , c] = l.name.split(':'); return `${g}:${a}:${c || ''}`; }
function libFiles(ver) {
  const out = []; const seen = new Set();
  for (const l of ver.libraries) {
    if (!rulesAllow(l.rules)) continue;
    const key = libKey(l) + (l.natives ? ':nat' : '');
    if (seen.has(key)) continue; seen.add(key);
    const nameCls = l.name.split(':')[3] || '';
    // old-style natives
    if (l.natives && l.natives[U.osName]) {
      const cls = l.natives[U.osName].replace('${arch}', process.arch === 'ia32' ? '32' : '64');
      const art = l.downloads && l.downloads.classifiers && l.downloads.classifiers[cls];
      if (art) out.push({ name: l.name, path: art.path, url: art.url, sha1: art.sha1, size: art.size, native: true, classpath: false, exclude: (l.extract && l.extract.exclude) || ['META-INF/'] });
      continue;
    }
    // new-style natives (separate library entries)
    const isNative = /^natives-/.test(nameCls);
    if (isNative) {
      const want = U.osName === 'windows' ? 'natives-windows' : U.osName === 'osx' ? 'natives-macos' : 'natives-linux';
      if (!nameCls.startsWith(want)) continue;
      const arm = /arm64|aarch64/.test(nameCls);
      if (arm !== (process.arch === 'arm64')) continue;
    }
    let art = l.downloads && l.downloads.artifact;
    if (!art) { // fabric/quilt style: maven base url + name
      const rel = U.mavenPath(l.name);
      art = { path: rel, url: (l.url || 'https://libraries.minecraft.net/').replace(/\/?$/, '/') + rel };
    }
    out.push({ name: l.name, path: art.path, url: art.url, sha1: art.sha1, size: art.size, native: isNative, classpath: true, exclude: ['META-INF/'] });
  }
  return out;
}

async function extractNatives(files, nativesDir) {
  const AdmZip = require('adm-zip');
  await fsp.rm(nativesDir, { recursive: true, force: true });
  await fsp.mkdir(nativesDir, { recursive: true });
  for (const f of files) {
    if (!f.native) continue;
    const zip = new AdmZip(path.join(P.libraries, f.path));
    for (const e of zip.getEntries()) {
      if (e.isDirectory) continue;
      if ((f.exclude || []).some(x => e.entryName.startsWith(x))) continue;
      if (!/\.(dll|so|dylib|jnilib)$/i.test(e.entryName)) continue;
      await fsp.writeFile(path.join(nativesDir, path.basename(e.entryName)), e.getData());
    }
  }
}

// ---------------- full install of a (resolved) version ----------------
async function installGame(versionId, progress) {
  const ver = await resolveVersion(versionId);
  const jarId = ver.jarId || ver.id;
  const files = libFiles(ver);
  const tasks = [];
  // client jar
  const clientJar = path.join(P.versions, jarId, jarId + '.jar');
  if (!ver.downloads || !ver.downloads.client) { if (!(await U.exists(clientJar))) throw new Error('Client jar info missing for ' + jarId); }
  else tasks.push({ label: 'Minecraft ' + jarId, url: ver.downloads.client.url, dest: clientJar, sha1: ver.downloads.client.sha1, size: ver.downloads.client.size });
  for (const f of files) tasks.push({ label: path.basename(f.path), url: f.url, dest: path.join(P.libraries, f.path), sha1: f.sha1, size: f.size });
  // logging config
  if (ver.logging && ver.logging.client && ver.logging.client.file) {
    const lf = ver.logging.client.file; tasks.push({ label: 'log config', url: lf.url, dest: path.join(P.assets, 'log_configs', lf.id), sha1: lf.sha1, size: lf.size });
  }
  // assets
  const idx = ver.assetIndex;
  const idxFile = path.join(P.assets, 'indexes', idx.id + '.json');
  await U.download(idx.url, idxFile, { sha1: idx.sha1 });
  const index = await U.readJSON(idxFile);
  const objs = Object.entries(index.objects || {});
  for (const [name, o] of objs) tasks.push({ label: name, url: `${ASSETS_URL}/${o.hash.slice(0, 2)}/${o.hash}`, dest: path.join(P.assets, 'objects', o.hash.slice(0, 2), o.hash), sha1: o.hash, size: o.size });

  const total = tasks.reduce((a, t) => a + (t.size || 0), 0) || tasks.length * 100000;
  let done = 0, n = 0, last = 0;
  const report = (stage) => { const now = Date.now(); if (now - last > 80) { last = now; progress && progress({ stage, pct: Math.min(99, (done / total) * 100), detail: `${n}/${tasks.length}` }); } };
  report('Downloading game files');
  await U.pool(tasks, 12, async (t) => {
    await U.download(t.url, t.dest, { sha1: t.sha1, size: t.size, onBytes: (b) => { done += b; report('Downloading game files'); } });
    n++; if (!t.size) done += 100000; report('Downloading game files');
  });
  return { ver, files, index };
}

async function prepareAssets(ver, index, gameDir) {
  if (index.virtual || index.map_to_resources) {
    const base = index.map_to_resources ? path.join(gameDir, 'resources') : path.join(P.assets, 'virtual', 'legacy');
    for (const [name, o] of Object.entries(index.objects || {})) {
      const dest = path.join(base, name);
      if (await U.exists(dest)) continue;
      await fsp.mkdir(path.dirname(dest), { recursive: true });
      await fsp.copyFile(path.join(P.assets, 'objects', o.hash.slice(0, 2), o.hash), dest);
    }
    return index.map_to_resources ? path.join(gameDir, 'resources') : base;
  }
  return P.assets;
}

// ---------------- Java runtime (Mojang's own runtimes) ----------------
const RUNTIME_BY_MAJOR = { 8: 'jre-legacy', 16: 'java-runtime-alpha', 17: 'java-runtime-gamma', 21: 'java-runtime-delta', 25: 'java-runtime-epsilon' };
function runtimePlatform() {
  if (process.platform === 'win32') return process.arch === 'arm64' ? 'windows-arm64' : process.arch === 'ia32' ? 'windows-x86' : 'windows-x64';
  if (process.platform === 'darwin') return process.arch === 'arm64' ? 'mac-os-arm64' : 'mac-os';
  return process.arch === 'ia32' ? 'linux-i386' : 'linux';
}
const javaBin = (dir) => path.join(dir, 'bin', process.platform === 'win32' ? 'java.exe' : 'java');

async function ensureJava(versionJson, progress) {
  const s = await loadSettings();
  if (s.javaMode === 'custom' && s.javaPath) return s.javaPath;
  const jv = versionJson.javaVersion || { majorVersion: 8, component: 'jre-legacy' };
  const component = jv.component || RUNTIME_BY_MAJOR[jv.majorVersion] || 'jre-legacy';
  const dir = path.join(P.runtimes, component);
  const marker = path.join(dir, '.moblauncher-ok');
  if (await U.exists(marker) && await U.exists(javaBin(dir))) return javaBin(dir);
  progress && progress({ stage: `Preparing Java ${jv.majorVersion}`, pct: 0, detail: '' });
  const all = await U.getJSON(RUNTIME_ALL);
  const plat = all[runtimePlatform()];
  const entry = plat && plat[component] && plat[component][0];
  if (!entry) throw new Error(`Java runtime "${component}" is not offered for ${runtimePlatform()}. Set a custom Java path in Settings.`);
  const man = await U.getJSON(entry.manifest.url);
  const list = Object.entries(man.files);
  const filesOnly = list.filter(([, f]) => f.type === 'file');
  for (const [p, f] of list) if (f.type === 'directory') await fsp.mkdir(path.join(dir, p), { recursive: true });
  let n = 0;
  await U.pool(filesOnly, 10, async ([p, f]) => {
    const raw = f.downloads.raw;
    await U.download(raw.url, path.join(dir, p), { sha1: raw.sha1, size: raw.size });
    if (f.executable && process.platform !== 'win32') await fsp.chmod(path.join(dir, p), 0o755);
    n++; progress && progress({ stage: `Preparing Java ${jv.majorVersion}`, pct: (n / filesOnly.length) * 100, detail: `${n}/${filesOnly.length}` });
  });
  await fsp.writeFile(marker, 'ok');
  return javaBin(dir);
}

// ---------------- Loaders ----------------
async function fabricVersions(mc) {
  const l = await U.getJSON(`https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(mc)}`);
  return l.map(x => ({ id: x.loader.version, stable: x.loader.stable }));
}
async function quiltVersions(mc) {
  const l = await U.getJSON(`https://meta.quiltmc.org/v3/versions/loader/${encodeURIComponent(mc)}`);
  return l.map(x => ({ id: x.loader.version, stable: !/beta|pre/.test(x.loader.version) }));
}
async function mavenVersions(url) {
  const xml = await U.getText(url);
  return [...xml.matchAll(/<version>([^<]+)<\/version>/g)].map(m => m[1]);
}
async function forgeVersions(mc) {
  const all = await mavenVersions('https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml');
  const list = all.filter(v => v.startsWith(mc + '-')).map(v => v.slice(mc.length + 1).split('-')[0]).reverse();
  let rec = null; try { const p = await U.getJSON('https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json'); rec = p.promos[mc + '-recommended']; } catch {}
  return list.map(v => ({ id: v, stable: v === rec }));
}
async function neoforgeVersions(mc) {
  const parts = mc.split('.'); // 1.21.1 -> 21.1 ; 1.21 -> 21.0
  const prefix = `${parts[1]}.${parts[2] || 0}.`;
  const all = await mavenVersions('https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml');
  let list = all.filter(v => v.startsWith(prefix)).reverse();
  if (mc === '1.20.1') { const old = await mavenVersions('https://maven.neoforged.net/releases/net/neoforged/forge/maven-metadata.xml').catch(() => []); list = old.filter(v => v.startsWith('1.20.1-')).reverse(); }
  return list.map(v => ({ id: v, stable: !/beta|alpha/.test(v) }));
}
async function loaderVersions(loader, mc) {
  if (loader === 'fabric') return fabricVersions(mc);
  if (loader === 'quilt') return quiltVersions(mc);
  if (loader === 'forge') return forgeVersions(mc);
  if (loader === 'neoforge') return neoforgeVersions(mc);
  return [];
}

async function runInstaller(javaPath, installerJar, args, cwd, log) {
  await new Promise((resolve, reject) => {
    const p = cp.spawn(javaPath, ['-jar', installerJar, ...args], { cwd, windowsHide: true });
    let out = '';
    const on = (d) => { out += d; log && log(String(d)); if (out.length > 20000) out = out.slice(-10000); };
    p.stdout.on('data', on); p.stderr.on('data', on);
    p.on('error', reject);
    p.on('exit', (c) => c === 0 ? resolve() : reject(new Error('Loader installer failed (exit ' + c + '):\n' + out.slice(-800))));
  });
}

// returns the version id to launch
async function installLoader({ loader, mcVersion, loaderVersion }, progress) {
  if (!loader || loader === 'vanilla') { await installVanillaJson(mcVersion); return mcVersion; }
  await installVanillaJson(mcVersion);
  progress && progress({ stage: `Installing ${loader}`, pct: 5, detail: '' });
  if (loader === 'fabric' || loader === 'quilt') {
    let lv = loaderVersion;
    if (!lv) { const l = await loaderVersions(loader, mcVersion); if (!l.length) throw new Error(`${loader} does not support Minecraft ${mcVersion}`); lv = (l.find(x => x.stable) || l[0]).id; }
    const id = `${loader}-loader-${lv}-${mcVersion}`;
    const file = path.join(P.versions, id, id + '.json');
    if (!(await U.exists(file))) {
      const url = loader === 'fabric'
        ? `https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(mcVersion)}/${encodeURIComponent(lv)}/profile/json`
        : `https://meta.quiltmc.org/v3/versions/loader/${encodeURIComponent(mcVersion)}/${encodeURIComponent(lv)}/profile/json`;
      const j = await U.getJSON(url); j.id = id; await U.writeJSON(file, j);
    }
    return id;
  }
  // forge / neoforge: run official installer in headless mode
  let lv = loaderVersion;
  if (!lv) { const l = await loaderVersions(loader, mcVersion); if (!l.length) throw new Error(`${loader} does not support Minecraft ${mcVersion}`); lv = (l.find(x => x.stable) || l[0]).id; }
  const full = loader === 'forge' ? `${mcVersion}-${lv}` : lv;
  const marker = path.join(P.versions, `.${loader}-${full}.id`);
  const cached = await U.exists(marker) ? (await fsp.readFile(marker, 'utf8')).trim() : null;
  if (cached && await U.exists(path.join(P.versions, cached, cached + '.json'))) return cached;
  const base = loader === 'forge'
    ? `https://maven.minecraftforge.net/net/minecraftforge/forge/${full}/forge-${full}-installer.jar`
    : (mcVersion === '1.20.1' ? `https://maven.neoforged.net/releases/net/neoforged/forge/${full}/forge-${full}-installer.jar` : `https://maven.neoforged.net/releases/net/neoforged/neoforge/${full}/neoforge-${full}-installer.jar`);
  const jar = path.join(P.cache, 'installers', path.basename(base));
  progress && progress({ stage: `Downloading ${loader} installer`, pct: 10, detail: '' });
  await U.download(base, jar);
  const ver = await resolveVersion(mcVersion);
  const java = await ensureJava(ver, progress);
  await installGame(mcVersion, (p) => progress && progress({ ...p, pct: 10 + p.pct * 0.5 })); // installer needs vanilla jar + libs
  await fsp.mkdir(P.root, { recursive: true });
  const lp = path.join(P.root, 'launcher_profiles.json');
  if (!(await U.exists(lp))) await U.writeJSON(lp, { profiles: {}, version: 3 });
  const before = new Set(await fsp.readdir(P.versions).catch(() => []));
  progress && progress({ stage: `Running ${loader} installer`, pct: 65, detail: 'this can take a minute' });
  await runInstaller(java, jar, ['--installClient', P.root], P.root);
  const after = (await fsp.readdir(P.versions)).filter(d => !before.has(d) && !d.startsWith('.'));
  let id = after.find(d => d.includes(lv)) || after[0];
  if (!id) { const all = await fsp.readdir(P.versions); id = all.find(d => d.toLowerCase().includes(loader) && d.includes(lv)); }
  if (!id) throw new Error(`${loader} installer finished but no version was created.`);
  await fsp.writeFile(marker, id);
  return id;
}

// ---------------- launch ----------------
function subst(s, vars) { return s.replace(/\$\{([^}]+)\}/g, (m, k) => (k in vars ? vars[k] : m)); }

function buildArgs(ver, ctx) {
  const features = {
    has_custom_resolution: true,
    is_demo_user: false,
    has_quick_plays_support: !!ctx.server,
    is_quick_play_multiplayer: !!ctx.server,
    is_quick_play_singleplayer: false,
    is_quick_play_realms: false,
  };
  const flatten = (arr) => {
    const out = [];
    for (const a of arr || []) {
      if (typeof a === 'string') { out.push(a); continue; }
      if (!rulesAllow(a.rules, features)) continue;
      if (Array.isArray(a.value)) out.push(...a.value); else out.push(a.value);
    }
    return out;
  };
  let jvm, game;
  if (ver.arguments) { jvm = flatten(ver.arguments.jvm); game = flatten(ver.arguments.game); }
  else {
    jvm = ['-Djava.library.path=${natives_directory}', '-Dminecraft.launcher.brand=${launcher_name}', '-Dminecraft.launcher.version=${launcher_version}', '-cp', '${classpath}'];
    game = (ver.minecraftArguments || '').split(' ').filter(Boolean);
  }
  if (!jvm.some(a => a.startsWith('-Djava.library.path'))) jvm.unshift('-Djava.library.path=${natives_directory}');
  if (!jvm.includes('-cp') && !jvm.includes('-classpath')) jvm.push('-cp', '${classpath}');
  const vars = {
    auth_player_name: ctx.account.name, version_name: ver.id, game_directory: ctx.gameDir, assets_root: ctx.assetsRoot,
    assets_index_name: ver.assetIndex ? ver.assetIndex.id : ver.assets, auth_uuid: ctx.account.uuid, auth_access_token: ctx.account.accessToken,
    clientid: 'moblauncher', auth_xuid: '0', user_type: ctx.account.userType, version_type: ver.type || 'release', user_properties: '{}',
    auth_session: ctx.account.accessToken, game_assets: ctx.assetsRoot,
    resolution_width: String(ctx.width), resolution_height: String(ctx.height),
    natives_directory: ctx.nativesDir, launcher_name: 'MobLauncher', launcher_version: LAUNCHER_VERSION,
    classpath: ctx.classpath, library_directory: P.libraries, classpath_separator: path.delimiter,
    path: ctx.logConfigPath || '', quickPlayMultiplayer: ctx.server || '', quickPlayPath: 'quickplay.json',
  };
  if (ver.logging && ver.logging.client && ver.logging.client.argument && ctx.logConfigPath) jvm.push(ver.logging.client.argument);
  let g = game.map(a => subst(a, vars));
  let j = jvm.map(a => subst(a, vars));
  // drop args that still contain unresolved placeholders
  g = g.filter((a, i) => !/\$\{/.test(a)); j = j.filter(a => !/\$\{/.test(a));
  if (ctx.server && !ver.arguments) {
    const [host, port] = ctx.server.split(':'); g.push('--server', host); if (port) g.push('--port', port);
  } else if (ctx.server && ver.arguments && !game.some(a => typeof a === 'string' && a.includes('quickPlayMultiplayer'))) {
    // an arguments-based version that predates quick play (1.13–1.19): use --server/--port
    const hasQP = JSON.stringify(ver.arguments.game || []).includes('quickPlayMultiplayer');
    if (!hasQP) { const [host, port] = ctx.server.split(':'); g.push('--server', host); if (port) g.push('--port', port); }
  }
  // remove "--demo"-like leftovers and empty flag/value pairs
  const cleaned = [];
  for (let i = 0; i < g.length; i++) { if (g[i].startsWith('--') && (g[i + 1] === undefined || g[i + 1] === '') && g[i] !== '--fullscreen') { i++; continue; } cleaned.push(g[i]); }
  return { jvm: j, game: cleaned };
}

async function prepareLaunch(inst, account, opts, progress) {
  const s = await loadSettings();
  progress({ stage: 'Checking Minecraft version', pct: 1, detail: '' });
  const versionId = inst.resolvedVersion && await U.exists(path.join(P.versions, inst.resolvedVersion, inst.resolvedVersion + '.json'))
    ? inst.resolvedVersion
    : await installLoader({ loader: inst.loader, mcVersion: inst.mcVersion, loaderVersion: inst.loaderVersion }, progress);
  const { ver, files, index } = await installGame(versionId, progress);
  const java = await ensureJava(ver, progress);
  const gameDir = path.join(P.instances, inst.id, 'game');
  await fsp.mkdir(gameDir, { recursive: true });
  progress({ stage: 'Preparing files', pct: 99, detail: '' });
  const nativesDir = path.join(P.instances, inst.id, 'natives');
  await extractNatives(files, nativesDir);
  const assetsRoot = await prepareAssets(ver, index, gameDir);
  const jarId = ver.jarId || ver.id;
  const cpFiles = files.filter(f => f.classpath).map(f => path.join(P.libraries, f.path));
  cpFiles.push(path.join(P.versions, jarId, jarId + '.jar'));
  const classpath = cpFiles.join(path.delimiter);
  const logCfg = ver.logging && ver.logging.client && ver.logging.client.file ? path.join(P.assets, 'log_configs', ver.logging.client.file.id) : '';
  const { jvm, game } = buildArgs(ver, {
    account, gameDir, assetsRoot: index.virtual || index.map_to_resources ? assetsRoot : P.assets, nativesDir, classpath,
    width: inst.width || s.width, height: inst.height || s.height, server: opts.server || null, logConfigPath: logCfg,
  });
  const min = inst.memoryMinMB || s.memoryMinMB, max = inst.memoryMaxMB || s.memoryMaxMB;
  const extra = ((inst.jvmArgs || s.jvmArgs) || '').split(/\s+/).filter(Boolean);
  const authInject = [];
  if (account.type === 'elyby') {
    const agent = path.join(P.cache, 'authlib-injector.jar');
    if (!(await U.exists(agent))) {
      progress({ stage: 'Downloading Ely.by authlib-injector', pct: 99, detail: '' });
      const meta = await U.getJSON('https://authlib-injector.yushi.moe/artifact/latest.json');
      await U.download(meta.download_url, agent, { sha1: meta.checksums && meta.checksums.sha256 ? undefined : undefined });
    }
    authInject.push(`-javaagent:${agent}=https://authserver.ely.by/api/authlib-injector`);
  }
  if (process.platform === 'darwin') extra.push('-XstartOnFirstThread');
  const fullJvm = [`-Xms${min}M`, `-Xmx${max}M`, ...extra, ...authInject, ...jvm];
  const mainClass = ver.mainClass;
  const args = [...fullJvm, mainClass, ...game];
  if (inst.fullscreen || s.fullscreen) args.push('--fullscreen');
  return { java, args, gameDir, versionId };
}

function spawnGame(java, args, cwd, hooks) {
  const child = cp.spawn(java, args, { cwd, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  const line = (buf) => String(buf).split(/\r?\n/).filter(Boolean).forEach(l => hooks.onLog && hooks.onLog(l));
  child.stdout.on('data', line); child.stderr.on('data', line);
  child.on('exit', (code) => hooks.onExit && hooks.onExit(code));
  child.on('error', (e) => hooks.onExit && hooks.onExit(-1, e));
  return child;
}

// Self-repair: wipe natives, drop broken version files, re-verify every file by SHA-1 and re-download what is damaged
async function repair(inst, progress) {
  const dir = path.join(P.instances, inst.id);
  await fsp.rm(path.join(dir, 'natives'), { recursive: true, force: true });
  for (const root of [P.libraries, P.assets, P.versions]) { // leftover partial downloads
    const stack = [root];
    while (stack.length) { const d = stack.pop(); let es = []; try { es = await fsp.readdir(d, { withFileTypes: true }); } catch { continue; }
      for (const e of es) { const f = path.join(d, e.name); if (e.isDirectory()) stack.push(f); else if (e.name.endsWith('.part')) await fsp.rm(f, { force: true }); } }
  }
  const id = inst.resolvedVersion || inst.mcVersion;
  const vf = path.join(P.versions, id, id + '.json');
  if (!(await U.readJSON(vf))) await fsp.rm(path.join(P.versions, id), { recursive: true, force: true });
  const versionId = await installLoader({ loader: inst.loader, mcVersion: inst.mcVersion, loaderVersion: inst.loaderVersion }, progress);
  await installGame(versionId, progress);
  return versionId;
}

function systemMemoryMB() { return Math.floor(os.totalmem() / 1048576); }

module.exports = { repair, listVersions, loaderVersions, installLoader, installGame, prepareLaunch, spawnGame, resolveVersion, ensureJava, systemMemoryMB, buildArgs, libFiles, rulesAllow, LAUNCHER_VERSION };
