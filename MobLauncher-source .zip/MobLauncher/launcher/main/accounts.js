'use strict';
const { safeStorage, shell, clipboard } = require('electron');
const crypto = require('crypto');
const { P, loadSettings } = require('./paths');
const { readJSON, writeJSON, getJSON, postJSON, http, offlineUUID, uid } = require('./util');

// ---------- storage (tokens encrypted with OS keychain when available) ----------
const enc = (s) => { try { if (s && safeStorage.isEncryptionAvailable()) return 'enc:' + safeStorage.encryptString(s).toString('base64'); } catch {} return s || ''; };
const dec = (s) => { try { if (s && s.startsWith('enc:')) return safeStorage.decryptString(Buffer.from(s.slice(4), 'base64')); } catch {} return s || ''; };

let db = null;
async function load() {
  if (db) return db;
  const raw = (await readJSON(P.accounts, null)) || { accounts: [], selected: null };
  db = raw;
  return db;
}
async function save() { await writeJSON(P.accounts, db); }
function toPublic(a) {
  return { id: a.id, type: a.type, name: a.name, uuid: a.uuid, capes: a.capes || [], skinUrl: a.skinUrl || null, skinVariant: a.skinVariant || 'classic', needsLogin: !!a.needsLogin };
}
async function list() { const d = await load(); return { accounts: d.accounts.map(toPublic), selected: d.selected }; }
async function select(id) { const d = await load(); if (d.accounts.find(a => a.id === id)) { d.selected = id; await save(); } return list(); }
async function remove(id) {
  const d = await load();
  d.accounts = d.accounts.filter(a => a.id !== id);
  if (d.selected === id) d.selected = d.accounts[0] ? d.accounts[0].id : null;
  await save(); return list();
}
async function upsert(acc) {
  const d = await load();
  const i = d.accounts.findIndex(a => a.type === acc.type && a.uuid === acc.uuid);
  if (i >= 0) { acc.id = d.accounts[i].id; d.accounts[i] = { ...d.accounts[i], ...acc }; } else { acc.id = acc.id || uid(); d.accounts.push(acc); }
  d.selected = acc.id;
  await save();
  return acc;
}

// ---------- offline ----------
async function addOffline(name) {
  name = String(name || '').trim();
  if (!/^[A-Za-z0-9_]{3,16}$/.test(name)) throw new Error('Nickname must be 3-16 characters: letters, digits, underscore.');
  await upsert({ type: 'offline', name, uuid: offlineUUID(name) });
  return list();
}

// ---------- Microsoft (device code flow) ----------
const MS = 'https://login.microsoftonline.com/consumers/oauth2/v2.0';
const SCOPE = 'XboxLive.signin offline_access';
const form = (o) => new URLSearchParams(o).toString();

let msAbort = null;
async function startMicrosoft(emit) {
  const s = await loadSettings();
  if (!s.msClientId) {
    const e = new Error('MS_CLIENT_ID_MISSING');
    e.code = 'MS_CLIENT_ID_MISSING'; throw e;
  }
  if (msAbort) msAbort.cancelled = true;
  const ctl = { cancelled: false }; msAbort = ctl;
  const dc = await getJSON(`${MS}/devicecode`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ client_id: s.msClientId, scope: SCOPE }) });
  const openUrl = dc.verification_uri_complete || (dc.verification_uri + (dc.verification_uri.includes('?') ? '&' : '?') + 'otc=' + encodeURIComponent(dc.user_code));
  try { clipboard.writeText(dc.user_code); } catch {}
  emit({ userCode: dc.user_code, url: dc.verification_uri, openUrl, copied: true, expiresIn: dc.expires_in });
  shell.openExternal(openUrl).catch(() => {});
  const end = Date.now() + dc.expires_in * 1000;
  let interval = (dc.interval || 5) * 1000;
  while (Date.now() < end && !ctl.cancelled) {
    await new Promise(r => setTimeout(r, interval));
    const r = await http(`${MS}/token`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, allowError: true, body: form({ grant_type: 'urn:ietf:params:oauth:grant-type:device_code', client_id: s.msClientId, device_code: dc.device_code }) });
    const j = await r.json();
    if (j.access_token) { return finishMicrosoft(j.access_token, j.refresh_token); }
    if (j.error === 'authorization_pending') continue;
    if (j.error === 'slow_down') { interval += 5000; continue; }
    throw new Error(j.error_description || j.error || 'Microsoft login failed');
  }
  throw new Error('Login cancelled or expired');
}
function cancelMicrosoft() { if (msAbort) msAbort.cancelled = true; }

async function xboxChain(msAccessToken) {
  const xbl = await postJSON('https://user.auth.xboxlive.com/user/authenticate', { Properties: { AuthMethod: 'RPS', SiteName: 'user.auth.xboxlive.com', RpsTicket: 'd=' + msAccessToken }, RelyingParty: 'http://auth.xboxlive.com', TokenType: 'JWT' });
  const xsts = await postJSON('https://xsts.auth.xboxlive.com/xsts/authorize', { Properties: { SandboxId: 'RETAIL', UserTokens: [xbl.Token] }, RelyingParty: 'rp://api.minecraftservices.com/', TokenType: 'JWT' }).catch(e => {
    let msg = 'Xbox authorization failed.';
    try { const j = JSON.parse(e.body); if (j.XErr === 2148916233) msg = 'This Microsoft account has no Xbox profile. Create one at xbox.com first.'; if (j.XErr === 2148916238) msg = 'This is a child account. An adult must add it to a Microsoft family.'; } catch {}
    throw new Error(msg);
  });
  const uhs = xbl.DisplayClaims.xui[0].uhs;
  const mc = await postJSON('https://api.minecraftservices.com/authentication/login_with_xbox', { identityToken: `XBL3.0 x=${uhs};${xsts.Token}` });
  return mc; // { access_token, expires_in }
}
async function mcProfile(token) {
  const r = await http('https://api.minecraftservices.com/minecraft/profile', { headers: { Authorization: 'Bearer ' + token }, allowError: true });
  if (r.status === 404) throw new Error('This account does not own Minecraft: Java Edition.');
  if (!r.ok) throw new Error('Could not load Minecraft profile (HTTP ' + r.status + ')');
  return r.json();
}
function applyProfile(p) {
  const skin = (p.skins || []).find(s => s.state === 'ACTIVE') || (p.skins || [])[0];
  return { name: p.name, uuid: p.id, skinUrl: skin ? skin.url : null, skinVariant: skin ? (skin.variant || 'CLASSIC').toLowerCase() : 'classic', capes: (p.capes || []).map(c => ({ id: c.id, alias: c.alias, url: c.url, active: c.state === 'ACTIVE' })) };
}
async function finishMicrosoft(msAccess, msRefresh) {
  const mc = await xboxChain(msAccess);
  const prof = await mcProfile(mc.access_token);
  await upsert({ type: 'microsoft', ...applyProfile(prof), accessToken: enc(mc.access_token), refreshToken: enc(msRefresh), expires: Date.now() + (mc.expires_in - 120) * 1000, needsLogin: false });
  return list();
}
async function refreshMicrosoft(a) {
  const s = await loadSettings();
  const j = await getJSON(`${MS}/token`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ grant_type: 'refresh_token', client_id: s.msClientId, refresh_token: dec(a.refreshToken), scope: SCOPE }) });
  const mc = await xboxChain(j.access_token);
  a.accessToken = enc(mc.access_token); a.refreshToken = enc(j.refresh_token || dec(a.refreshToken)); a.expires = Date.now() + (mc.expires_in - 120) * 1000; a.needsLogin = false;
}

// ---------- Ely.by (Yggdrasil) ----------
const ELY = 'https://authserver.ely.by';
async function loginElyby(username, password, totp) {
  const clientToken = crypto.randomBytes(16).toString('hex');
  const pass = totp ? `${password}:${String(totp).trim()}` : password;
  let r;
  try { r = await postJSON(`${ELY}/auth/authenticate`, { username, password: pass, clientToken, requestUser: true }); }
  catch (e) {
    let m = 'Ely.by login failed.';
    try { const j = JSON.parse(e.body); m = j.errorMessage || m; if (/two factor/i.test(m)) { const x = new Error('ELY_2FA'); x.code = 'ELY_2FA'; throw x; } } catch (x) { if (x.code) throw x; }
    throw new Error(m);
  }
  const p = r.selectedProfile || (r.availableProfiles || [])[0];
  if (!p) throw new Error('No profile on this Ely.by account.');
  await upsert({ type: 'elyby', name: p.name, uuid: p.id, accessToken: enc(r.accessToken), clientToken, skinUrl: `http://skinsystem.ely.by/skins/${encodeURIComponent(p.name)}.png`, needsLogin: false });
  return list();
}
async function refreshElyby(a) {
  const at = dec(a.accessToken);
  const v = await http(`${ELY}/auth/validate`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ accessToken: at }), allowError: true });
  if (v.ok) return;
  const r = await postJSON(`${ELY}/auth/refresh`, { accessToken: at, clientToken: a.clientToken });
  a.accessToken = enc(r.accessToken);
}

// ---------- get a usable account for launching ----------
async function getLaunchAccount(id) {
  const d = await load();
  const a = d.accounts.find(x => x.id === (id || d.selected));
  if (!a) throw new Error('No account selected. Add an account first.');
  if (a.type === 'offline') return { type: 'offline', name: a.name, uuid: a.uuid, accessToken: '0', userType: 'legacy', id: a.id };
  try {
    if (a.type === 'microsoft' && (!a.expires || Date.now() > a.expires)) { await refreshMicrosoft(a); await save(); }
    if (a.type === 'elyby') { await refreshElyby(a); await save(); }
  } catch (e) {
    a.needsLogin = true; await save();
    throw new Error('Session expired. Please sign in again (' + e.message + ')');
  }
  return { type: a.type, name: a.name, uuid: a.uuid, accessToken: dec(a.accessToken), userType: a.type === 'microsoft' ? 'msa' : 'mojang', id: a.id };
}

// ---------- skins / capes (Microsoft) ----------
async function uploadSkin(accountId, buf, variant) {
  const a = await getLaunchAccount(accountId);
  if (a.type !== 'microsoft') throw new Error('Skin upload to Mojang works for Microsoft accounts. For Ely.by, change your skin on ely.by.');
  const fd = new FormData();
  fd.append('variant', variant === 'slim' ? 'slim' : 'classic');
  fd.append('file', new Blob([buf], { type: 'image/png' }), 'skin.png');
  const r = await http('https://api.minecraftservices.com/minecraft/profile/skins', { method: 'POST', headers: { Authorization: 'Bearer ' + a.accessToken }, body: fd, allowError: true });
  if (!r.ok) throw new Error('Skin upload failed: HTTP ' + r.status);
  return refreshProfile(accountId);
}
async function setCape(accountId, capeId) {
  const a = await getLaunchAccount(accountId);
  const r = capeId
    ? await http('https://api.minecraftservices.com/minecraft/profile/capes/active', { method: 'PUT', headers: { Authorization: 'Bearer ' + a.accessToken, 'Content-Type': 'application/json' }, body: JSON.stringify({ capeId }), allowError: true })
    : await http('https://api.minecraftservices.com/minecraft/profile/capes/active', { method: 'DELETE', headers: { Authorization: 'Bearer ' + a.accessToken }, allowError: true });
  if (!r.ok) throw new Error('Cape change failed: HTTP ' + r.status);
  return refreshProfile(accountId);
}
async function refreshProfile(accountId) {
  const d = await load();
  const a = d.accounts.find(x => x.id === accountId);
  if (a && a.type === 'microsoft') {
    const la = await getLaunchAccount(accountId);
    Object.assign(a, applyProfile(await mcProfile(la.accessToken)));
    await save();
  }
  return list();
}

// ---------- Yggdrasil session join (used to prove identity to the friends server) ----------
async function sessionJoin(accountId, serverId) {
  const a = await getLaunchAccount(accountId);
  if (a.type === 'offline') throw new Error('Offline accounts cannot use friends.');
  const url = a.type === 'microsoft' ? 'https://sessionserver.mojang.com/session/minecraft/join' : `${ELY}/session/join`;
  const r = await http(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ accessToken: a.accessToken, selectedProfile: a.uuid, serverId }), allowError: true });
  if (!r.ok && r.status !== 204) throw new Error('Session join failed: HTTP ' + r.status);
  return { provider: a.type, username: a.name, uuid: a.uuid };
}

module.exports = { list, select, remove, addOffline, startMicrosoft, cancelMicrosoft, loginElyby, getLaunchAccount, uploadSkin, setCape, refreshProfile, sessionJoin, load };
