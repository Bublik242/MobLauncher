'use strict';
const net = require('net'), dns = require('dns').promises;
const { P } = require('./paths');
const U = require('./util');
const file = require('path').join(P.dataDir, 'servers.json');

async function list() { return (await U.readJSON(file, [])) || []; }
async function save(arr) { await U.writeJSON(file, arr); return arr; }
async function add(name, address) {
  address = String(address || '').trim().toLowerCase();
  if (!/^[a-z0-9.\-_]+(:\d{1,5})?$/.test(address)) throw new Error('Enter a server address like play.example.com or 1.2.3.4:25565');
  const arr = await list(); if (arr.some(s => s.address === address)) throw new Error('This server is already in your list.');
  arr.push({ id: U.uid(), name: String(name || address).trim().slice(0, 40) || address, address }); return save(arr);
}
async function remove(id) { return save((await list()).filter(s => s.id !== id)); }

const varint = (n) => { const b = []; do { let x = n & 0x7f; n >>>= 7; if (n) x |= 0x80; b.push(x); } while (n); return Buffer.from(b); };
const readVarint = (buf, off) => { let v = 0, sh = 0, i = off; for (;;) { if (i >= buf.length) return null; const b = buf[i++]; v |= (b & 0x7f) << sh; if (!(b & 0x80)) return [v, i - off]; sh += 7; if (sh > 35) return null; } };
const flat = (d) => typeof d === 'string' ? d : !d ? '' : (d.text || '') + (d.extra || []).map(flat).join('') + (d.translate && !d.text ? d.translate : '');

async function ping(address, timeout = 4000) {
  let [host, port] = address.split(':'); port = Number(port) || 0;
  if (!port) { try { const r = await dns.resolveSrv('_minecraft._tcp.' + host); if (r[0]) { host = r[0].name; port = r[0].port; } } catch {} port = port || 25565; }
  return new Promise((resolve) => {
    const t0 = Date.now(); let buf = Buffer.alloc(0); let done = false;
    const s = net.connect({ host, port, timeout });
    const fin = (o) => { if (done) return; done = true; s.destroy(); resolve(o); };
    s.on('connect', () => {
      const hb = Buffer.from(host);
      const data = Buffer.concat([varint(0), varint(767), varint(hb.length), hb, Buffer.from([port >> 8, port & 255]), varint(1)]);
      s.write(Buffer.concat([varint(data.length), data, Buffer.from([1, 0])]));
    });
    s.on('data', (d) => {
      buf = Buffer.concat([buf, d]);
      const pl = readVarint(buf, 0); if (!pl) return; if (buf.length < pl[1] + pl[0]) return;
      try {
        let o = pl[1]; const id = readVarint(buf, o); o += id[1]; const sl = readVarint(buf, o); o += sl[1];
        const j = JSON.parse(buf.subarray(o, o + sl[0]).toString('utf8'));
        fin({ online: true, ms: Date.now() - t0, version: j.version && j.version.name, protocol: j.version && j.version.protocol, players: j.players ? { online: j.players.online, max: j.players.max } : null, motd: flat(j.description).replace(/§./g, '').trim().slice(0, 160), favicon: j.favicon || null });
      } catch { fin({ online: true, ms: Date.now() - t0 }); }
    });
    s.on('timeout', () => fin({ online: false })); s.on('error', () => fin({ online: false }));
  });
}
module.exports = { list, add, remove, ping };
