'use strict';
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const { Readable } = require('stream');
const { pipeline } = require('stream/promises');

const UA = 'MobLauncher/1.0 (https://moblauncher.app)';

const sha1File = (p) => new Promise((res, rej) => {
  const h = crypto.createHash('sha1');
  fs.createReadStream(p).on('data', d => h.update(d)).on('end', () => res(h.digest('hex'))).on('error', rej);
});

async function exists(p) { try { await fsp.access(p); return true; } catch { return false; } }
async function readJSON(p, fallback = null) { try { return JSON.parse(await fsp.readFile(p, 'utf8')); } catch { return fallback; } }
async function writeJSON(p, data) {
  await fsp.mkdir(path.dirname(p), { recursive: true });
  const tmp = p + '.tmp';
  await fsp.writeFile(tmp, JSON.stringify(data, null, 2));
  await fsp.rename(tmp, p);
}

async function http(url, opts = {}) {
  const r = await fetch(url, {
    method: opts.method || 'GET',
    headers: { 'User-Agent': UA, ...(opts.headers || {}) },
    body: opts.body,
    redirect: 'follow',
    signal: AbortSignal.timeout(opts.timeout || 25000),
  });
  if (!r.ok && !opts.allowError) {
    const e = new Error(`HTTP ${r.status} for ${url}`);
    e.status = r.status;
    e.body = await r.text().catch(() => '');
    throw e;
  }
  return r;
}
async function getJSON(url, opts = {}) { return (await http(url, opts)).json(); }
async function getText(url, opts = {}) { return (await http(url, opts)).text(); }
async function postJSON(url, body, headers = {}, opts = {}) {
  return getJSON(url, { method: 'POST', body: JSON.stringify(body), headers: { 'Content-Type': 'application/json', Accept: 'application/json', ...headers }, ...opts });
}

// Download with retry, atomic rename, optional sha1 check and progress(bytes)
async function download(url, dest, { sha1, size, onBytes, retries = 3, headers } = {}) {
  if (await exists(dest)) {
    try {
      const st = await fsp.stat(dest);
      if (sha1 ? (await sha1File(dest)) === sha1 : (st.size > 0 && (!size || st.size === size))) { onBytes && onBytes(st.size, true); return dest; }
    } catch {}
  }
  await fsp.mkdir(path.dirname(dest), { recursive: true });
  let lastErr;
  for (let i = 0; i < retries; i++) {
    const tmp = dest + '.part';
    try {
      const r = await http(url, { timeout: 120000, headers });
      const src = Readable.fromWeb(r.body);
      src.on('data', c => onBytes && onBytes(c.length, false));
      await pipeline(src, fs.createWriteStream(tmp));
      if (sha1 && (await sha1File(tmp)) !== sha1) throw new Error('SHA1 mismatch for ' + url);
      await fsp.rename(tmp, dest);
      return dest;
    } catch (e) { lastErr = e; await fsp.rm(tmp, { force: true }); await new Promise(r => setTimeout(r, 400 * (i + 1))); }
  }
  throw lastErr;
}

async function pool(items, n, fn) {
  let i = 0, firstErr = null;
  const workers = Array.from({ length: Math.min(n, items.length) }, async () => {
    while (i < items.length && !firstErr) {
      const idx = i++;
      try { await fn(items[idx], idx); } catch (e) { firstErr = firstErr || e; }
    }
  });
  await Promise.all(workers);
  if (firstErr) throw firstErr;
}

const osName = process.platform === 'win32' ? 'windows' : process.platform === 'darwin' ? 'osx' : 'linux';
const sanitize = (s) => String(s).replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').trim().slice(0, 64) || 'unnamed';
const uid = () => crypto.randomBytes(6).toString('hex');

function offlineUUID(name) {
  const h = crypto.createHash('md5').update('OfflinePlayer:' + name).digest();
  h[6] = (h[6] & 0x0f) | 0x30; h[8] = (h[8] & 0x3f) | 0x80;
  return h.toString('hex');
}
const dashUUID = (u) => u.replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/, '$1-$2-$3-$4-$5');

// Maven coordinate -> relative path
function mavenPath(name) {
  let [g, a, v, ...rest] = name.split(':');
  let ext = 'jar';
  if (v && v.includes('@')) { [v, ext] = v.split('@'); }
  let cls = rest[0];
  if (cls && cls.includes('@')) { [cls, ext] = cls.split('@'); }
  return `${g.replace(/\./g, '/')}/${a}/${v}/${a}-${v}${cls ? '-' + cls : ''}.${ext}`;
}

module.exports = { UA, sha1File, exists, readJSON, writeJSON, http, getJSON, getText, postJSON, download, pool, osName, sanitize, uid, offlineUUID, dashUUID, mavenPath, fsp, fs, path };
