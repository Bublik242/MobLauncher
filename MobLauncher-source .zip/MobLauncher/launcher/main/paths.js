'use strict';
const path = require('path');
const fs = require('fs');
const { app } = require('electron');
const { readJSON, writeJSON } = require('./util');

// dataDir: moblauncher.config.json next to the exe (written by the installer) -> else %APPDATA%/MobLauncher
function resolveDataDir() {
  try {
    const exeDir = path.dirname(app.getPath('exe'));
    const cfg = path.join(exeDir, 'moblauncher.config.json');
    if (fs.existsSync(cfg)) { const j = JSON.parse(fs.readFileSync(cfg, 'utf8')); if (j.dataDir) return j.dataDir; }
  } catch {}
  if (process.env.MOB_DATA_DIR) return process.env.MOB_DATA_DIR;
  return path.join(app.getPath('appData'), 'MobLauncher');
}

const dataDir = resolveDataDir();
const P = {
  dataDir,
  root: path.join(dataDir, 'minecraft'),            // shared: versions, libraries, assets
  versions: path.join(dataDir, 'minecraft', 'versions'),
  libraries: path.join(dataDir, 'minecraft', 'libraries'),
  assets: path.join(dataDir, 'minecraft', 'assets'),
  runtimes: path.join(dataDir, 'runtimes'),
  instances: path.join(dataDir, 'instances'),
  cache: path.join(dataDir, 'cache'),
  skins: path.join(dataDir, 'skins'),
  settings: path.join(dataDir, 'settings.json'),
  accounts: path.join(dataDir, 'accounts.json'),
  bootstrap: path.join(dataDir, 'bootstrap.json'),
};

const DEFAULT_SETTINGS = {
  language: 'en',
  memoryMinMB: 1024,
  memoryMaxMB: 4096,
  javaMode: 'auto',       // auto | custom
  javaPath: '',
  jvmArgs: '-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4 -XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1RSetUpdatingPauseTimePercent=5 -XX:SurvivorRatio=32 -XX:+PerfDisableSharedMem -XX:MaxTenuringThreshold=1',
  closeOnLaunch: 'keep',  // keep | hide | quit
  showConsole: false,
  fullscreen: false,
  width: 1280, height: 720,
  reducedMotion: false,
  accent: 'green',
  friendsServer: '',      // wss://your-server
  msClientId: '',         // Azure application (client) id for Microsoft login
  curseforgeKey: '',
  shareServerAddress: '', // manual "my server" for friends to join
  lastInstance: null,
  lastTab: 'play',
  autoRam: true,
  showHours: true,        // friends can see my total play time
  showActivity: true,     // friends can see what I'm playing
};

let cache = null;
async function loadSettings() {
  if (cache) return cache;
  const s = (await readJSON(P.settings, {})) || {};
  cache = { ...DEFAULT_SETTINGS, ...s };
  if (!cache.msClientId && process.env.MOB_MS_CLIENT_ID) cache.msClientId = process.env.MOB_MS_CLIENT_ID;
  if (!cache.friendsServer && process.env.MOB_FRIENDS_SERVER) cache.friendsServer = process.env.MOB_FRIENDS_SERVER;
  if (!cache.curseforgeKey && process.env.MOB_CURSEFORGE_KEY) cache.curseforgeKey = process.env.MOB_CURSEFORGE_KEY;
  try { const b = await readJSON(path.join(__dirname, '..', 'defaults.json'), {}); for (const k of Object.keys(b)) if (!s[k] && b[k]) cache[k] = b[k]; } catch {}
  return cache;
}
async function saveSettings(patch) {
  const cur = await loadSettings();
  Object.assign(cur, patch || {});
  await writeJSON(P.settings, cur);
  return cur;
}

module.exports = { P, loadSettings, saveSettings, DEFAULT_SETTINGS };
