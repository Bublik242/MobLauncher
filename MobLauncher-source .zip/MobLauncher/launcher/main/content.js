'use strict';
const { loadSettings, P } = require('./paths');
const U = require('./util');
const I = require('./instances');
const { path, fsp } = U;

const MR = 'https://api.modrinth.com/v2';
const CF = 'https://api.curseforge.com/v1';
const CF_CLASS = { mod: 6, resourcepack: 12, shader: 6552, modpack: 4471, datapack: 6945 };
const CF_LOADER = { forge: 1, fabric: 4, quilt: 5, neoforge: 6 };

// CurseForge: own key if set, otherwise the friends server's built-in proxy (key stays on the server)
async function cfBase() {
  const s = await loadSettings();
  if (s.curseforgeKey) return { base: CF, headers: { 'x-api-key': s.curseforgeKey } };
  if (s.friendsServer) return { base: s.friendsServer.replace(/^ws/, 'http').replace(/\/$/, '') + '/cf', headers: {} };
  const e = new Error('CF_KEY_MISSING'); e.code = 'CF_KEY_MISSING'; throw e;
}
let cfAvail = { t: 0, v: false };
async function cfAvailable() {
  const s = await loadSettings(); if (s.curseforgeKey) return true; if (!s.friendsServer) return false;
  if (Date.now() - cfAvail.t < 60000) return cfAvail.v;
  let v = false; try { v = !!(await U.getJSON(s.friendsServer.replace(/^ws/, 'http').replace(/\/$/, '') + '/cf-status', { timeout: 5000 })).enabled; } catch {}
  cfAvail = { t: Date.now(), v }; return v;
}
async function cfGet(p, params) {
  const { base, headers } = await cfBase();
  return U.getJSON(base + p + (params ? '?' + new URLSearchParams(params) : ''), { headers: { ...headers, Accept: 'application/json' } });
}
async function cfPost(p, body) { const { base, headers } = await cfBase(); return U.postJSON(base + p, body, headers); }

// ---------------- search ----------------
async function search({ provider, type, query, mcVersion, loader, offset = 0, sort = 'relevance', category }) {
  if (provider === 'curseforge') {
    const p = { gameId: 432, classId: CF_CLASS[type] || 6, pageSize: 20, index: offset, sortField: sort === 'downloads' || !query ? 2 : 1, sortOrder: 'desc' };
    if (query) p.searchFilter = query;
    if (mcVersion) p.gameVersion = mcVersion;
    if (loader && CF_LOADER[loader] && (type === 'mod' || type === 'modpack')) p.modLoaderType = CF_LOADER[loader];
    const r = await cfGet('/mods/search', p);
    return { total: r.pagination ? r.pagination.totalCount : r.data.length, items: r.data.map(m => ({ provider: 'curseforge', id: String(m.id), title: m.name, author: (m.authors || [])[0] ? m.authors[0].name : '', description: m.summary, icon: m.logo ? m.logo.thumbnailUrl || m.logo.url : null, downloads: m.downloadCount, slug: m.slug, type })) };
  }
  const facets = [[`project_type:${type === 'datapack' ? 'datapack' : type}`]];
  if (mcVersion && type !== 'modpack') facets.push([`versions:${mcVersion}`]);
  if (loader && loader !== 'vanilla' && (type === 'mod' || type === 'modpack')) facets.push([`categories:${loader}`]);
  if (category) facets.push([`categories:${category}`]);
  const q = new URLSearchParams({ query: query || '', facets: JSON.stringify(facets), limit: '20', offset: String(offset), index: sort });
  const r = await U.getJSON(`${MR}/search?${q}`);
  return { total: r.total_hits, items: r.hits.map(h => ({ provider: 'modrinth', id: h.project_id, title: h.title, author: h.author, description: h.description, icon: h.icon_url, downloads: h.downloads, slug: h.slug, type, categories: h.display_categories })) };
}

// ---------------- project page (text + images) ----------------
async function project({ provider, id, type }) {
  if (provider === 'curseforge') {
    const [m, d] = await Promise.all([cfGet('/mods/' + id), cfGet(`/mods/${id}/description`)]);
    const x = m.data;
    return { provider, id, title: x.name, summary: x.summary, icon: x.logo ? x.logo.url : null, author: (x.authors || [])[0] ? x.authors[0].name : '', downloads: x.downloadCount, bodyHtml: d.data, bodyMd: null,
      gallery: (x.screenshots || []).map(s => ({ url: s.url, title: s.title || '' })), url: x.links ? x.links.websiteUrl : null, updated: x.dateModified, categories: (x.categories || []).map(c => c.name) };
  }
  const p = await U.getJSON(`${MR}/project/${id}`);
  return { provider, id: p.id, title: p.title, summary: p.description, icon: p.icon_url, author: '', downloads: p.downloads, bodyMd: p.body, bodyHtml: null,
    gallery: (p.gallery || []).sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0)).map(g => ({ url: g.url, title: g.title || '', description: g.description || '' })),
    url: `https://modrinth.com/${p.project_type}/${p.slug}`, updated: p.updated, categories: p.categories, loaders: p.loaders, versions: (p.game_versions || []).slice(-12) };
}

// ---------------- pick a compatible file ----------------
async function modrinthVersion(projectId, mcVersion, loader, type) {
  const q = new URLSearchParams();
  if (mcVersion && type !== 'datapack') q.set('game_versions', JSON.stringify([mcVersion]));
  if (loader && loader !== 'vanilla' && type === 'mod') q.set('loaders', JSON.stringify(loader === 'quilt' ? ['quilt', 'fabric'] : [loader]));
  const vs = await U.getJSON(`${MR}/project/${projectId}/version?${q}`);
  if (!vs.length) return null;
  return vs.find(v => v.version_type === 'release') || vs[0];
}
async function curseFile(projectId, mcVersion, loader, type) {
  const p = { pageSize: 30 };
  if (mcVersion) p.gameVersion = mcVersion;
  if (loader && CF_LOADER[loader] && type === 'mod') p.modLoaderType = CF_LOADER[loader];
  const r = await cfGet(`/mods/${projectId}/files`, p);
  const f = (r.data || []).filter(x => x.isAvailable !== false).sort((a, b) => (a.releaseType || 9) - (b.releaseType || 9) || new Date(b.fileDate) - new Date(a.fileDate))[0];
  return f || null;
}
const cfUrl = (f) => f.downloadUrl || `https://edge.forgecdn.net/files/${Math.floor(f.id / 1000)}/${f.id % 1000}/${encodeURIComponent(f.fileName)}`;

// ---------------- install into an instance (with required dependencies) ----------------
async function install({ instanceId, provider, id, type = 'mod', title, icon }, emit, _seen = new Set()) {
  const inst = await I.get(instanceId);
  const key = provider + ':' + id; if (_seen.has(key)) return []; _seen.add(key);
  const dir = path.join(I.gameOf(instanceId), I.SUB[type] || 'mods');
  const installed = [];
  if (provider === 'curseforge') {
    const f = await curseFile(id, inst.mcVersion, inst.loader, type);
    if (!f) throw new Error(`"${title || id}" has no file for Minecraft ${inst.mcVersion} (${inst.loader}).`);
    emit && emit({ stage: 'Downloading ' + (title || f.fileName) });
    const sha = (f.hashes || []).find(h => h.algo === 1);
    await U.download(cfUrl(f), path.join(dir, f.fileName), { sha1: sha ? sha.value : undefined });
    await I.track(instanceId, { provider, projectId: String(id), versionId: String(f.id), file: f.fileName, name: title || f.displayName || f.fileName, version: f.displayName || '', type, icon: icon || null });
    installed.push(f.fileName);
    for (const d of (f.dependencies || []).filter(d => d.relationType === 3)) {
      try { installed.push(...await install({ instanceId, provider, id: String(d.modId), type: 'mod' }, emit, _seen)); } catch (e) { emit && emit({ warn: 'Dependency ' + d.modId + ': ' + e.message }); }
    }
    return installed;
  }
  const v = await modrinthVersion(id, inst.mcVersion, inst.loader, type);
  if (!v) throw new Error(`"${title || id}" has no version for Minecraft ${inst.mcVersion} (${inst.loader}).`);
  const file = v.files.find(f => f.primary) || v.files[0];
  emit && emit({ stage: 'Downloading ' + (title || file.filename) });
  await U.download(file.url, path.join(dir, file.filename), { sha1: file.hashes && file.hashes.sha1 });
  await I.track(instanceId, { provider, projectId: id, versionId: v.id, file: file.filename, name: title || v.name, version: v.version_number, type, icon: icon || null });
  installed.push(file.filename);
  for (const d of (v.dependencies || []).filter(d => d.dependency_type === 'required' && d.project_id)) {
    try { installed.push(...await install({ instanceId, provider, id: d.project_id, type: 'mod' }, emit, _seen)); } catch (e) { emit && emit({ warn: 'Dependency: ' + e.message }); }
  }
  return installed;
}

// ---------------- modpacks -> new instance ----------------
function safeJoin(base, rel) { const p = path.resolve(base, rel); if (!p.startsWith(path.resolve(base) + path.sep)) throw new Error('Unsafe path in modpack: ' + rel); return p; }

async function installModpack({ provider, id, title, icon }, emit) {
  const AdmZip = require('adm-zip');
  let zipPath, name = title || 'Modpack';
  const tmp = path.join(P.cache, 'packs'); await fsp.mkdir(tmp, { recursive: true });
  if (provider === 'curseforge') {
    const files = await cfGet(`/mods/${id}/files`, { pageSize: 10 });
    const f = files.data.sort((a, b) => new Date(b.fileDate) - new Date(a.fileDate))[0];
    if (!f) throw new Error('Modpack has no files');
    zipPath = path.join(tmp, f.fileName); emit({ stage: 'Downloading modpack', pct: 2 });
    await U.download(cfUrl(f), zipPath);
  } else {
    const vs = await U.getJSON(`${MR}/project/${id}/version`);
    const v = vs[0]; if (!v) throw new Error('Modpack has no versions');
    const file = v.files.find(x => x.primary) || v.files[0];
    zipPath = path.join(tmp, file.filename); emit({ stage: 'Downloading modpack', pct: 2 });
    await U.download(file.url, zipPath, { sha1: file.hashes && file.hashes.sha1 });
  }
  const zip = new AdmZip(zipPath);
  const mrIdx = zip.getEntry('modrinth.index.json'), cfIdx = zip.getEntry('manifest.json');
  let mcVersion, loader = 'vanilla', loaderVersion = '', jobs = [], overridesDirs = ['overrides'];
  if (mrIdx) {
    const idx = JSON.parse(mrIdx.getData().toString('utf8'));
    name = idx.name || name; const d = idx.dependencies || {};
    mcVersion = d.minecraft;
    if (d['fabric-loader']) { loader = 'fabric'; loaderVersion = d['fabric-loader']; } else if (d['quilt-loader']) { loader = 'quilt'; loaderVersion = d['quilt-loader']; }
    else if (d.neoforge) { loader = 'neoforge'; loaderVersion = d.neoforge; } else if (d.forge) { loader = 'forge'; loaderVersion = d.forge; }
    overridesDirs = ['overrides', 'client-overrides'];
    jobs = (idx.files || []).filter(f => !(f.env && f.env.client === 'unsupported')).map(f => ({ rel: f.path, urls: f.downloads, sha1: f.hashes && f.hashes.sha1 }));
  } else if (cfIdx) {
    const m = JSON.parse(cfIdx.getData().toString('utf8'));
    name = m.name || name; mcVersion = m.minecraft.version;
    const ml = (m.minecraft.modLoaders || []).find(x => x.primary) || (m.minecraft.modLoaders || [])[0];
    if (ml) { const [l, ...v] = ml.id.split('-'); loader = l; loaderVersion = v.join('-'); }
    overridesDirs = [m.overrides || 'overrides'];
    const ids = m.files.map(f => f.fileID);
    const info = await cfPost('/mods/files', { fileIds: ids });
    const byId = new Map(info.data.map(f => [f.id, f]));
    for (const f of m.files) { const fi = byId.get(f.fileID); if (fi) jobs.push({ rel: 'mods/' + fi.fileName, urls: [cfUrl(fi)], sha1: (fi.hashes || []).find(h => h.algo === 1)?.value }); }
  } else throw new Error('Unsupported modpack format (no modrinth.index.json or manifest.json)');

  const inst = await I.create({ name, mcVersion, loader, loaderVersion: loader === 'forge' && loaderVersion.startsWith(mcVersion + '-') ? loaderVersion.slice(mcVersion.length + 1) : loaderVersion, icon: 3 });
  const game = I.gameOf(inst.id);
  let n = 0;
  await U.pool(jobs, 8, async (j) => {
    const dest = safeJoin(game, j.rel);
    let lastErr;
    for (const url of j.urls) { try { await U.download(url, dest, { sha1: j.sha1 }); lastErr = null; break; } catch (e) { lastErr = e; } }
    if (lastErr) throw lastErr;
    n++; emit({ stage: 'Downloading mods', pct: 5 + (n / jobs.length) * 90, detail: `${n}/${jobs.length}` });
  });
  for (const e of zip.getEntries()) {
    for (const od of overridesDirs) if (e.entryName.startsWith(od + '/') && !e.isDirectory) {
      const dest = safeJoin(game, e.entryName.slice(od.length + 1)); await fsp.mkdir(path.dirname(dest), { recursive: true }); await fsp.writeFile(dest, e.getData());
    }
  }
  return inst;
}

// ---------------- mod updates (Modrinth-tracked mods) ----------------
async function checkUpdates(instanceId) {
  const inst = await I.get(instanceId);
  const t = (await I.tracked(instanceId)).filter(e => e.provider === 'modrinth' && e.type === 'mod');
  const dir = path.join(I.gameOf(instanceId), 'mods'); const byHash = {};
  for (const e of t) for (const f of [e.file, e.file + '.disabled']) { try { byHash[await U.sha1File(path.join(dir, f))] = e; break; } catch {} }
  if (!Object.keys(byHash).length) return [];
  const body = { hashes: Object.keys(byHash), algorithm: 'sha1', game_versions: [inst.mcVersion] };
  if (inst.loader && inst.loader !== 'vanilla') body.loaders = inst.loader === 'quilt' ? ['quilt', 'fabric'] : [inst.loader];
  const r = await U.postJSON(`${MR}/version_files/update`, body);
  const out = [];
  for (const [h, v] of Object.entries(r || {})) {
    const e = byHash[h]; if (!e || v.id === e.versionId) continue;
    const f = v.files.find(x => x.primary) || v.files[0];
    out.push({ file: e.file, name: e.name, projectId: e.projectId, icon: e.icon, from: e.version, to: v.version_number, versionId: v.id, url: f.url, filename: f.filename, sha1: f.hashes && f.hashes.sha1 });
  }
  return out;
}
async function applyUpdates(instanceId, list, emit) {
  const dir = path.join(I.gameOf(instanceId), 'mods'); let n = 0;
  for (const u of list) {
    emit && emit({ stage: 'Updating ' + u.name, pct: (n / list.length) * 100 });
    await U.download(u.url, path.join(dir, u.filename), { sha1: u.sha1 });
    if (u.filename !== u.file) { await fsp.rm(path.join(dir, u.file), { force: true }); await fsp.rm(path.join(dir, u.file + '.disabled'), { force: true }); }
    await I.track(instanceId, { provider: 'modrinth', projectId: u.projectId, versionId: u.versionId, file: u.filename, name: u.name, version: u.to, type: 'mod', icon: u.icon });
    n++;
  }
  return n;
}

module.exports = { search, project, install, installModpack, cfAvailable, checkUpdates, applyUpdates };
