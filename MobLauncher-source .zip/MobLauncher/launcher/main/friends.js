'use strict';
const WebSocket = require('ws');
const { loadSettings } = require('./paths');
const A = require('./accounts');

let ws = null, timer = null, wantUrl = '', accountId = null, emitFn = () => {}, backoff = 1000, lastPresence = null, state = 'offline';
function setState(s, extra) { state = s; emitFn('friends:state', { state: s, ...(extra || {}) }); }
function getState() { return state; }

async function connect(emit, accId) {
  emitFn = emit || emitFn; accountId = accId || accountId;
  const s = await loadSettings();
  if (!s.friendsServer) { setState('no-server'); return; }
  wantUrl = s.friendsServer;
  disconnect(true);
  const acc = (await A.list()).accounts.find(a => a.id === accountId);
  if (!acc || acc.type === 'offline') { setState('offline-account'); return; }
  setState('connecting');
  try { ws = new WebSocket(wantUrl, { maxPayload: 4 * 1024 * 1024, handshakeTimeout: 10000 }); }
  catch (e) { setState('error', { message: e.message }); return; }
  const mine = ws;
  mine.on('message', async (raw) => {
    let m; try { m = JSON.parse(String(raw)); } catch { return; }
    if (m.t === 'hello') {
      try {
        await A.sessionJoin(accountId, m.challenge);
        const info = (await A.list()).accounts.find(a => a.id === accountId);
        mine.send(JSON.stringify({ t: 'auth', provider: info.type, username: info.name, uuid: info.uuid }));
      } catch (e) { setState('error', { message: e.message }); mine.close(); }
      return;
    }
    if (m.t === 'authed') { backoff = 1000; setState('online'); if (lastPresence) send(lastPresence); }
    if (m.t === 'error' && m.code === 'auth_failed') setState('error', { message: m.message || 'Auth failed' });
    emitFn('friends:msg', m);
  });
  mine.on('close', () => {
    if (ws !== mine) return;
    ws = null;
    if (state !== 'error') setState('offline');
    clearTimeout(timer);
    timer = setTimeout(() => connect(null, accountId), backoff); backoff = Math.min(backoff * 2, 30000);
  });
  mine.on('error', (e) => { if (ws === mine) setState('error', { message: e.message }); });
  const ping = setInterval(() => { if (mine.readyState === 1) mine.send('{"t":"ping"}'); else clearInterval(ping); }, 25000);
}
function disconnect(silent) {
  clearTimeout(timer);
  if (ws) { const w = ws; ws = null; try { w.removeAllListeners('close'); w.close(); } catch {} }
  if (!silent) setState('offline');
}
function send(obj) {
  if (obj && obj.t === 'presence') lastPresence = obj;
  if (ws && ws.readyState === 1) { ws.send(JSON.stringify(obj)); return true; }
  return false;
}
module.exports = { connect, disconnect, send, getState };
