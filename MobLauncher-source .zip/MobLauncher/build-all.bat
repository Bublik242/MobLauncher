@echo off
rem Needs Node.js 20+ (nodejs.org). Builds installer\dist\MobLauncher-Setup-Offline.exe
set /p SRV=Friends server URL (wss://..., Enter to skip): 
set /p MSID=Microsoft Azure client ID (Enter to skip): 
node "%~dp0configure.js" "%SRV%" "%MSID%" || goto :err
cd /d "%~dp0launcher" && call npm i || goto :err
cd /d "%~dp0installer" && call npm i && call npm run payload && call npm run dist:offline || goto :err
echo.& echo DONE: installer\dist\MobLauncher-Setup-Offline.exe & pause & exit /b 0
:err
echo BUILD FAILED & pause & exit /b 1
