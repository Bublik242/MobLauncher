import struct, io, sys, pathlib
from playwright.sync_api import sync_playwright
root = pathlib.Path(__file__).parent
svg = (root/'assets/logo.svg').read_text()
sizes = [16,24,32,48,64,128,256,512]
png = {}
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={'width':512,'height':512})
    for s in sizes:
        pg.set_viewport_size({'width':s,'height':s})
        pg.set_content(f'<body style="margin:0;background:transparent">{svg.replace("<svg ", f"<svg width=%d height=%d " % (s,s),1)}</body>')
        png[s] = pg.screenshot(omit_background=True, clip={'x':0,'y':0,'width':s,'height':s})
    b.close()
(root/'assets/icon.png').write_bytes(png[512])
ico_sizes=[16,24,32,48,64,128,256]
data=b''; entries=b''; off=6+16*len(ico_sizes)
for s in ico_sizes:
    d=png[s]; entries+=struct.pack('<BBBBHHII', s%256, s%256, 0,0,1,32,len(d),off); data+=d; off+=len(d)
(root/'assets/icon.ico').write_bytes(struct.pack('<HHH',0,1,len(ico_sizes))+entries+data)
print('ok')
