// Writes launcher/defaults.json (baked into the installer): node configure.js <friendsServerUrl> [msClientId]
const fs = require('fs'), path = require('path');
const [srv = '', ms = ''] = process.argv.slice(2);
if (srv && !/^wss?:\/\//.test(srv)) { console.error('Friends server must start with wss:// (or ws://)'); process.exit(1); }
fs.writeFileSync(path.join(__dirname, 'launcher', 'defaults.json'), JSON.stringify({ msClientId: ms, curseforgeKey: '', friendsServer: srv }, null, 2));
console.log('launcher/defaults.json written.');
